<?php get_header();?>

<div id="content">
	<div class="wrapper">
    	<div class="content-left">
        
        	<h2 class="title">Page not found!</h2>
            
        </div>
        <div class="content-right">        	
			<?php get_sidebar(); ?>
        </div>
        <div class="clear"></div>
    </div>
</div><!-- EOF : content ID -->

<?php get_footer(); ?>