<?php 
include 'widgets/MyImageWidget.php';
include 'widgets/MyChildWidget.php';
?>