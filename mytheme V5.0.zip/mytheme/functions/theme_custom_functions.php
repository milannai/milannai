<?php 
    /*Include google map function*/
    include ("theme_custom_functions/my_map.php");
    /*end of Include google map function*/
?>