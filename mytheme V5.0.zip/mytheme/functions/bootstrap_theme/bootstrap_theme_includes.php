<?php 
    $style_url = get_bloginfo('template_url')."/functions/bootstrap_theme/";
?>
<link href="<?php echo $style_url; ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $style_url; ?>css/bootstrap-theme.min.css" rel="stylesheet">
<link href="<?php echo $style_url; ?>css/theme.css" rel="stylesheet">
<!--[if lt IE 9]><script src="<?php echo $style_url; ?>js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="<?php echo $style_url; ?>js/ie-emulation-modes-warning.js"></script>
<script src="<?php echo $style_url; ?>js/ie10-viewport-bug-workaround.js"></script>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" href="<?php echo $style_url; ?>fontastic_ico/styles.css">
<link rel="stylesheet" href="<?php echo $style_url; ?>own_style.css">