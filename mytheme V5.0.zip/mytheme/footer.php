	<div id="footer">
    	<div class="wrapper">
        	<p>&copy; 2013 <a href="<?php echo esc_url(home_url('/')); ?>">MY THEME</a> All rights reserved.</p>
        </div>
    </div><!-- EOF : footer ID -->
</div><!-- EOF : main ID -->
<?php wp_footer(); ?>
</body>
</html>