<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>
<?php
	
	global $page, $paged;

	wp_title( '-', true, 'right' );

	bloginfo( 'name' );

	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'mytheme' ), max( $paged, $page ) );

?>
</title>
<link rel="icon" type="image/png" href="<?php echo get_option('favicon_icon'); ?>"/>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /> 
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_enqueue_script( 'jquery' ); wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="main">
	<div id="header">
    	<div class="wrapper">
        	<div id="header-wrap">
        		<a href="<?php echo esc_url(home_url('/')); ?>" id="logo">My Theme</a>
            </div><!-- EOF: header-wrap ID -->
        </div>
    </div><!-- EOF : header ID -->

    <div id="nav">
    	<div class="wrapper">
			<?php wp_nav_menu( array( 'theme_location'  => 'header_menu',                                              
                                      'container'	   => false ) ); ?>
            <div class="clear"></div>
        </div>
    </div><!-- EOF : nav ID -->    