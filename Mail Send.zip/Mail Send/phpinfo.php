<?php 
phpinfo();

?>