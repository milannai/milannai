﻿<?php 


$ip = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);
$_SESSION['client_ip']=$ip;
$_SESSION['client_browser']=$_SERVER['HTTP_USER_AGENT'];
$_SESSION['clienturl']=$_SERVER['PHP_SELF'];

$clientBrowser = $_SESSION['client_browser'];

include 'class.IPInfoDB.php';

// Load the class
$ipinfodb = new IPInfoDB('096b4343df40b24205b235d5b795b1d76a9407fbb3c1dff31be668a459903d1d');
$results = $ipinfodb->getCity($_SERVER['REMOTE_ADDR']);
$countryName = $results['countryName'];
$cityName = $results['cityName'];
    
   

    if($_POST)
    {

        require_once "Mail/Mailinner/Mail.php";
        require "config.php";

        header('Content-Type: application/json');

        $name    = $_POST['name'];
        $email   = $_POST['email'];
        $subject = $_POST['subject'];
        $phoneno = $_POST['phoneno'];
        $message = $_POST['message'];


        if(  $name != '' && $name != null
            && $email != '' && $email != null
          )
        {

        	$host = 'localhost';
			$username = 'aditya_wpxbyteio';
			$password = '$S%Gm@jR=cXF';
			$database = 'aditya_xbytewpio';

           echo $mailToAdmin = mailToAdmin($name, $email, $subject, $phoneno, $message, $ip, $clientBrowser, $countryName, $cityName); // Mail to Admin
           echo $mailToClient = mailToClient($name, $email, $subject, $phoneno, $message); // Mail to Client
           $insertRecord = insertRecordInDatabase($host, $username, $password, $database, $name, $email, $subject, $phoneno, $message); // Save data in DB
           if($insertRecord)
           {
                /*$result = array();
                $result['status'] = true;
                $result['message'] = 'Information has been submitted successfully';
                $finalRes = json_encode($result);*/

                echo true;
           }
           else
           {
                /*$result = array();
                $result['status'] = false;
                $result['message'] = 'Information has not been submitted';
                $finalRes = json_encode($result);*/

                echo false;
           }
        }
        else
        {
            /*$result = array();
            $result['status'] = false;
            $result['message'] = 'Please send all required parameter';
            $finalRes = json_encode($result);*/

            echo 'param';
        }
    }

    // Mail to Admin
    function mailToAdmin($name, $email, $subject, $phoneno, $message, $ip, $clientBrowser, $countryName, $cityName)
    {
        $HTMLmessage = "<html>
                            <head>
                            <title>HTML email</title>
                            </head>
                            <body>
                                <p>Hello Admin,</p>
                                <p><strong>Client Name : </strong>".$name."</p>
                                <p><strong>Client Email : </strong>".$email."</p>
                                <p><strong>Client Phone : </strong>".$phoneno."</p>
                                <p><strong>Topic : </strong>".$subject."</p>
                                <p><strong>Brief : </strong>".$message."</p>
                                <p><strong>Client IP : </strong>".$ip."</p>
                                <p><strong>Browser Info : </strong>".$clientBrowser."</p>
                                <p><strong>Client Country : </strong>".$countryName."</p>
                                <p><strong>Client City : </strong>".$cityName."</p>
                                <p>Thank you.</p>
                            </body>
                            </html>
                        ";

        $toEmail    =  'sales@xbyte.io';
        $fromEmail = 'sales@xbyte.io'; 
        $fromName = 'Travel Intelligence'; 
        $subject = 'Travel Intelligence Inquiry';

        $headers = "From: $fromName"." <".$fromEmail.">";

        //boundary 
        $semi_rand = md5(time()); 
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 

        //headers for attachment 
        $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 

        //multipart boundary 
        $finalMailMessage = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
        "Content-Transfer-Encoding: 7bit\n\n" . $HTMLmessage . "\r\n"; 

        //send email
        $sentMailResult = mail($toEmail, $subject, $finalMailMessage, $headers); 
        if($sentMailResult )  
        { 
           return true; 
        } 
        else
        { 
           return false;
        }
    }

    // Mail to Client
    function mailToClient($name, $email, $subject, $phoneno, $message)
    {
        $HTMLmessage = "<html>
                            <head>
                            <title>HTML email</title>
                            </head>
                            <body>
                                <p>Hello ".$name.",</p> 
                                <p>Thank you for taking the time to contact us!</p>
                                <p>Your message was successfully sent to the X-Byte Sales Team.</p>
                                <p>You should receive a reply from a representative in next few hours.</p>
                                <p>Please be sure to check your spambox.</p>
                                <p>To provide you precise costs/analysis, we generally ask about:</p>
                                <ul>
                                <li>Target site(s) from where you wish us to scrape the data.</li>
                                <li>Specific categories, regions, search filters to be applied for desired data.</li>
                                <li>Number of listings (Approx).</li>
                                <li>Frequency : Once off, or daily/weekly/monthly?</li>
                                <li>List of data fields.</li>
                                </ul>
                                <p>Have A Great Day!</p>
                                <a href='http://www.xbyte.io'>X-Byte</a> <spn>Sales Team </span>
                            </body>
                            </html>
                        ";

        $toEmail    =  $email;
        $fromEmail = 'sales@xbyte.io'; 
        $fromName = 'Travel Intelligence'; 
        $subject = 'Travel Intelligence Inquiry';

        $headers = "From: $fromName"." <".$fromEmail.">";

        //boundary 
        $semi_rand = md5(time()); 
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 

        //headers for attachment 
        $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 

        //multipart boundary 
        $finalMailMessage = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
        "Content-Transfer-Encoding: 7bit\n\n" . $HTMLmessage . "\r\n"; 

        //send email
        $sentMailResult = mail($toEmail, $subject, $finalMailMessage, $headers); 
        if($sentMailResult )  
        { 
           return true; 
        } 
        else
        { 
           return false;
        }
    }




    function insertRecordInDatabase($host, $username, $password, $database, $name, $email, $subject, $phoneno, $message)
    {
        $connection = mysqli_connect($host, $username, $password, $database ); 
        if ($connection->connect_error)
        {
            die("ERROR: Unable to connect: " . $conn->connect_error);
            mysqli_close($connection);
            return false;
        }
        else
        {
           // mysql_select_db($database, $connection);
            echo $queryString = 'INSERT INTO `xbjnj_contact_us` (name, email, subject, phoneno, message) values ("'.$name.'", "'.$email.'", "'.$subject.'", "'.$phoneno.'", "'.mysqli_real_escape_string($connection, $message).'")';
            mysqli_query($connection, $queryString);
            mysqli_close($connection);
            return true;
        }
        
    }

    
?>