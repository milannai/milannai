<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
   <meta charset="utf-8" />
    <meta http-equiv=X-UA-Compatible content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Travel, Hotel and Flights Price Intelligence | Scrape or Extract Price Data</title>
    <meta name="description" content="Scrape or Extract Flights, Airlines, Vacation Rentals, Hotels, villa & Resorts, Car Rentals, Cruise & Ferry, Airbnb, CTrip, with Travel Price Intelligence services USA." />
    <meta name="ahrefs-site-verification" content="1cc61ee3c7c160d563a7072806b95c5b4b7cbacc253f85ea1679095f6d17c315">
    <meta name="google-site-verification" content="pKWkcUoq-tRWdCHxbnPpzg-lB4KtT0JdySPjr-692D4" />
    <meta name="yandex-verification" content="33df86a4b8cac226" />
    <meta name="msvalidate.01" content="31F9087EACA824596661BE3BDB536C9B" />
    <meta name="norton-safeweb-site-verification" content="apb74c427nt8voroihiuffg5cfog0omrg0r4w5dhngkusmeiy-7cah7-0ntl3lhkob7226-9xw2orpz25zask9dzqjfdyncu3hp2gdtjdsa5zn2b3imklpcep1ko2qbz" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="https://www.xbyte.io/travel-intelligence/" />
    <meta name="meta_classification" content="Travel Intelligence - Scrape or Extract Data for AIrbnb, Booking rental, Vacation Rentals, Hotels & Resorts, Travel Aggregator Sites & OTAs, Cruise & Ferry, Attraction & Excursion." />
    <meta name="meta_business" content="Travel Intelligence - Scrape or Extract Data for AIrbnb, Booking rental, Vacation Rentals, Hotels & Resorts, Travel Aggregator Sites & OTAs, Cruise & Ferry, Attraction & Excursion. Travel Technology  " />
    <meta name="meta_copyright" content="X-Byte Enterprise Crawling" />
    <meta name="meta_author" content="Mr. Alpesh Khunt" />
    <meta name="meta_identify_url" content="https://www.xbyte.io/travel-intelligence/" />
    <meta name="meta_reply_to" content="sales@xbyte.io" />
    <meta name="meta_distribution" content="Global" />
    <meta name="meta_revisit_after" content="daily" />
    <meta name="language" content="en-US" />
    <meta name="meta_rating" content="General" />
    <meta name="meta_audience" content="All" />
    <meta name="meta_coverage" content="Worldwide" />
    <meta name="meta_state" content="Gujarat" />
    <meta name="meta_country" content="India" />
    <meta name="meta_document_state" content="Dynamic" />
    <meta name="meta_publisher" content="xbyte.io" />
    <meta property="og:type" content="website" /> 
    <meta property="og:url" content="https://www.xbyte.io" /> 
    <meta property="og:title" content="Travel, Hotel and Flights Price Intelligence | Web Scraping services" /> 
    <meta property="og:description" content="Scrape or Extract Flights, Airlines, Vacation Rentals, Hotels, villa & Resorts, Car Rentals, Cruise & Ferry, Airbnb, CTrip, with Travel Price Intelligence services USA."/>
    <meta property="og:image" content="https://www.xbyte.io/travel-intelligence/img/xbyte-enterprise-crawling.png" /> 
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="300" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@xbyte.io" />
    <meta name="twitter:creator" content="@xbyte.io" />
    <meta name="twitter:title" content="Travel, Hotel and Flights Price Intelligence | Web Scraping services" />
    <meta name="twitter:description" content="Scrape or Extract Flights, Airlines, Vacation Rentals, Hotels, villa & Resorts, Car Rentals, Cruise & Ferry, Airbnb, CTrip, with Travel Price Intelligence services USA." />
    <meta name="twitter:image" content="https://www.xbyte.io/travel-intelligence/img/xbyte-enterprise-crawling.png" />
    <meta name="twitter:image:alt" content="X-Byte-logo">
    <link rel="shortcut icon" href=images/favicon.png />
    <meta name=mobile-web-app-capable content=yes>
    <link rel="shortcut icon" href="img/favicon.jpg" type="image/x-icon">
    <meta name="X-Byte Enterprise Crawling" content=images/favicon.png />
    <meta name=msapplication-TileColor content=#202429 />
    <meta name=apple-mobile-web-app-capable content=yes />
    <meta name=apple-mobile-web-app-status-bar-style content=black />
    <meta name=apple-mobile-web-app-title content="X-Byte Enterprise Crawling" />
    <meta name=apple-mobile-web-app-title content="X-Byte Enterprise Crawling" />
    <meta name="p:domain_verify" content="6f4aada105eba785a5e0f663bb7f1ea4"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/bootstrap-selector/css/bootstrap-select.min.css">
    <!--icon font css-->
    <link rel="stylesheet" href="vendors/themify-icon/themify-icons.css">
    <link rel="stylesheet" href="vendors/flaticon/flaticon.css">
    <link rel="stylesheet" href="vendors/animation/animate.css">
    <link rel="stylesheet" href="vendors/owl-carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
    <link rel="stylesheet" href="vendors/magnify-pop/magnific-popup.css">
    <link rel="stylesheet" href="vendors/scroll/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="vendors/elagent/style.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>

<body>
    <div class="body_wrapper">
         <header class="header_area">
            <nav class="navbar navbar-expand-lg menu_one erp_menu">
                <div class="container">
                    <a class="navbar-brand" href="https://www.xbyte.io/"><img src="img/xbyte-enterprise-crawling.png" alt="Travel Intelligence - Scrape data Flights, Hotels, Car Rentals"></a>
                    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="menu_toggle">
                            <span class="hamburger">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                            <span class="hamburger-cross">
                                <span></span>
                                <span></span>
                            </span>
                        </span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto mr-auto menu">
                            <li class="nav-item dropdown submenu mega_menu mega_menu_two active">
                                <a class="nav-link" href="#home" role="button">Home</a>
                            </li>
                            <li class="nav-item"><a title="Pages" class="dropdown-toggle nav-link" href="#process">Process</a>
                                
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="#Solution" role="button">Solution</a></li>
                                
                            <li class="nav-item">
                                <a class="nav-link" href="#Features-info" role="button">Features</a>                                
                            </li>                         
                        </ul>
                        <a class="er_btn btn_hover" href="#contactus">Get in touch</a>
                    </div>
                </div>
            </nav>
        </header>
        <section class="support_home_area" id="home">
            <div class="banner_top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2 class="f_p f_size_40 l_height60 wow fadeInUp" data-wow-delay="0.3s"><span class="f_700">Travel, Hotel and Flights Price Intelligence </span>- Scrape or Extract Price Data</h2>
                            <p class="f_size_18 l_height30 wow fadeInUp" data-wow-delay="0.5s">Real-time Travel Intelligence Solutions for Smarter Business Decisions</p>
                            <form id="emailsubForm" class="mailchimp wow fadeInUp" data-wow-delay="0.6s">
                                <div class="input-group subcribes">
                                    <input type="text" name="EMAIL" id="es_email" palceHolderVal="Email" class="form-control memail req" placeholder="sales@xbyte.io">
                                    <button class="btn btn_submit f_size_15 f_500" id="emailSubbtn" type="submit">Get Started</button>
                                </div>
                                <div class="col-md-12 mb-40 margin-top-10 " id="responseMessage1"></div>
                                <div id="success">Your message succesfully sent!</div>
                                <div id="error">Opps! There is something wrong. Please try again</div> 
                                <div class="loader-form-submit" style="display: none;"></div>
                            </form>
                        </div>
                    </div>
                    <div class="support_home_img wow fadeInUp" data-wow-delay="0.9s">
                        <img src="img/new-home/banner.png" alt="">
                    </div>
                </div>
            </div>
        </section>
        <section class="support_partner_logo_area">
            <div class="container">
                <h4 class="f_size_18 f_400 f_p text-center l_height28 mb_50">&nbsp;</h4>
                <div class="row partner_info">
                    <div class="logo_item">
                        <a><img src="img/home3/logo_01.png" alt="Airbnb Travel Data Scraping services"></a>
                    </div>
                    <div class="logo_item">
                        <a><img src="img/home3/logo_02.png" alt="Booking Travel Data Scraping services"></a>
                    </div>
                    <div class="logo_item">
                        <a"><img src="img/home3/logo_03.png" alt="Expedia Travel Data Scraping services"></a>
                    </div>
                    <div class="logo_item">
                        <a><img src="img/home3/logo_04.png" alt="Kayak Travel Data Scraping services"></a>
                    </div>
                    <div class="logo_item">
                        <a><img src="img/home3/logo_05.png" alt="Ctrip Travel Data Scraping services"></a>
                    </div>
                </div>
                <div class="border_bottom"></div>
            </div>
        </section>
        
        <section class="payment_features_area_three disktop-view">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                    <div class="payment_features_img-back">     
                    <div class="row">
                         <!-- <div class="payment_features_img">  -->
                             <!-- <img src="img/new/app_screen.png" alt="" >  -->
                        <!-- </div>-->                                      
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/flights.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Flight & Airlines</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo3.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo2.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo1.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30 margin-top-50">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/car_rental.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Car Rental</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo6.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo5.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo4.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/hotels.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Hotel & OTAs</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo7.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo8.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo9.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30 margin-top-50">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/vaction.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Vacation Rental</span></div>
                                </div>
                                <div class="side back">
                                    <div><img src="img/new/lo10.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo11.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo12.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    <div class="col-lg-6 d-flex align-items-center">
                        <div class="">
                           <h2 class="travelindu">Online Travel Industry</h2>
                            <p class="text-justify travelindutext">Online travel industry is highly competitive and endures constant price fluctuations. It is really critical to keep track of real –time competitive information to maximize the revenue for various travel oriented businesses like Hotels, Tours & Travel Aggregaors, OTAs, Airlines, Rail, Car Rental agency, Travel Technology solution providers etc. </p>
                            <p class="text-justify travelindutext">Competition in the online travel industry is fierce. Businesses can differentiate from the competition by using real time market data to understand market, competitors and customers. Analysis of such data in right time can drive the right decisions and deliver positive business outcomes. More than ever, such live data can give extra mileage to outperform competitors and stay on top of dynamic markets.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
       
       <section class="payment_features_area_three mobile-view">
            <div class="container">
                <div class="row">                   
                    <div class="col-lg-6 d-flex align-items-center">
                        <div class="">
                           <h2 class="travelindu">Online Travel Industry</h2>
                            <p class="text-justify travelindutext">Online travel industry is highly competitive and endures constant price fluctuations. It is really critical to keep track of real –time competitive information to maximize the revenue for various travel oriented businesses like Hotels, Tours & Travel Aggregaors, OTAs, Airlines, Rail, Car Rental agency, Travel Technology solution providers etc. </p>
                            <p class="text-justify travelindutext">Competition in the online travel industry is fierce. Businesses can differentiate from the competition by using real time market data to understand market, competitors and customers. Analysis of such data in right time can drive the right decisions and deliver positive business outcomes. More than ever, such live data can give extra mileage to outperform competitors and stay on top of dynamic markets.</p>
                            
                        </div>
                    </div>
                     <div class="col-lg-6">
                    <div class="payment_features_img-back">     
                    <div class="row">                                                           
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/flights.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Flight & Airlines</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo3.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo2.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo1.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30 margin-top-50 xs-margin-top-0">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/car_rental.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Car Rental</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo6.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo5.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo4.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/hotels.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Hotel & OTs</span></div>
                                </div>
                                <div class="side back">
                                        <div><img src="img/new/lo7.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo8.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo9.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-30 margin-top-50 xs-margin-top-0">
                            <div class="card-container">
                              <div class="card">
                                <div class="side">
                                    <div><img src="img/new/vaction.png"></div>
                                    <div class="margin-top-10"><span class="font-weight-bold font-size-20 color-black">Vacation Rental</span></div>
                                </div>
                                <div class="side back">
                                    <div><img src="img/new/lo10.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo11.png"></div>
                                        <div class="margin-top-10"><img src="img/new/lo12.png"></div>
                                </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>

       <section class="developer_product_area">
            <div class="container">
            <div class="sec_title text-center mb_70 wow fadeInUp" data-wow-delay="0.2s">
                    <h2 class="f_p f_size_30 l_height50 f_600 t_color3">Travel Intelligence Solution</h2>
                </div>
                <div class="row">
                
                    <div class="col-lg-6 d-flex align-items-center">
                        <div class="developer_product_content">
                            <ul class="nav nav-tabs develor_tab mb-30" id="myTab2" role="tablist">
                                <li class="nav-item">
                                    <span class="nav-link active" data-tab="tab_one" id="ruby-tab" data-toggle="tab" href="#ruby" role="tab" aria-controls="ruby" aria-selected="true">Data Extraction</span>
                                </li>
                                <li class="nav-item">
                                    <span class="nav-link" data-tab="tab_two" id="curl-tab" data-toggle="tab" href="#curl" role="tab" aria-controls="curl" aria-selected="false"> Business Insights (Dashboard)</span>
                                </li>
                            </ul>
                            <div class="tab-content developer_tab_content">
                                <div class="tab-pane fade show active" id="ruby" role="tabpanel" aria-labelledby="ruby-tab">
                                <h2 class="f_p f_size_20 l_height50 f_600 t_color3">Travel Data Extraction <h2>
                                    <p class="mb_40 text-justify">Travel Data Extraction from X-Byte offers a complete solution for accurate pricing and product data of all competitors that one desires to track. With tailor made offerings for OTAs, airlines / rail companies & car rental agencies, it facilitates complete, robust decision support system that allows businesses to strategize their pricing policy at right time. It delivers manageable data on demand as per the industry specific need and to be integrated directly with pricing and revenue management systems.</p>
                                    
                                </div>
                                <div class="tab-pane fade" id="curl" role="tabpanel" aria-labelledby="curl-tab">
                                <h2 class="f_p f_size_20 l_height50 f_600 t_color3">Travel Business Insights (Dashboard)<h2>
                                    <p class="mb_40 text-justify">Travel Business Insights from X-Byte is the exclusive (Addon) functionality offered by X-Byte that enable user to view the interactive user defined reports from the data collected via Travel Data Extraction Solution. It is very important functionality for pricing analyst & Revenue Managers to view the competitive pricing landscape with easy-to-use visual reports. </p>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="tab_img_info">
                            <div class="tab_img active" id="tab_one">
                                <img class="img-fluid wow fadeInRight" src="img/home5/data-extraction.jpg" alt="data-extraction">
                            </div>
                            <div class="tab_img" id="tab_two">
                                <img class="img-fluid wow fadeInRight" src="img/home5/business-insights-dashboard.png" alt="business-insights-dashboard">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="IntelligenceProcess" id="process">
            <div class="container">
             <div class="sec_title text-center mb_70">
                <h2 class="travelindu">Online Travel Intelligence Process</h2>
            </div>
            <div class="TravelIntelligenceProcess">
                <div class="row">
                  <div class="margin-20">
                    <div>
                    <div class="d-flex justify-content-space-between margin-bottom-20">
                        <h4 class="f_600 f_size_20 l_height28 t_color2 mb_20">Definition</h4>
                        <div class="w-40"><img src="img/home2/Definition.png"></div>
                    </div>
                    <div class="xs-center"><img src="img/home2/undraw.png" alt=""></div>
                    </div>
                  </div>
                  <div class="margin-20">
                  <div>
                    <div class="d-flex justify-content-space-between margin-bottom-20">
                    <h4 class="f_600 f_size_20 l_height28 t_color2 mb_20">Crawling</h4>
                    <div class="w-40"><img src="img/home2/crawling.png"></div>
                    </div>
                    <div class="xs-center"><img src="img/home2/inbox.png" alt=""></div>
                    </div>
                  </div>
                  <div class="margin-20">
                  <div>
                    <div class="d-flex justify-content-space-between margin-bottom-20">
                    <h4 class="f_600 f_size_20 l_height28 t_color2 mb_20">Preparation</h4>
                    <div class="w-40"><img src="img/home2/preparation.png"></div>
                    </div>
                    <div class="xs-center"><img src="img/home2/file.png" alt=""></div>
                    </div>
                  </div>
                  <div class="margin-20">
                  <div>
                    <div class="d-flex justify-content-space-between margin-bottom-20">
                    <h4 class="f_600 f_size_20 l_height28 t_color2 mb_20">Integration</h4>
                    <div class="w-40"><img src="img/home2/integration.png"></div>
                    </div>
                    <div class="xs-center"><img src="img/home2/report.png" alt=""></div>
                    </div>
                  </div>
                  <div class="margin-20">
                  <div>
                    <div class="d-flex justify-content-space-between margin-bottom-20">
                    <h4 class="f_600 f_size_20 l_height28 t_color2 mb_20">Analysis</h4>
                    <div class="w-40"><img src="img/home2/ana.png"></div>
                    </div>
                    <div class="xs-center"><img src="img/home2/price-1.png" alt="" ></div>
                    </div>
                  </div>
                </div>
            </div>
         </div>
        </section>
        <section class="h_analytices_features_area" id="Solution">
            <div class="container">
                <div class="row h_analytices_features_item">
                    <div class="col-lg-6">
                        <div class="h_analytices_img">
                            <img class="wow fadeInUp" src="img/home-software/analytices4.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Flights, Airlines & Rail </h2>
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Review pricing of any O&Ds pair with PAX for fix departure date</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Analyze promotions during the festive seasons</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Track route information from entire Travel Marketplace</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Identify opportunities to minimize rival advantage </li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Real-time price monitoring to align the pricing</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Automatic Alerts & user defined reports</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Easy Integration with 3rd Party Application</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item flex-row-reverse">
                    <div class="col-lg-6">
                        <div class="h_analytices_img_two">
                            <img class="wow fadeInUp" src="img/home-software/analytices5.png" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Vacation Rentals, Hotels, villa & Resorts</h2>
                            
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Get property pricing based on any destination; specific geography; star rating</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Align pricing strategy based on inventory, availability and pricing data</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Fetch hotel pricing  from geo specific IP addresses for check-in dates, PAX, LOS</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Collect attributes including Facilities, Reviews, Ratings, Images & contacts</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Daily review competitors’ pricing to align your pricing</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Set optimal rate based on demand, season, weekends, competition & more</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Analyze customer reviews for better customer experience</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item">
                    <div class="col-lg-6">
                        <div class="h_analytices_img">
                            <img class="wow fadeInUp" src="img/home-software/ota.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Travel Aggregator Sites & OTAs</h2>
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Monitor variety of travel products i.e. flights, hotels, deals, car rentals, cruises, attractions</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Destination wise cheapest deal including hotel + Flight price</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Track travel deals, packages, promotions and special offers</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Collect reviews in numbers for hotels, vacation rentals, packages etc.</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Bespoke solution with user defined reports</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Constant source of live data from all brand sites, Metas & OTAs for real time analysis</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Keep track of Mobile Rates, B2B Rates & Promotional Rates to easily customize your offers</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item flex-row-reverse">
                    <div class="col-lg-6">
                        <div class="h_analytices_img_two">
                            <img class="wow fadeInUp" src="img/home-software/carrent.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Car Rentals</h2>
                            
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Set right car rates for right market, at right time, for right audience</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Track up-to-the-minute accurate pricing data for every competitor</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Compare any car types for a specific pickup (Also return) location and date</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Review  price changes based on different pickup times at locations</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Collect rental fare for hourly rate, daily rate, transfer, one way and multi-city</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Accurate Inventory Mapping & seamless competition Tracking to set optimized car rental price</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Analyze historical data & indicators like weather, festivals, demand to align the pricing</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item">
                    <div class="col-lg-6">
                        <div class="h_analytices_img">
                             <img class="wow fadeInUp" src="img/home-software/cruise.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Cruise & Ferry</h2>
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Collect pricing based on Journey Type, Duration, Route, Boarding and Disembarkation port </li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Analyse historical data to validate pricing strategy and checking pricing pattern</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Price recommendations based on data, reports & alerts to improve experience</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Examine competitor pricing strategy of Cruises and Ferries industry</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">On demand Coverage from all popular cruise lines & Ferries</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Real time insights based on specific events & festive seasons</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Easy Integration with 3rd Party Application</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item flex-row-reverse">
                    <div class="col-lg-6">
                        <div class="h_analytices_img_two">
                            <img class="wow fadeInUp" src="img/home-software/attraction.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Attraction & Excursion</h2>
                            
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Monitor price information from multiple excursion web portals</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">Collect attraction details like Meeting Point, Included, Excluded, Highlights, Cancellation Policy, reviews & ratings etc.</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Collect attractions of any of the popular destination with images</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Filter pricing based on Dates, deals, Time of the day & duration, Star Ratings</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Pricing intelligence report with bespoke functionalities</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Accurate Mapping of Attractions among all the competitors to get ready price comparison</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Review attraction ticket pricing of future dates for festive seasons and weekends.</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row h_analytices_features_item">
                    <div class="col-lg-6">
                        <div class="h_analytices_img">
                           <img class="wow fadeInUp" src="img/home-software/Travel1.png" alt="" >
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="h_analytices_content">
                            <h2 class="wow fadeInUp" data-wow-delay="0.1s">Travel Technology Solution Providers</h2>
                            <ul class="list-unstyled">
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.5s">Automated data feeds in large volume on a regular basis</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.7s">API Integration with existing Travel Technology System</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Data Collection from both Websites & Mobile Apps </li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Timely & Accurate data Stream enable to enhance their existing product functionalities</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Real time data flows of Hotels, Airlines, Flight, Restaurant, Car Rental & other Travel Products</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">On demand solution to source from all online travel sources</li>
                                <li class="wow fadeInUp text-justify" data-wow-delay="0.9s">Multi currency & multi language functionalities with dedicated residential IP address</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="payment_service_area" id="Features-info">
            <div class="container">
                <div class="row flex-row-reverse">
                    <div class="col-lg-4">
                        <div class="service-content wow fadeInRight" data-wow-delay="0.2s">
                            <div class="pay_icon">
                                <div class="icon_shape"></div>
                                <img src="img/home9/icon3.png" alt="" >
                            </div>
                            <h2 class="f_p w_color f_700">Salient Features</h2>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-md-6 media payment_service_item wow fadeInUp" data-wow-delay="0.2s">
                                <div class="icon">
                                    <img src="img/home9/icon4.png" alt="" >
                                </div>
                                <div class="media-body">
                                    <h3 class="f_size_20 f_p w_color f_600">Robust & Accurate</h3>
                                    <p class="f_400 f_size_15 w_color">Collecting tons of accurate information from multiple travel sources</p>
                                </div>
                            </div>
                            <div class="col-md-6 media payment_service_item wow fadeInUp" data-wow-delay="0.3s">
                                <div class="icon">
                                    <img src="img/home9/icon7.png" alt="" >
                                </div>
                                <div class="media-body">
                                    <h3 class="f_size_20 f_p w_color f_600">On demand</h3>
                                    <p class="f_400 f_size_15 w_color">Extraction of data whenever user require</p>
                                </div>
                            </div>
                            <div class="col-md-6 media payment_service_item wow fadeInUp" data-wow-delay="0.4s">
                                <div class="icon">
                                    <img src="img/home9/icon5.png" alt="" >
                                </div>
                                <div class="media-body">
                                    <h3 class="f_size_20 f_p w_color f_600">User defined</h3>
                                    <p class="f_400 f_size_15 w_color">Fetching of filtered data as per user’s business preference  </p>
                                </div>
                            </div>
                            <div class="col-md-6 media payment_service_item wow fadeInUp" data-wow-delay="0.5s">
                                <div class="icon">
                                    <img src="img/home9/icon8.png" alt="" >
                                </div>
                                <div class="media-body">
                                    <h3 class="f_size_20 f_p w_color f_600">Diverse Sources </h3>
                                    <p class="f_400 f_size_15 w_color">Sourcing of data from both travel Website & Mobile Apps</p>
                                </div>
                            </div>
                            <div class="col-md-6 media payment_service_item wow fadeInUp" data-wow-delay="0.6s">
                                <div class="icon">
                                    <img src="img/home9/icon6.png" alt="" >
                                </div>
                                <div class="media-body">
                                    <h3 class="f_size_20 f_p w_color f_600">Secured Interface</h3>
                                    <p class="f_400 f_size_15 w_color">Data & connections are highly protected from any threats</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="support_integration_area ">
            <div class="container">
                <div class="sec_title text-center mb_70 wow fadeInUp" data-wow-delay="0.3s">
                    <h2 class="f_p f_size_30 l_height50 f_600 t_color3">Common Use Cases</h2>
                    <p class="f_300 f_size_16 mb-0">Why I say old chap that is spiffing lavatory chip shop gosh off his nut, smashing boot<br> are you taking the piss posh loo brilliant matie boy.!</p>
                </div>
                <div class="row flex-row-reverse">
                    <div class="col-lg-9 col-md-10 col-sm-12">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="https://www.xbyte.io/travel-intelligence/price-monitoring" target="_blank" class="s_integration_item">
                                    <img src="img/new-home/kissmetrics.png" alt="" >
                                    <h5>Price Monitoring</h5>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="https://www.xbyte.io/travel-intelligence/price-monitoring" target="_blank" class="s_integration_item">
                                    <img src="img/new-home/metorik.png" alt="" >
                                    <h5>Competitive Intelligence</h5>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="#" class="s_integration_item">
                                    <img src="img/new-home/nicereply-1.png" alt="" >
                                    <h5>Inventory Watch</h5>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="#" class="s_integration_item">
                                    <img src="img/new-home/campfire.png" alt="" >
                                    <h5>Building Travel Portfolio</h5>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="https://www.xbyte.io/solution/travel-hotel-intelligence/" target="_blank" class="s_integration_item">
                                    <img src="img/new-home/webhooks.png" alt="" >
                                    <h5>Traveller Sentiment: Review & Rating </h5>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <a href="https://www.xbyte.io/solution/social-media-monitoring/" target="_blank" class="s_integration_item">
                                    <img src="img/new-home/briteverify.png" alt="" >
                                    <h5>Social Media</h5>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-2 col-sm-12">
                        <img class="integration_img" src="img/new-home/tree.png" alt="" >
                    </div>
                </div>
            </div>
        </section>
        <section class="seo_fact_area sec_pad">
            <div class="home_bubble">
                <div class="bubble b_one"></div>
                <div class="bubble b_three"></div>
                <div class="bubble b_four"></div>
                <div class="bubble b_six"></div>
                <div class="triangle b_eight" data-parallax='{"x": 120, "y": -10}'><img src="img/seo/triangle_one.png" alt=""></div>
            </div>
            <div class="container">
                <div class="seo_sec_title text-center mb_70 wow fadeInUp" data-wow-delay="0.3s">
                    <h2>Over 9000+<br> completed work & Still counting.</h2>
                </div>
                <div class="seo_fact_info">
                    <div class="seo_fact_item">
                        <div class="text">
                            <div class="counter one">+7</div>
                            <p>Year of Experience</p>
                        </div>
                    </div>
                    <div class="seo_fact_item Employee">
                        <div class="text">
                            <div class="counter two">+120</div>
                            <p>Employee Strength</p>
                        </div>
                    </div>
                    <div class="seo_fact_item client">
                        <div class="text">
                            <div class="counter three">+1000</div>
                            <p>Clients Worldwide</p>
                        </div>
                    </div>
                    <div class="seo_fact_item last data">
                        <div class="text">
                            <div class="counter four">+2500</div>
                            <p>Data Feeds Every Day</p>
                        </div>
                    </div>
                    <div class="seo_fact_item Completed">
                        <div class="text">
                            <div class="counter three">+9000</div>
                            <p>Completed Projects</p>
                        </div>
                    </div>
                    <div class="seo_fact_item last">
                        <div class="text">
                            <div class="counter four">+1000</div>
                            <p>MM Pages Crawled per Month</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="s_subscribe_area">
            <div class="s_shap">
                <svg class="right_shape" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <defs>
                        <linearGradient id="PSgrad_5">
                            <stop offset="0%" stop-color="rgb(103,84,226)" stop-opacity="0.95"/>
                            <stop offset="100%" stop-color="rgb(25,204,230)" stop-opacity="0.95"/>
                        </linearGradient>
                    </defs>
                    <path fill="url(#PSgrad_5)" d="M543.941,156.289 L227.889,41.364 C184.251,25.497 136.000,47.975 120.118,91.571 L5.084,407.325 C-10.799,450.921 11.701,499.127 55.339,514.995 L371.391,629.920 C415.029,645.788 463.280,623.309 479.162,579.713 L594.196,263.959 C610.079,220.362 587.579,172.157 543.941,156.289 Z"/>
                    <path fill="url(#PSgrad_5)" d="M625.661,120.004 L309.609,5.079 C265.971,-10.790 217.720,11.689 201.838,55.286 L86.804,371.039 C70.921,414.636 93.421,462.842 137.059,478.709 L453.111,593.634 C496.749,609.502 545.000,587.024 560.882,543.427 L675.916,227.673 C691.799,184.077 669.299,135.872 625.661,120.004 Z"/>
                </svg>
                <svg class="bottom_shape" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <defs>
                        <linearGradient id="PSgrad_6" x1="76.604%" x2="0%" y1="0%" y2="64.279%">
                            <stop offset="0%" stop-color="rgb(103,84,226)" stop-opacity="0.95"/>
                            <stop offset="100%" stop-color="rgb(25,204,230)" stop-opacity="0.95"/>
                        </linearGradient>
                    </defs>
                    <path fill="url(#PSgrad_6)" d="M543.941,156.289 L227.889,41.365 C184.251,25.496 136.000,47.975 120.118,91.572 L5.084,407.325 C-10.799,450.922 11.701,499.127 55.339,514.995 L371.391,629.920 C415.029,645.788 463.280,623.310 479.162,579.713 L594.196,263.959 C610.079,220.362 587.579,172.157 543.941,156.289 Z"/>
                    <path fill="url(#PSgrad_6)" d="M625.661,120.004 L309.609,5.078 C265.971,-10.789 217.720,11.689 201.838,55.286 L86.804,371.040 C70.921,414.636 93.421,462.842 137.059,478.709 L453.111,593.634 C496.749,609.502 545.000,587.023 560.882,543.427 L675.916,227.673 C691.799,184.077 669.299,135.871 625.661,120.004 Z"/>
                </svg>
            </div>
            <div class="container">
                <div class="sec_title text-center mb_50 wow fadeInUp" data-wow-delay="0.4s">
                    <h2 class="f_p f_size_30 l_height50 f_600 t_color">X-Byte Enterprise Crawling</h2>
                    <p class="f_300 f_size_16 l_height34 text-justify">X-Byte Enterprise Crawling helps aggregating data from thousands of web sources, enabling the big data enterprises transforming data into actionable insights. X-Byte aims to be one of the largest data sourcing company with its cloud-based automated data harvesting eco-system. Started in Feb 2012, X-Byte has achieved 200% growth year on year since inception, now spread over 13500 sq.ft. with a team size of 120+ resources at 2 delivery centres in Ahmedabad, India.</p>
                    <p class="f_300 f_size_16 l_height34 text-justify">X-Byte, with its custom Data-as-a-Service (DaaS) model, takes care of end-to-end extraction processes from setting up of crawlers, servers, proxies, extraction, monitoring, quality assurance, timely delivery and continuous maintenance due to structural changes in the websites.</p>
                </div>
            </div>
        </section>
        
       
        
        <footer class="new_footer_area bg_color" id="contactus">
            <div class="new_footer_top">
                <div class="container">
            <div class="sec_title text-center mb_50 wow fadeInUp" data-wow-delay="0.3s">
                    <h2 class="f_p f_size_30 l_height50 f_600 t_color3">Contact Us</h2>
                    <p class="f_300 f_size_16 mb-0">We will help you drive business value from technology innovations</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 pr-0">
                        <div class="contact_info_item">
                            <h6 class="f_p f_size_20 t_color3 f_500 mb_20">Office Address</h6>
                            <b class="f_p f_size_16 t_color3 f_500 mb_20">India Office Address</b>
                            <p class="f_300 f_size_15">A-412, 4th Floor, Dev Arc Commercial Complex Iscon Cross Road, Sarkhej - Gandhinagar Hwy, Ahmedabad, Gujarat 380015</p>
                            
                            <b class="f_p f_size_16 t_color3 f_500 mb_20">USA Office Address</b>
                            <p class="f_300 f_size_15">10685-B Hazelhurst Dr. #23604 Houston, TX 77043 USA</p>
                        </div>
                        <div class="contact_info_item">
                            <h6 class="f_p f_size_20 t_color3 f_500 mb_20">Contact Info</h6>
                            <p class="f_300 f_size_15"><span class="f_400 t_color3">India Phone:</span> <a href="tel:3024437488">+91 (79) 403 924 66</a></p>
                            <p class="f_300 f_size_15"><span class="f_400 t_color3">USA Phone:</span> <a href="tel:3024437488">+1 (832) 251 7311</a></p>
                            <p class="f_300 f_size_15"><span class="f_400 t_color3">Email:</span> <a href="mailto:saasland@gmail.com">sales@xbyte.io</a></p>
                        </div>
                    </div>
                    <div class="col-lg-8 offset-lg-1">
                        <div class="contact_form">
                            <form class="contact_form_box" id="contactForm" novalidate="novalidate">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group text_box">
                                            <input class="req" type="text" id="name" name="name" placeholder="Your Name">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group text_box">
                                            <input class="req" type="text" name="email" id="email" placeholder="Your Email">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group text_box">
                                            <input type="text" id="mobile" name="mobile" placeholder="Mobile Number">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group text_box">
                                            <input type="text" id="subject" name="subject" placeholder="Subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group text_box">
                                            <textarea name="message" id="message" cols="30" rows="10" placeholder="Enter Your Message . . ."></textarea>
                                        </div>
                                    </div>
                                     <div class="col-lg-12">
                                         <div class="g-recaptcha" data-sitekey="6Ldu4LkUAAAAALqcshBowKtYW-qurTHQqabaPnEG"></div>
                                          <div class="col-md-12 mb-40 " id="recaptchResponse" style="color: red;"></div>
                                    </div>
                                    <div class="col-lg-12 margin-top-10">
                                        <button type="submit" id="submitContactForm" class="btn_three">Send Message</button>
                                        <span class="loader-form-submit" style="display: none;"></span>
                                    </div>
                                </div>

                            </form>
                            <div class="col-md-12 mb-40 margin-top-10 " id="responseMessage"></div>
                            <div id="success">Your message succesfully sent!</div>
                            <div id="error">Opps! There is something wrong. Please try again</div>
                        </div>
                    </div>
                </div>
        
        
                </div>
                <div class="footer_bg">
                    <div class="footer_bg_one"></div>
                    <div class="footer_bg_two"></div>
                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-sm-5 col-xs-12">
                            <p class="mb-0 f_300">© COPYRIGHT © 2019 - <a href="https://www.xbyte.io/" class="color-black-gray">XBYTE-IO.</a> ALL RIGHTS RESERVED.</p>
                        </div>
                        <div class="col-lg-2 col-sm-2 col-xs-12 xs-text-center xs-mt-15">
                            <a href="https://www.dmca.com/Protection/Status.aspx?ID=a59d3aee-fc7d-4dfb-abf6-dfcb4fff40f7"><img src="img/dmca.png"></a>
                        </div>
                        <div class="col-lg-4 col-sm-5 text-right xs-text-center">
                             <div class="f_social_icon">
                                    <a href="https://www.facebook.com/xbyteio" class="ti-facebook"></a>
                                    <a href="https://twitter.com/xbyteio" class="ti-twitter-alt"></a>
                                    <a href="https://www.linkedin.com/company/xbyte-crawling" class="ti-linkedin"></a>
                                    
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <form class="search_boxs" role="search">
        <div class="search_box_inner">
            <div class="close_icon">
                <i class="icon_close"></i>
            </div>
            <div class="input-group">
                <input type="text" name="search" class="form_control search-input" placeholder="Recipient's username" autofocus>
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="button"><i class="icon_search"></i></button>
                </div>
            </div>
        </div>
    </form>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/propper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="vendors/bootstrap-selector/js/bootstrap-select.min.js"></script>
    <script src="vendors/wow/wow.min.js"></script>
    <script src="vendors/sckroller/jquery.parallax-scroll.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
    <script src="vendors/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/magnify-pop/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="vendors/scroll/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- <script src="vendors/multiscroll/jquery.easings.min.js"></script>
    <script src="vendors/multiscroll/multiscroll.responsiveExpand.limited.min.js"></script>
    <script src="vendors/multiscroll/jquery.multiscroll.extensions.min.js"></script> -->
    <script src="js/main.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <script type="text/javascript">
var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || 
{widgetcode:"ae56a149c873a9fe8a949af24eed3313a5a205bf4d221192ae8170160d3b6bb66970830d0bca98e608f2ec39ec1bc0e0", values:{},ready:function(){}};
var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;
s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);d.write("<div id='zsiqwidget'></div>");
</script>
</script>


    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123159302-5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123159302-5');
</script>


<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(55463599, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/55463599" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

     <script type="text/javascript">
        var BASEURL = 'http://www.xbyte.io/travel-intelligence/';

        function validateEmail(inputText) {
            var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if (reg.test(inputText) == false) {
                return false;
            }
            return true;
        }

        jQuery(document).on('click', '#submitContactForm', function(e){
                
                e.preventDefault();

                var errorCount = 0;
                jQuery('#contactForm .error-msg').remove(); // Remove Error Message
                jQuery('#contactForm').find('.req').each(function(){
                    var that = jQuery(this);
                    var inputVal = that.val();
                    var inputId = that.attr('id');
                    inputVal = jQuery.trim(inputVal);
                    that.removeClass('validation-error'); // Remove Class
                    
                    if(inputVal == '')
                    {
                        var palceHolderVal = that.attr('placeholder');
                        that.after('<ul class="validation-errors-list filled error-msg text-danger"><li class="validation-required">'+palceHolderVal+' is required</li></ul>');
                        that.addClass('validation-error');
                        errorCount++;
                    }
                    else if(inputId == 'email')
                    {
                        if(!validateEmail(inputVal))
                        {
                            that.after('<ul class="validation-errors-list filled error-msg text-danger"><li class="validation-required">Please enter valid email!</li></ul>');
                            that.addClass('validation-error');
                            errorCount++;
                        }
                    }
                });

                if(errorCount == 0)
                {
                    var name = jQuery('#name').val();
                    var email = jQuery('#email').val();
                    var phoneno = jQuery('#mobile').val();
                    var subject = jQuery('#subject').val();
                    var message = jQuery('#message').val();

                    if(grecaptcha.getResponse() == "") {

                        jQuery('#recaptchResponse').html('Please verify I am not robot ');

                    }else{

                    jQuery('#recaptchResponse').html('');

                    var formValue = new FormData();
                    formValue.append('name', name);
                    formValue.append('email', email);
                    formValue.append('phoneno', phoneno);
                    formValue.append('subject', subject);
                    formValue.append('message', message);

                    jQuery(".loader-form-submit").show();

                    jQuery.ajax({
                        type: "POST",
                        url: BASEURL+"form-submit.php",
                        data: formValue,
                        processData: false,
                        contentType: false,
                        success: function (data) {
                            jQuery(".loader-form-submit").hide();
                            jQuery('#responseMessage').removeClass('text-success').removeClass('text-danger');
                            if(data)
                            {
                                jQuery('#responseMessage').html('Information has been submitted successfully. Please be sure to check your spambox.').addClass('text-success').show('800');
                                jQuery('#name, #email, #mobile, #subject, #message').val('')
                                setTimeout(function(){
                                    jQuery('#responseMessage').hide('800').html('');
                                },5000)
                            }
                            else if(!data)
                            {
                                jQuery('#responseMessage').html('Information has not been submitted').addClass('text-danger').show('800');
                                setTimeout(function(){
                                    jQuery('#responseMessage').hide('800').html('');
                                },5000)
                            }
                            else
                            {
                                jQuery('#responseMessage').html('Information has not been submitted').addClass('text-danger').show('800');
                                setTimeout(function(){
                                    jQuery('#responseMessage').hide('800').html('');
                                },5000)
                            }
                        },
                        error: function (data) {
                            jQuery(".loader-form-submit").hide();
                            jQuery('#responseMessage').html('Please send all required parameter').removeClass('text-success').addClass('text-danger').show('800');
                            setTimeout(function(){
                                jQuery('#responseMessage').hide('800').html('');
                            },5000)
                        }
                    });
                    }
                }

        });




         jQuery(document).on('click', '#emailSubbtn', function(e){
                
                e.preventDefault();

                var errorCount = 0;
                jQuery('#emailsubForm .error-msg').remove(); // Remove Error Message
                jQuery('#emailsubForm').find('.req').each(function(){
                    var that = jQuery(this);
                    var inputVal = that.val();
                    var inputId = that.attr('id');
                    inputVal = jQuery.trim(inputVal);
                    that.removeClass('validation-error'); // Remove Class
                    
                    if(inputVal == '')
                    {
                        var palceHolderVal = that.attr('palceHolderVal');
                        jQuery('.subcribes').after('<ul class="validation-errors-list filled error-msg text-danger"><li class="validation-required">'+palceHolderVal+' is required</li></ul>');
                        that.addClass('validation-error');
                        errorCount++;
                    }
                    else if(inputId == 'es_email')
                    {
                        if(!validateEmail(inputVal))
                        {
                            that.after('<ul class="validation-errors-list filled error-msg text-danger"><li class="validation-required">Please enter valid email!</li></ul>');
                            that.addClass('validation-error');
                            errorCount++;
                        }
                    }
                });

                if(errorCount == 0)
                {
                    
                    var email = jQuery('#es_email').val();
                
                 /*   if(grecaptcha.getResponse() == "") {

                        jQuery('#recaptchResponse').html('Please verify I am not robot ');

                    }else{*/

                    //jQuery('#recaptchResponse').html('');

                    var formValue = new FormData();
                    formValue.append('email', email);

                    jQuery(".loader-form-submit").show();

                    jQuery.ajax({
                        type: "POST",
                        url: BASEURL+"form-submit-email.php",
                        data: formValue,
                        processData: false,
                        contentType: false,
                        success: function (data) {
                            jQuery(".loader-form-submit").hide();
                            jQuery('#responseMessage1').removeClass('text-success').removeClass('text-danger');
                            if(data)
                            {
                                jQuery('#responseMessage1').html('Information has been submitted successfully. Please be sure to check your spambox.').addClass('text-success').show('800');
                                jQuery('#email').val('')
                                setTimeout(function(){
                                    jQuery('#responseMessage1').hide('800').html('');
                                },5000)
                            }
                            else if(!data)
                            {
                                jQuery('#responseMessage1').html('Information has not been submitted').addClass('text-danger').show('800');
                                setTimeout(function(){
                                    jQuery('#responseMessage1').hide('800').html('');
                                },5000)
                            }
                            else
                            {
                                jQuery('#responseMessage1').html('Information has not been submitted').addClass('text-danger').show('800');
                                setTimeout(function(){
                                    jQuery('#responseMessage1').hide('800').html('');
                                },5000)
                            }
                        },
                        error: function (data) {
                            jQuery(".loader-form-submit").hide();
                            jQuery('#responseMessage1').html('Please send all required parameter').removeClass('text-success').addClass('text-danger').show('800');
                            setTimeout(function(){
                                jQuery('#responseMessage1').hide('800').html('');
                            },5000)
                        }
                    });
                    //}
                }
        });
        
</script>

    
</body>
</html>