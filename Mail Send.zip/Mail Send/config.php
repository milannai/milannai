﻿<?php
error_reporting(E_ALL);
// Database 
$host = 'localhost';
$username = 'aditya_wpxbyteio';
$password = '$S%Gm@jR=cXF';
$database = 'aditya_xbytewpio';

$conn = mysqli_connect($host, $username, $password, $database) or
 die("Connection failed: " . mysqli_connect_error());
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
} 

?>