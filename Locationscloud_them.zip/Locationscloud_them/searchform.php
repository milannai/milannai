<div class="search">
    <form action="<?php bloginfo('url'); ?>" method="get">
        <input class="searchText" type="text" name="s" value="Search here.." onfocus="this.value=(this.value=='Search here..') ? '' : this.value;" onblur="this.value=(this.value=='') ? 'Search here..' : this.value;" />
        <input class="searchBtn" type="submit" alt="Search" value="Search" />
        <div class="clear"></div>
    </form>
</div>
