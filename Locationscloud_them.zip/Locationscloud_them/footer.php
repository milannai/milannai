<footer class="main-footer">            
            <div class="container">
                <div class="widgets-section">
                    <div class="row clearfix">
                        <div class="footer-column col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                                <div class="col-md-8 col-sm-12 col-xs-12 margin-top-75">
                                    <span class="text-lg">We can help you build what you have been thinking about.</span>
                                    <p>Just talk to us about how we can utilize an inclined approach to test your ideas before you create more.</p>
                                    <a href="" class="theme-btn btn-style-four">Work with us</a>
                                </div>
                                <div class="col-md-4 col-sm-12 col-xs-12 xs-mt-50">
                                    <div class="text-center">
                                        <img src="">
                                    </div>
                                </div>
                            </div>
                            <div class="row ft-middle">
                                <div class="col-lg-3 col-md-3 col-sm-3 xs-padding-left-0 xs-padding-right-0">
                                    <h3 data-target="#collapse_ft_1" class="" data-toggle="collapse">Company</h3>
                                    <div class="collapse dont-collapse-sm" id="collapse_ft_1">
                                        <ul class="links">
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">About us</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Services</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Projects</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Benefits</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 xs-padding-left-0 xs-padding-right-0">
                                    <h3 data-target="#collapse_ft_2" data-toggle="collapse">Solutions</h3>
                                    <div class="collapse dont-collapse-sm" id="collapse_ft_2">
                                        <ul class="links">
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">eCommerce</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Online Travel</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Business Directory</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Social Media</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 xs-padding-left-0 xs-padding-right-0">
                                    <h3 data-target="#collapse_ft_3" data-toggle="collapse">Services</h3>
                                    <div class="collapse dont-collapse-sm" id="collapse_ft_3">
                                        <ul class="contacts">
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Custom Web Scraping Service</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Cloud Based Web Scraping</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Python Web Scraping</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">Mobile App Scraping</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 xs-padding-left-0 xs-padding-right-0">
                                    <h3 data-target="#collapse_ft_4" data-toggle="collapse">Contact</h3>
                                    <div class="collapse dont-collapse-sm" id="collapse_ft_4">
                                        <ul class="contacts">
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">info@locationscloud.com</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">+91 917-372-9962 (India)</a></li>
                                            <li class="margin-bottom-5"><a href="#" class="color-black font-size-13">+1 (832) 251 7311 (USA)</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="row clearfix ft-btm margin-top-30">
                                <div class="col-md-6 col-sm-6 col-xs-8 sm-padding-left-0 sm-padding-right-0">
                                    <ul>
                                        <li class="font-size-14 xs-margin-bottom-10 color-black font-weight-500">© Locations Cloud 2019.</li>
                                        <li><a href="">Privacy Policy</a></li>
                                        <li><a href="">Contact</a></li>
                                    </ul>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-4 sm-padding-left-0 sm-padding-right-0">
                                    <ul class="social-media text-right">
                                        <li><a href="" target="_blank">Linkedin</a></li>
                                        <li><a href="" target="_blank">Twitter</a></li>
                                        <li><a href="" target="_blank">Facebook</a></li>
                                        <li><a href="" target="_blank">Instagram</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>

<?php wp_footer(); ?>

</body>
</html>