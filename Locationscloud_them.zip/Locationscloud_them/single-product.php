<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post();

    global $product;

   //echo "<pre>";print_r($product);exit();
   // echo $product->get_category_ids();exit();
   
 ?>

      <div class="section-1 pt-135 pb-30 bg-gray">
                    <div class="container">
                
                        <div class="col-md-12 col-sm-12 col-xs-12 sm-padding-left-0 sm-padding-right-0">
                            <div class="margin-top-30">
                                <div>
                                    <div class="d-flex justify-content-space-between">
                                        <div class="xs-margin-bottom-20">
                                            <!-- <span class="color-black margin-right-10 font-size-28"><a href="<?php echo get_home_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></span>
                                            <span class="color-black font-size-18">Categories / <a href="#" class="font-weight-bold color-blue">All Stores</a></span> -->
                                            <span class="color-black margin-right-10 font-size-28"><a href="<?php echo get_home_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></span>
                                            <span class="color-black font-size-18"><a class="font-weight-bold color-blue" href="<?php echo get_site_url(); ?>/all-data">All Stores</a> >  <?php echo get_the_title(); ?></span>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
         
       
    
    <div class="section-2 pt-100 pb-100 mb-100">
        <div class="container">
            <div class="col-md-12 col-sm-12 col-xs-12 pdding-left-0 padding-right-0 sm-text-center sm-padding-left-0 sm-padding-right-0">

                <div class="col-md-9 col-sm-12 col-xs-12">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <div class="zoom-effect-container">
                                <div class="image-card">
                                    <?php echo $product->get_image(); ?>
                                    <!-- <img src="<?php echo get_template_directory_uri(); ?>/images/5a0c75949642de34b6b65cfc.png"> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <div class="sm-margin-100">
                                <h2 class="lft-heading"><?php echo $product->get_name(); ?></h2>
                            </div>
                            <div class="text-price">
                                <span class="font-weight-bold"><?php echo get_woocommerce_currency_symbol().$product->get_regular_price(); ?></span>
                            </div>
                            <div>
                                <label class="lbl-info">Number of store locations available for <br /> download in this dataset are <span class="color-blue"><?php echo get_field('dataset_number'); ?></span> <br />This data set was last updated <br />on <span class="color-blue"><?php echo date('F j, Y',strtotime("-1 days")); ?></span></label>
                            </div>
                            <div>
                                <div class="btn-pos" data-toggle="modal" data-target="#getInModal"><button>Get in Touch</button></div>
                            </div>

                        </div>
                    </div>

                    <div>
                        <div class="btn-discription"><button>Description</button></div>
                        <div class="text-info-img">
                            <p class="color-black"><?php echo $product->get_description(); ?></p>
                        </div>
                        <!--<div class="btn-download"><a href="#" class="btn btn-primary">Download Sample</a></div>-->
                        
                            <div class="text-right">
                                <div>
                                    <button type="button" class="btn btn-primary btn-lg btn-download-sample" data-toggle="modal" data-target="#myModal">Download Sample</button>
                                </div>
                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal" role="dialog">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="btn btn-default float-right" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                                                    <h2 class="lft-heading-about">Do you want to download this database?</h2>
                                                    <div class="text-center">
                                                        <span>
                                                            Fill out the form below and we will get in touch shortly.
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="modal-body popup-contact-main">
                                                   <?php echo do_shortcode('[contact-form-7 id="66" title="Popup Contact form"]'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="modal fade" id="getInModal" role="dialog">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="btn btn-default float-right" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                                                    <h2 class="lft-heading-about">Do you want to download this database?</h2>
                                                    <div class="text-center">
                                                        <span>
                                                            Fill out the form below and we will get in touch shortly.
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="modal-body popup-contact-main">
                                                   <?php echo do_shortcode('[contact-form-7 id="84" title="Product inquiry"]'); ?>
                                                </div>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                        </div>

                    <div>
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/slider1.png" alt="First slide">
                                    <div class="carousel-caption">
                                        <h2 class="color-gray xs-font-size-14">
                                            Over Web,Mobile,Cloud & IoT, for businesses globally.
                                        </h2>
                                        <a href="#" class="btn-learn">Learn More</a>
                                    </div>
                                </div>
                                <div class="item">
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/slider2.png" alt="Second slide">
                                    <div class="carousel-caption">
                                        <h2 class="color-gray xs-font-size-14">
                                            Over Web,Mobile,Cloud & IoT, for businesses globally.
                                        </h2>
                                        <a href="#" class="btn-learn">Learn More</a>
                                    </div>
                                </div>
                                <div class="item">
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/slider3.png" alt="Third slide">
                                    <div class="carousel-caption">
                                        <h2 class="color-gray xs-font-size-14">
                                            Over Web,Mobile,Cloud & IoT, for businesses globally.
                                        </h2>
                                        <a href="#" class="btn-learn">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a><a class="right carousel-control"
                                   href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right">
                                </span>
                            </a>
                        </div>
                    </div>
                </div>



                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div>
                        <ul>
                             <li class="listinfo-datastore">
                                <a href="<?php echo get_site_url(); ?>/all-data" class="color-black">All Store</a>
                                <span>(<?php echo do_shortcode('[product_count]'); ?>)</span>
                            </li>
                             <?php

                              $taxonomy     = 'product_cat';
                              $orderby      = 'name';  
                              $show_count   = 0;      // 1 for yes, 0 for no
                              $pad_counts   = 0;      // 1 for yes, 0 for no
                              $hierarchical = 1;      // 1 for yes, 0 for no  
                              $title        = '';  
                              $empty        = 0;

                              $args = array(
                                     'taxonomy'     => $taxonomy,
                                     'orderby'      => $orderby,
                                     'show_count'   => $show_count,
                                     'pad_counts'   => $pad_counts,
                                     'hierarchical' => $hierarchical,
                                     'title_li'     => $title,
                                     'hide_empty'   => $empty
                              );
                             $all_categories = get_categories( $args );
                             foreach ($all_categories as $cat) {
                                if($cat->category_parent == 0) {
                                    $category_id = $cat->term_id;       
                                    //echo '<br /><a href="'. get_term_link($cat->slug, 'product_cat') .'">'. $cat->name .'</a>'; 

                                    if($cat->cat_name != 'Uncategorized'){
                                    ?>

                                    <li class="listinfo-datastore">
                                        <a href="<?php echo get_term_link($cat->slug, 'product_cat'); ?>" class="color-black"><?php echo $cat->name; ?></a>
                                        <span>(<?php echo $cat->count; ?>)</span>
                                    </li>

                                <?php

                                    }
                                   /* $args2 = array(
                                            'taxonomy'     => $taxonomy,
                                            'child_of'     => 0,
                                            'parent'       => $category_id,
                                            'orderby'      => $orderby,
                                            'show_count'   => $show_count,
                                            'pad_counts'   => $pad_counts,
                                            'hierarchical' => $hierarchical,
                                            'title_li'     => $title,
                                            'hide_empty'   => $empty
                                    );
                                    $sub_cats = get_categories( $args2 );
                                    if($sub_cats) {
                                        foreach($sub_cats as $sub_category) {
                                            echo  $sub_category->name ;
                                        }   
                                    }*/
                                }       
                            }
                            ?>
                          
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-3 pt-70 pb-70 bg-gray">
        <div class="container">
            <div>
                <h2 class="lft-heading-about">Fields We Provide</h2>
                <p class="text-center">
                    Data takes you in the right direction, be it starting a business or in day-to-day <br> decisions or for expansion.We can empower you with the right data.
                </p>
            </div>
            <div class="row pt-40">
                <?php

                    $provideFieldsAll = get_field_object('field_5d6515827214f');
                    $provideFields = $provideFieldsAll['value'];
                   // echo "<pre>";print_r($field);
                    foreach ($provideFields as $key => $value) { 
                ?>
                     <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black"><?php echo $value; ?></span>
                        </div>
                    </div>
             <?php } ?>

            </div>
        </div>
    </div>

     <?php // echo do_shortcode("[woo-related title='no']"); ?>


<div class="section-4 pt-100">
    <div class="container">
        <div>
            <h2 class="lft-heading-about">Related Products</h2>
        </div>
        <div class="row margin-top-30">
            <div class="col-md-12 heroSlider-fixed">
                <div class="overlay">
                </div>
                <!-- Slider -->
                <div class="slider responsive">
                   
                        	    <?php 

                                $sortcolumn = 'ID';
                                $prod_categories = $product->get_category_ids();
                                $current_productId = $product->get_id();

                              
                                
                                $product_args = array(
                                    'numberposts' => -1,
                                    'post_status' => array('publish', 'pending', 'private', 'draft'),
                                    'post_type' => array('product', 'product_variation'), //skip types
                                    'order' => 'ASC',
                                );

                                if (!empty($prod_categories)) {
                                    $product_args['tax_query'] = array(
                                        array(
                                            'taxonomy' => 'product_cat',
                                            'field' => 'id',
                                            'terms' => $prod_categories,
                                            'operator' => 'IN',
                                    ));
                                }

                                $related_products = get_posts($product_args);
                                //echo "<pre>";print_r($related_products);exit();

                                foreach ($related_products as $related_product) { 
                                            
                                        $_product = wc_get_product( $related_product->ID );

                                        $related_productId = $_product->get_id();

                                        if($current_productId != $related_productId){
                                        
                                    ?>

                            <div class="col-item">
                                <div class="photo">
                                    <div class="pricing-list">
                                        <a href="<?php echo get_permalink( $_product->get_id() ); ?>"><div><?php echo $_product->get_image(); ?></div>
                                        <div><h3><?php echo $_product->get_name(); ?></h3></div></a>
                                        <div><span><?php echo get_woocommerce_currency_symbol().$_product->get_regular_price(); ?></span></div>
                                        <a href="<?php echo get_permalink( $_product->get_id() ); ?>"><div class="btn-pos"><button>View More</button></div></a>
                                    </div>
                                </div>
                            </div>
                       	<?php } } ?>
                    
                  
                </div>
                <!-- control arrows -->
                <div class="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                </div>
                <div class="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $postid = get_the_ID(); ?>


<?php endwhile; endif; ?>

<script>
jQuery(document).ready(function(){
    var pageUrl = window.location.href;
    var sheetDownload = '<?php echo get_field("upload_sample_file", $postid) ?>';
    jQuery('#lcpage_hidden').val(pageUrl);
    jQuery('#lcsheet_hidden').val(sheetDownload);
  });
</script>

<?php get_footer(); ?>


