<!DOCTYPE html>
<html>
<head>
    <title><?php echo get_field('loc_page_title'); ?></title>
    <meta name="description" content="<?php echo get_field('loc_meta_description'); ?>" />
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="page-wrapper">
 <!--    <div class="preloader"></div> -->
    <div class="header">
        <div class="section-menu example2">
            <div class="container">
                <nav class="navbar navbar-default">
                    <div class="">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar top-bar"></span>
                                <span class="icon-bar middle-bar"></span>
                                <span class="icon-bar bottom-bar"></span>
                            </button>
                          
                            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="" title="">
                            </a>
                        </div>
                        <div id="navbar2" class="navbar-collapse collapse">
                              <?php 
                              $args = array(
                                    'theme_location' => 'header-menu',
                                    'menu' => 'top-menu',
                                    'menu_class' => 'nav navbar-nav navbar-right',
                                    'menu_id' => 'mainNav'
                                    );
                                wp_nav_menu( $args );  
                            ?>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>  