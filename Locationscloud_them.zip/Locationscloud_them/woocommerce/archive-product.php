<?php get_header();

defined( 'ABSPATH' ) || exit;
?>

 <div class="section-1 pt-135 pb-30 bg-gray">
            <div class="container">
              
                <div class="col-md-12 col-sm-12 col-xs-12 sm-padding-left-0 sm-padding-right-0">
                    <div class="margin-top-30">
                        <div>
                            <div class="d-flex justify-content-space-between">
                                <div class="xs-margin-bottom-20">
                                    <span class="color-black margin-right-10 font-size-28"><a href="<?php echo get_home_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></span>
                                    <span class="color-black font-size-18">All Stores</span>
                                </div>
                                <?php echo do_shortcode('[aws_search_form]'); ?>
                            </div>                          
                        </div>
                    </div>
                </div>
            </div>
        </div>

         <div class="section-2 pt-100 pb-100">
            <div class="container">
                <div class="col-md-12 col-sm-12 col-xs-12 pdding-left-0 padding-right-0 sm-padding-left-0 loc-all-data">
                  
                    <div class="col-md-9 col-sm-12 col-xs-12 sm-padding-right-15 sm-margin-top-30 sm-padding-left-0 sm-padding-right-0">

                        <?php
                        if ( woocommerce_product_loop() ) {

                            /**
                             * Hook: woocommerce_before_shop_loop.
                             *
                             * @hooked woocommerce_output_all_notices - 10
                             * @hooked woocommerce_result_count - 20
                             * @hooked woocommerce_catalog_ordering - 30
                             */
                            do_action( 'woocommerce_before_shop_loop' );

                            woocommerce_product_loop_start();

                            if ( wc_get_loop_prop( 'total' ) ) {
                                while ( have_posts() ) {
                                    the_post(); 

                                    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
                                    ?>

                                        <div class="col-md-4 col-sm-6 col-xs-12">
                                            <div class="pricing-list">
                                                <div><a href="<?php echo get_the_permalink(); ?>"><img src="<?php  echo $image[0]; ?>"></a></div>
                                                <div><a href="<?php echo get_the_permalink(); ?>"><h3><?php echo get_the_title(); ?></h3></a></div>
                                                <div class="margin-bottom-10"><span><?php echo $product->get_price_html(); ?></span></div>
                                                <a href="<?php echo get_the_permalink(); ?>"><div class="btn-pos"><button>View More</button></div></a>
                                            </div>
                                        </div>
                                        
                                    <?php    
                                    do_action( 'woocommerce_shop_loop' );

                                }
                            }

                            woocommerce_product_loop_end();

                            /**
                             * Hook: woocommerce_after_shop_loop.
                             *
                             * @hooked woocommerce_pagination - 10
                             */
                            do_action( 'woocommerce_after_shop_loop' );
                        } else {
                            /**
                             * Hook: woocommerce_no_products_found.
                             *
                             * @hooked wc_no_products_found - 10
                             */
                            do_action( 'woocommerce_no_products_found' );
                        }

                        ?>

                      
                    </div>

                      <div class="col-md-3 col-sm-12 col-xs-12 sm-padding-left-15">
                        <div>
                            <ul>

                            <li class="listinfo-datastore">
                                <a href="<?php echo get_site_url(); ?>/all-data" class="color-black">All Store</a>
                                <span>(<?php echo do_shortcode('[product_count]'); ?>)</span>
                            </li>   

                            <?php
                              $taxonomy     = 'product_cat';
                              $orderby      = 'name';  
                              $show_count   = 0;      // 1 for yes, 0 for no
                              $pad_counts   = 0;      // 1 for yes, 0 for no
                              $hierarchical = 1;      // 1 for yes, 0 for no  
                              $title        = '';  
                              $empty        = 0;

                              $args = array(
                                     'taxonomy'     => $taxonomy,
                                     'orderby'      => $orderby,
                                     'show_count'   => $show_count,
                                     'pad_counts'   => $pad_counts,
                                     'hierarchical' => $hierarchical,
                                     'title_li'     => $title,
                                     'hide_empty'   => $empty
                              );
                             $all_categories = get_categories( $args );
                             foreach ($all_categories as $cat) {
                                if($cat->category_parent == 0) {
                                    $category_id = $cat->term_id;       
                                    //echo '<br /><a href="'. get_term_link($cat->slug, 'product_cat') .'">'. $cat->name .'</a>'; 

                                    if($cat->cat_name != 'Uncategorized'){
                                    ?>

                                <li class="listinfo-datastore">
                                    <a href="<?php echo get_term_link($cat->slug, 'product_cat'); ?>" class="color-black"><?php echo $cat->name; ?></a>
                                    <span>(<?php echo $cat->count; ?>)</span>
                                </li>
                               
                                 <?php

                                    }
                                  
                                }       
                            }
                            ?>

                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
         




<?php get_footer(); ?>