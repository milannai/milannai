<?php
/**
 * Template Name: Home Page
*/

get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post();

 ?>

     <div class="section-1 pb-100 pt-100 sm-padding-top-20" id="home">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="about-info margin-top-15">
                            <div>
                                <p class="text-justify">
                                    Useful Business Store Location Data to Support Your Tactical Business Decisions
                                </p>
                            </div>
                            <div class="margin-bottom-30 margin-top-5">
                                <?php echo do_shortcode("[osd_subscribe categories='uncategorized' placeholder='Email Address' button_text='Get Started Now!']");  ?>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-12 col-xs-12 text-right xs-mt-30 sm-text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/datastore_hero_gif.gif">
                    </div>
                </div>
            </div>
        </div>

        <div class="section-2 pt-70 pb-150 bg-gray" id="aboutus">
            <div class="container">
                <div class="row">
                    <div>
                        <h2 class="lft-heading-about">Empower You with the Right Data</h2>
                        <p class="text-center margin-bottom-0">
                            Buy more than 2.5 million business store location on various sectors like E-commerce, Restaurants, Retail, Real Estate, Automobile, and more. </p>
                        <p class="text-center">We can empower you with the right data.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="section-3 pb-100">
            <div class="container">
                <div>
                    <div class="row">
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="Empower-data text-center">
                                <div>
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/Quality.png" />
                                </div>
                                <div><h3>Quality</h3></div>
                                <div><p>We offer retail store location data of best quality and high accuracy which is fresh, updated, and most appropriate for your business requirements.</p></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="Empower-data text-center">
                                <div>
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/Convenient.png" />
                                </div>
                                <div><h3>Convenient</h3></div>
                                <div><p>All you have to do is provide us your data requirement and we will deliver it in an easy-to-use CSV format.</p></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="Empower-data text-center">
                                <div>
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/update.png" />
                                </div>
                                <div><h3>Updated</h3></div>
                                <div><p>Data location is well-researched & updated with a 30, 60, or 90-days cycle to provide you the latest and ready-to-use information.</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section-4">
            <section id="banner-header-data-location" class="banner-header">
                <div class="inner">
                    <div class="copy">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="data-location border-right">
                                        <h3>2.8 Million+</h3>
                                        <span>Locations</span>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="data-location border-right">
                                        <h3>3000+</h3>
                                        <span>Companies</span>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="data-location">
                                        <h3>120+</h3>
                                        <span>Industries</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="section-5 pt-100 pb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="margin-top-20-per">
                            <div><h2 class="lft-heading-about">Industries We Serve </h2></div>
                            <div><p>Whether you are looking for the list of fast food restaurants, list of department stores, or a retail store database, we can energize you with the required data.</p></div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-12 col-xs-12"></div>
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div>
                            <ul class="industries">
                                <li>
                                    <div class="d-flex">
                                       <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/food_ser.png" class="margin-right-30" /></span><label class="lbl-indusries">Accommodation & Food Services</label></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="d-flex">                                       
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/art.png" class="margin-right-30" /></span><label class="lbl-indusries">Art, Entertainment, and Recreation</label></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/finance.png" class="margin-right-30" /></span><label class="lbl-indusries">Finance & Insurance</label></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/health.png" class="margin-right-30" /></span><label class="lbl-indusries">Healthcare & Social Assistance</label></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/information.png" class="margin-right-30" /></span><label class="lbl-indusries">Information</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/lab.png" class="margin-right-30" /></span><label class="lbl-indusries">Professional, Technical, and Scientific</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/realestate.png" class="margin-right-30" /></span><label class="lbl-indusries">Real Estate Rental & Leasing</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/retailtade.png" class="margin-right-30" /></span><label class="lbl-indusries">Retail Trade</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/transpotation.png" class="margin-right-30" /></span><label class="lbl-indusries">Transportation & Warehousing</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/utilities.png" class="margin-right-30" /></span><label class="lbl-indusries">Utilities</label></div>
                                    </div>
                                </li>
								<li>
                                    <div class="d-flex">                                        
                                        <div><span><img src="<?php echo get_template_directory_uri(); ?>/images/wholesaler.png" class="margin-right-30"/></span><label class="lbl-indusries">Wholesale Trade</label></div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="section-6 pt-70 pb-70 bg-gray" id="KeyAttributes">
            <div class="container">
                <div>
                    <h2 class="lft-heading-about">Our List of Key Attributes</h2>
                    <p class="text-center margin-bottom-0">Here is the list of key attributes that we provide in our professional store location data services:</p>
                    <p class="text-center">We can empower you with the right data.</p>
                </div>
                <div class="row pt-40">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Store Name</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Address</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Fax</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Phone</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Services Given</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Amenities Accessible</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Hours of Operations</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Payment Options</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Latitude & Longitude</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Website</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Contact Person</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Email ID</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Year Established</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Social Media Presence</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Products</span>
                        </div>
                    </div>
					<div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="list-attribute">
                            <span class="color-black">Category</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="section-7 pt-100 pb-50" id="OurPlans">
            <div class="container">
                <div>
                    <h2 class="lft-heading-about">Our Plans</h2>
                    <p class="text-center">
                        At iWeb Scraping, we have plans for every requirement, whether it’s daily, weekly, monthly, or Enterprise Scraping.
                    </p>
                </div>
                <div class="tabbed" style="display:none;">
                    <input type="radio" name="tabs" id="tab-nav-2" checked>
                    <label for="tab-nav-2">Monthly</label>
                    <input type="radio" name="tabs" id="tab-nav-3">
                    <label for="tab-nav-3">Weekly</label>
                    <div class="tabs">
                        <div><p>Pricing may vary depending on the complexity of websites, IP Blocking, and Customization required.</p></div>
                        <div class="w-100">
                            <table class="table margin-top-15">
                                <thead>
                                    <tr>
                                        <th>Features</th>
                                        <th>Once off Scrape (Per Site)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Basic Cost</td>
                                        <td>$45 - $199</td>
                                    </tr>
                                    <tr>
                                        <td>Pages/Listings Crawled</td>
                                        <td>Upto 30K</td>
                                    </tr>
                                    <tr>
                                        <td>Number Of Data Fields</td>
                                        <td>Unlimited</td>
                                    </tr>
                                    <tr>
                                        <td>Data Delivery Format</td>
                                        <td>Unlimited</td>
                                    </tr>
                                    <tr>
                                        <td>Data Storage Period</td>
                                        <td>15 Days</td>
                                    </tr>
                                    <tr>
                                        <td>Customized Output Schema Format</td>
                                        <td>Yes</td>
                                    </tr>
                                    <tr>
                                        <td>Multiple Delivery Options</td>
                                        <td>Yes</td>
                                    </tr>
                                    <tr>
                                        <td>Data Visualization</td>
                                        <td>Yes</td>
                                    </tr>
                                    <tr>
                                        <td>Custom Data Export</td>
                                        <td>Yes</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="w-100">
                            <div class="w-100">
                                <table class="table margin-top-15">
                                    <thead>
                                        <tr>
                                            <th>Features</th>
                                            <th>Once off Scrape (Per Site)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Basic Cost</td>
                                            <td>$45 - $199</td>
                                        </tr>
                                        <tr>
                                            <td>Pages/Listings Crawled</td>
                                            <td>Upto 30K</td>
                                        </tr>
                                        <tr>
                                            <td>Number Of Data Fields</td>
                                            <td>Unlimited</td>
                                        </tr>
                                        <tr>
                                            <td>Data Delivery Format</td>
                                            <td>Unlimited</td>
                                        </tr>
                                        <tr>
                                            <td>Data Storage Period</td>
                                            <td>15 Days</td>
                                        </tr>
                                        <tr>
                                            <td>Customized Output Schema Format</td>
                                            <td>Yes</td>
                                        </tr>
                                        <tr>
                                            <td>Multiple Delivery Options</td>
                                            <td>Yes</td>
                                        </tr>
                                        <tr>
                                            <td>Data Visualization</td>
                                            <td>Yes</td>
                                        </tr>
                                        <tr>
                                            <td>Custom Data Export</td>
                                            <td>Yes</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-md-3 col-sm-12 col-xs-12"></div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="our-plans">
                            <div class="header">
                                <sapn class="font-size-32">Custom Plan</sapn><br />
                                <span>Fully customizable plan</span>
                            </div>
                            <div class="body">
                                <h1 class="color-blue-varies">Varies</h1>
                                <p>Billed Monthly</p>
                                <p>Includes any number of Brands</p>
                                <p>Includes any number of Countries</p>
                                <p>Includes any number of Locations</p>
                                <p>Updated on a custom schedule</p>
                                <a href="#" class="btn btn-primary contact-info">Contact</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12"></div>
                </div>

            </div>
        </div>
        <div class="section-8 pb-50">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 col-sm-12 col-xs-12"></div>
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <div class="need-more">
                            <div class="col-md-4 col-sm-12 col-xs-12">
                                <h2 class="lft-heading-about-needmore">Need More Information?</h2>
                            </div>
                            <div class="col-md-8 col-sm-12 col-xs-12">
                                <h2 class="lft-heading-about-contact">Call us on +1 (832) 251 7311 / +91(79) 403 924 66</h2>
                                <div><button>Get Free Quote</button></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-12 col-xs-12"></div>
                </div>
            </div>
        </div>
        <div class="section-9 pt-50 pb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="margin-top-35-per">
                            <div><h2 class="lft-heading-about">Our Data is Broadly Used in</h2></div>
                            <div><p>Data takes you in the right direction,be it starting a business or in day decisions or for expansion. We can empower you with the data.</p></div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-12 col-xs-12"></div>
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="our-data">
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Competitive Analysis</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Market share Analysis</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Site Selection</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Mapping Services</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Marketing Campaigns</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Sales Campaigns</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">Business Directives</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">App Integration</p></div>
							<div class="d-flex font-size-18 padding-left-40"><span><i class="fa fa-check color-theme-checked margin-right-20" aria-hidden="true"></i></span><p class="text-justify color-black font-weight-600">US Store Locations Data</p></div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section-10 pt-70 pb-70 bg-gray">
            <div class="container">
                <div>
                    <h2 class="lft-heading-about">We Offer the Best Pricing Online for Store Location Data</h2>
                    <p class="text-center margin-bottom-0">
                        Still not convinced? You can compare our pricing with others to get an exact idea about our affordable store location data services.</p>
                   
                </div>
                <div class="row margin-top-40">


                    <?php
                        $args = array(
                            'post_type' => 'product',
                            'posts_per_page' => 8
                            );
                        $loop = new WP_Query( $args );
                        if ( $loop->have_posts() ) {
                            while ( $loop->have_posts() ) : $loop->the_post();
                                global $product;
                               // echo "<pre>";print_r($loop);exit();
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
                             ?>



                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="pricing-list">
                                        <div><a href="#"><img src="<?php  echo $image[0]; ?>" /></a></div>
                                        <div><a href="<?php echo get_the_permalink(); ?>"><h3><?php echo get_the_title(); ?></h3></a></div>
                                        <div class="margin-bottom-5"><span><?php echo $product->get_price_html(); ?></span></div>
                                        <a href="<?php echo get_the_permalink(); ?>"><div class="btn-pos"><button>View More</button></div></a>
                                    </div>
                                </div>

                                <?php 

                            endwhile;
                        } else {
                            echo __( 'No products found' );
                        }
                        wp_reset_postdata();
                    ?>


                </div>
                <div class="row">
                    <div class="margin-top-20 text-center"><a href="#" class="btn btn-primary">View All DataBase</a></div>
                </div>
            </div>
        </div>

        <div class="section-11 pt-100 pb-50" id="ContactUs">
            <div class="container">
                <div>
                    <h2 class="lft-heading-about">Looking for a more detailed dataset?</h2>
                    <p class="text-center">
                        Just fill the form below and we will contact you shortly.
                    </p>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="col-md-2 col-sm-12 col-xs-12">

                    </div>
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <div>
                            <div class="margin-top-20">
                             <?php echo do_shortcode('[contact-form-7 id="23" title="Contact form"]'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-12 col-xs-12">
                    </div>
                </div>
                
            </div>
        </div>


<?php endwhile; endif; ?>

<?php get_footer(); ?>