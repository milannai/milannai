jQuery(document).foundation();

// below does the "Programs" info switch
jQuery('.is-hover a').on('mouseover', function () {
  var idx = jQuery(this).parent().index() + 2;
  jQuery('.info:nth-child(' + idx + ')').addClass('info-visible');
  jQuery('.info:nth-child(' + idx + ')').siblings().removeClass('info-visible');
});

jQuery('.dropdown').on('mouseout', function () {
  jQuery('.info:nth-child(1)').addClass('info-visible').siblings().removeClass('info-visible');
});

/*menu responsive js screen size start*/
jQuery(document).ready(function(){
	jQuery(".toggle-topbar.menu-icon").click(function(){
		if(jQuery(window).width()<=800 && $(window).width()>425){
			jQuery(".top-bar").toggleClass("expanded");
		}	
	});
});
/*menu responsive js screen size End*/