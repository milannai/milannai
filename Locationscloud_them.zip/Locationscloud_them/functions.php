<?php

//$start_wp_theme_tmp

/*if ( function_exists( 'add_theme_support' ) ) {  
add_theme_support( 'post-thumbnails' );  
}*/

add_theme_support( 'post-thumbnails' );

// Add default posts and comments RSS feed links to head.
add_theme_support( 'automatic-feed-links' );

/*
 * Let WordPress manage the document title.
 * By adding theme support, we declare that this theme does not use a
 * hard-coded <title> tag in the document head, and expect WordPress to
 * provide it for us.
 */
add_theme_support( 'title-tag' );  

/*
 * Switch default core markup for search form, comment form, and comments
 * to output valid HTML5.
 */
add_theme_support(
    'html5',
    array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    )
);    

/**
 * Add support for core custom logo.
 *
 * @link https://codex.wordpress.org/Theme_Logo
 */
add_theme_support(
    'custom-logo',
    array(
        'height'      => 190,
        'width'       => 190,
        'flex-width'  => false,
        'flex-height' => false,
    )
);  


// Add theme support for selective refresh for widgets.
add_theme_support( 'customize-selective-refresh-widgets' );

// Add support for Block Styles.
add_theme_support( 'wp-block-styles' );

// Add support for full and wide align images.
add_theme_support( 'align-wide' );

// Add support for editor styles.
add_theme_support( 'editor-styles' );

function mytheme_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );


/* include theme commun codes */
include("functions/theme_commun_code.php");
/* end of include theme commun codes */

/* include theme widget area */
include("functions/theme_widget_areas.php");
/* end of include theme widget area */

/* include the Menu Registration page */
include("functions/register_menus.php");
/* end of include the Menu Registration page */

/* include the option page */
include("functions/theme_option_page.php");
/* end of include the option page */

/* Include the custom post type */
include("functions/custom_post_type.php");
/*end ov Include the custom post type*/

/* Include the theme's custom functions */
include("functions/theme_custom_functions.php");
/*end of theme's custom functions */

/* Include the theme's custom widgets */
include("functions/widgets.php");
/*end of theme's custom widgets */

/* Include the theme's custom users */
include("functions/custom_users.php");
/*end of theme's custom users */



function register_multiko_menu() {
  register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_multiko_menu' );


/*wp_deregister_script('jquery');
wp_register_script('jquery', 'https://code.jquery.com/jquery-2.2.4.js', false, '2.2.4');
wp_enqueue_script('jquery');*/

function enqueue_locationscloud_style() {
	
    wp_enqueue_style( 'main-style', get_stylesheet_uri() );

	wp_enqueue_style('normalize-min-css', 'https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css');
	wp_enqueue_style('foundation-css', 'https://cdn.jsdelivr.net/foundation/5.5.0/css/foundation.css');
	wp_enqueue_style('font-awesome-min-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
	wp_enqueue_style('bootstrap-css', get_template_directory_uri() .'/css/bootstrap.css');
	wp_enqueue_style('style-css', get_template_directory_uri() .'/css/style.css');
	wp_enqueue_style('custom-css', get_template_directory_uri() .'/css/custom.css');
	wp_enqueue_style('responsive-css', get_template_directory_uri() .'/css/responsive.css');
	wp_enqueue_style('menu1-css', get_template_directory_uri() .'/css/menu1.css');
    wp_enqueue_style('slick-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.5/slick.min.css');
    wp_enqueue_style('databaselisting-css', get_template_directory_uri() .'/css/databaselisting.css');
    wp_enqueue_style('databaselisting-innerpage-css', get_template_directory_uri() .'/css/databaselisting-innerpage.css');


	//wp_enqueue_style('contact-custom-css', get_template_directory_uri() .'/css/contact-custom.css');

	

	//wp_enqueue_script('jquery-min-js', get_template_directory_uri() . '/js/jquery-1.12.2.min.js', '', '', true);
    wp_enqueue_script('main-jquery', get_template_directory_uri() . '/js/jquery.js', '', '', true);
    wp_enqueue_script('bootstrap-min-js', get_template_directory_uri() . '/js/bootstrap.min.js', '', '', true);
    wp_enqueue_script('jquery-fancybox-js', get_template_directory_uri() . '/js/jquery.fancybox.js', '', '', true);
    wp_enqueue_script('jquery-ui-js', get_template_directory_uri() . '/js/jquery-ui.js', '', '', true);
    wp_enqueue_script('owl-js', get_template_directory_uri() . '/js/owl.js', '', '', true);
    wp_enqueue_script('appear-js', get_template_directory_uri() . '/js/appear.js', '', '', true);
    wp_enqueue_script('wow-js', get_template_directory_uri() . '/js/wow.js', '', '', true);
    wp_enqueue_script('script-js', get_template_directory_uri() . '/js/script.js', '', '', true);
    wp_enqueue_script('foundation-js', 'https://cdnjs.cloudflare.com/ajax/libs/foundation/5.5.0/js/foundation.min.js', '', '', true);
    wp_enqueue_script('menu-js', get_template_directory_uri() . '/js/menu.js', '', '', true);
    wp_enqueue_script('menuItemScroll-js', get_template_directory_uri() . '/js/menuItemScroll.js', '', '', true);
    wp_enqueue_script('maps-key', 'http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o', '', '', true);
    wp_enqueue_script('map-script-js', get_template_directory_uri() . '/js/map-script.js', '', '', true);
    wp_enqueue_script('slick-main-js', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.5/slick.min.js', '', '', true);
    wp_enqueue_script('slick-js', get_template_directory_uri() . '/js/slick.js', '', '', true);
}
add_action('wp_enqueue_scripts', 'enqueue_locationscloud_style');


add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 20 );
function new_loop_shop_per_page( $cols ) {
  // $cols contains the current number of products per page based on the value stored on Options -> Reading
  // Return the number of products you wanna show per page.
  $cols = 9;
  return $cols;
}

function product_count_shortcode( ) {
	$count_posts = wp_count_posts( 'product' );
	return $count_posts->publish;
}
add_shortcode( 'product_count', 'product_count_shortcode' );

function SearchFilter($query) {
if ( !is_admin() && $query->is_search ) {
$query->set('post_type', 'post'); // OR USE 'PRODUCT'
}
return $query;
}
  
add_filter( 'pre_get_posts', 'SearchFilter' );


/* Contact form 7 Sample file download */


/*                //add_filter('wpcf7_skip_mail', 'abort_mail_sending');


                    add_action( 'wpcf7_before_send_mail', 'my_change_subject_mail' );
                    function my_change_subject_mail($WPCF7_ContactForm)
                    {
                    $wpcf7 = WPCF7_ContactForm :: get_current() ;
                    $submission = WPCF7_Submission :: get_instance() ;
                    if ($submission)
                    {
                    $posted_data = $submission->get_posted_data() ;
                    // nothing's here... do nothing...
                    if ( empty ($posted_data))
                    return ;
                    //$subject = $posted_data['your-message'];
                    
                    if( !empty($posted_data["sd-email"])){  //use a field unique to your form

                           $email = trim($posted_data["sd-email"]);
                           // more custom stuff here

                           $file_id = get_field('upload_sample_file');

                           

                                    //$subject = substr($this->replace_tags( $template['subject'] ), 0, 50);
                            // do some replacements in the cf7 email body
                            $mail = $WPCF7_ContactForm->prop('mail_2') ;
                            $mail['body'] .= "<p>Greetings from X-Byte.</p>";
                            $mail['body'] = "<p>Hello ".$file_id.",</p>";
                            $mail['body'] .= "<p>Thank you for submitting the details to download the Company Profile of X-Byte Enterprise Crawling.</p>";
                            $mail['body'] .= "Thanks,";
                            $mail['body'] .= "<br>";
                            $mail['body'] .= "Team X-Byte";
                            
                            // Save the email body
                            $WPCF7_ContactForm->set_properties( array("mail_2" => $mail)) ;
                            // error_log( print_r( $WPCF7_ContactForm, 1 ) );
                            // return current cf7 instance
                            return $WPCF7_ContactForm ;
                               }
                                               
                    


                   
                    }
                    }
*/
         

?>