<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Form Plugin
 * Description:       This is Form Plugin	
 * Version:           1.0.0
 * Author:            Milan
 * Author URI:        www.milan.com
 * Text Domain:       formplugin
 * Domain Path:       /languages
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
* Currently plugin version.
* Rename this for your plugin and update it as you release new versions.
*/
define( 'Form Plugin', '1.0.0' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

/**
* The code that runs during plugin activation.
* This action is documented in includes/class-formplugin-activator.php
*/
function activate_formplugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-formplugin-activator.php';
	Formplugin_Activator::activate();
}

/**
* The code that runs during plugin deactivation.
* This action is documented in includes/class-formplugin-deactivator.php
*/
function deactivate_formplugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-formplugin-deactivator.php';
	Formplugin_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_formplugin' );
register_deactivation_hook( __FILE__, 'deactivate_formplugin' );



/* Add menu Admin */

/** Step 2 (from text above). */
add_action( 'admin_menu', 'formplugin_plugin_menu' );

/** Step 1. */
function formplugin_plugin_menu() {
	add_menu_page( 'Customer Date', 'Form Plugin', 'manage_options', 'form-plugin', 'formplugin_backend','dashicons-welcome-widgets-menus', 90  );
}


function formplugin_backend() {

//must check that the user has the required capability 
	if (!current_user_can('manage_options'))
	{
		wp_die( __('You do not have sufficient permissions to access this page.') );
	}
		
		
if(isset($_POST['submit'])) {
	global $wpdb;
	//$table_name ='customer';
	
	$nameErr = $emailErr = "";
	
	
	
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$phone = $_POST['phone'];
	
	 if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["name"])) {
               $nameErr = "Name is required";
            }else {
               $name = test_input($_POST["name"]);
            }
			
			if (empty($_POST["email"])) {
               $emailErr = "Email is required";
            }else {
               $email = test_input($_POST["email"]);
               
               // check if e-mail address is well-formed
               if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  $emailErr = "Invalid email format"; 
               }
            }
	 }		
	 
	 function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
	
	
	//$target_dir = plugin_dir_url( __FILE__ )."images/";
	$target_dir = $_SERVER['DOCUMENT_ROOT'].'/wptest/wp-content/plugins/formplugin/images/';
		
	if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true) {
         move_uploaded_file($file_tmp, $target_dir.$file_name);
      }
   }
	
		
	if($firstname != '' && $email != ''){	
	$success = $wpdb->insert("wp_customer", array(
	   "firstname" => $firstname,
	   "lastname" => $lastname,
	   "email" => $email,
	   "address" => $address,
	   "phone" => $phone,
	   "image" => $_FILES['image']['name'],
	));
	if($success) {
		echo ' Inserted successfully';
      } else {
		  echo 'not';
	  }
	}
	else{
		$errallreq = "<br>Please Enter Required Field";
	}
}	
		
		
	?>
	
	
	<h1>Customer Data</h1>

	<form action ="<?php echo $_SERVER['REQUEST_URI']; ?>" method ="post" enctype="multipart/form-data">
	
	<div class="form-control">
		<label for name=""> First Name:</label><br>
		<input type = "text" name = "firstname" id = "firstname" >
		<span class="error"><?php echo $nameErr; ?></span>
	</div>
	
	<div class="form-control">
		<label for name=""> Last Name:</label><br>
		<input type = "text" name = "lastname" id = "lastname" >
		<span class="error"><?php echo $emailErr; ?></span>
	</div>
	
	<div class="form-control">
		<label for name=""> Email:</label><br>
		<input type = "email" name = "email" id = "email" >
	</div>
	
	<div class="form-control">
		<label for name=""> Address:</label><br>
		<input type = "text" name = "address" id = "address" >
	</div>
	
	<div class="form-control">
		<label for name=""> Phone:</label><br>
		<input type="tel" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}">
	</div>
	
	<div class="form-control">
		<label for name=""> Image:</label><br>
		<input type="file" name="image" id="image">
	</div>
	
	<div class="form-control">
		<input type = "submit" name = "submit" value = "Insert">
	</div>
	</form>	
	<div><span class="error"><?php echo $errallreq; ?></span></div>
	
	<div class="CusData" style="margin-top:50px;">
	<?php do_shortcode('[customerdata]'); ?>
	</div>
	
	<?php

	}

function customerdata(){
	
 global $wpdb;
 $results = $wpdb->get_results("select * from wp_customer");
 
 echo '<table style="width:100%;">
  <tr style="text-align:left;">
    <th>Firstname</th>
    <th>Lastname</th>
    <th>Email</th>
	<th>Address</th>
	<th>Phone</th>
  </tr>';
 foreach( $results as $user_data) {
 echo "<tr>
    <td>$user_data->firstname</td>
    <td>$user_data->lastname</td>
    <td>$user_data->email</td>
	<td>$user_data->address</td>
	<td>$user_data->phone</td>
  </tr>";
 }
 echo '</table>';
}

add_shortcode('customerdata','customerdata');


function wpdocs_theme_name_scripts() {
    wp_enqueue_style( 'style-name', get_stylesheet_uri().'/style.css' );
    //wp_enqueue_script( 'script-name', get_template_directory_uri() . '/js/example.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );

add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
  echo '<style>
		.error{
		color: #FF0000;
		}
  </style>';
}

	?>