<?php
/**
 * @wordpress-plugin
 * Plugin Name:       PostType DataTable
 * Description:       This is a PostType DataTable Plugin. Which Generate Shortcode with attribute Like Postatype, Title, Excerpt, Image.
					  Plugin Display PostType DataTable in FrontEnd Side.	
 * Version:           1.0.0
 * Author:            Milan
 * Author URI:        www.milan.com
 * Text Domain:       posttype_datatable
 * Domain Path:       /languages
 */
?>
<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
* Currently plugin version.
* Rename this for your plugin and update it as you release new versions.
*/
define( 'PostType DataTable', '1.0.0' );

/**
* The code that runs during plugin activation.
* This action is documented in includes/class-posttype-datatable-activator.php
*/
function activate_posttype_datatable() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-posttype-datatable-activator.php';
	PostType_DataTable_Activator::activate();
}

/**
* The code that runs during plugin deactivation.
* This action is documented in includes/class-posttype-datatable-deactivator.php
*/
function deactivate_posttype_datatable() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-posttype-datatable-deactivator.php';
	PostType_DataTable_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_posttype_datatable' );
register_deactivation_hook( __FILE__, 'deactivate_posttype_datatable' );

/* Add menu Admin */

/** Step 2 (from text above). */
add_action( 'admin_menu', 'posttype_datatable_plugin_menu' );

/** Step 1. */
function posttype_datatable_plugin_menu() {
	add_menu_page( 'PostType DataTable', 'PostType DataTable', 'manage_options', 'my-unique-identifier', 'posttype_datatable_plugin_options','dashicons-welcome-widgets-menus', 90  );
}


// mt_settings_page() displays the page content for the Test Settings submenu
function posttype_datatable_plugin_options() {

//must check that the user has the required capability 
	if (!current_user_can('manage_options'))
	{
		wp_die( __('You do not have sufficient permissions to access this page.') );
	}

	?>
	
	<h1>PostType DataTable</h1>

	<form name="form1" method="post" action="">
		<input type="hidden" name="<?php echo $hidden_field_name; ?>" value="Y">
		
		<p><label>Post Type</label>
		<select class="posttype">
		<?php 
			$args = array(
				'public'   => true,
			);
		
		$output = 'names';
		$post_types = get_post_types( $args, $output);
		unset($post_types['attachment']);
		foreach ( $post_types  as $post_type ) {
	?>
		<option value="<?php echo $post_type; ?>"><?php echo $post_type; ?></option>
		<?php } ?>
	    </select></p><hr />
		</br>
		<p>
		<label>Display Title</label>
		<select class="post_title">
			  <option value="1">Yes</option>
			  <option value="0">No</option>
	    </select>
		</p> <hr />
		
		<p>
			<label>Display Excerpt</label>
		<select class="post_excerpt">
			  <option value="1">Yes</option>
			  <option value="0">No</option>
	    </select>
		</p><hr />	
		
			<p>
			<label>Display Image</label>
		<select class="post_image">
			  <option value="1">Yes</option>
			  <option value="0">No </option>
	    </select>
		</p><hr />

		<p class="submit">
			<input type="submit" name="Submit2" class="button-primary3" value="<?php esc_attr_e('Generate Shortcode') ?>" onclick ="save_row1();"/>
			
		</p>
		<hr />
		<p>Short Code : <label class="short_code_generate"></label></p>

	</form>
	<?php } 

function post_data_table($attr){

$post_type = $attr['post_type'];
$post_title = $attr['title'];
$post_excerpt = $attr['excert'];
$post_image = $attr['image'];

?>	
	<table id="table_id" class="table plugin-datatable_<?php echo $post_type; ?>">
		<thead>
			<tr>
				<th>
					Post Type
				</th>
				<th>
					Post Title
				</th>
				<th>
					Post Excerpt
				</th>
				<th>
					Post Image
				</th>
				
			</tr>
		</thead>

		<tbody>
       <?php
				$args = array(
					'post_type' => $post_type,
					'posts_per_page' => -1
				);
			 $post_list = new WP_Query($args);	
            while ($post_list->have_posts()) : $post_list->the_post();
					$gallery_id = get_post_thumbnail_id($post_list->ID);
					$gallery_featured_img = wp_get_attachment_image_src($gallery_id, 'medium');
				  ?>
				  <tr>
					  <td><?php echo $args['post_type']; ?></td>
					  <td><?php the_title(); ?></td>
					  <td><?php echo get_the_excerpt(); ?></td>
					  <td><img src="<?php echo $gallery_featured_img[0]; ?>" height="50" width="50" /></td>
					  
				  </tr>
					
				<?php endwhile;
				wp_reset_query();
				?>
           
		</tbody>
	</table>
		<link rel='stylesheet' href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" type='text/css' media='all' />
		<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function(){
				jQuery('.plugin-datatable_<?php echo $post_type; ?>').DataTable({
				"paging":   true,
				"ordering": true,
				"info":     true
				
			} );
			});
		</script>
	<?php
	}

add_shortcode('post_datatable', 'post_data_table');
 
	
/*
 * Enqueue scripts and styles
 */
function posttype_datatable_style_scripts() {
  wp_enqueue_style( 'posttype_datatable', plugins_url( 'posttype_datatable.css', __FILE__ ) );
  
}
add_action( 'admin_enqueue_scripts', 'posttype_datatable_style_scripts' );


 function postype_datatable_ajax_script() { ?>	

	<script type="text/javascript">
	
		jQuery(document).ready(function(){
			
			jQuery(".button-primary3").click(function(event){
				event.preventDefault();
				var post = jQuery('.posttype option:selected');
				var title = jQuery('.post_title option:selected');
				var excerpt = jQuery('.post_excerpt option:selected');
				var image = jQuery('.post_image option:selected');
			jQuery(".short_code_generate").html("<p>[posttype_datatable post_type='"+post.val()+"' title='"+title.val()+"' excerpt='"+excerpt.val()+"' image='"+image.val()+"']<p>");
		});

		});
	
		

	</script>
<?php } 
add_action( 'admin_footer', 'postype_datatable_ajax_script' );
?>