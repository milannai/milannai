<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.milan.com
 * @since      1.0.0
 *
 * @package    PostType DataTable
 * @subpackage PostType DataTable/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    PostType DataTable
 * @subpackage PostType DataTable/includes
 * @author     Milan <milan@gmail.com>
 */
class PostType_DataTable_Deactivator {
	
	public static function deactivate() {

	}
}