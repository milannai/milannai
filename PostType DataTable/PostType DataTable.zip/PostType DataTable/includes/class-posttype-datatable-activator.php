<?php
/**
 * Fired during plugin activation
 *
 * @link       www.milan.com
 * @since      1.0.0
 *
 * @package    PostType DataTable
 * @subpackage PostType DataTable/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    PostType DataTable
 * @subpackage PostType DataTable/includes
 * @author     Milan <milan@gmail.com>
 */
class PostType_DataTable_Activator {

	
	public static function activate() {
		
	}

}