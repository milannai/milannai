<?php

/**
 * Fired during plugin activation
 *
 * @link       www.milan.com
 * @since      1.0.0
 *
 * @package    Addresses
 * @subpackage Addresses/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Addresses
 * @subpackage Addresses/includes
 * @author     Milan <milan@gmail.com>
 */
class Addresses_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
