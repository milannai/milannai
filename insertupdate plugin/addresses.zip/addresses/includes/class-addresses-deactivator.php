<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.milan.com
 * @since      1.0.0
 *
 * @package    Addresses
 * @subpackage Addresses/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Addresses
 * @subpackage Addresses/includes
 * @author     Milan <milan@gmail.com>
 */
class Addresses_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
