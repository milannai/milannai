<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Form Plugin
 * Description:       This is Form Plugin	
 * Version:           1.0.0
 * Author:            Milan
 * Author URI:        www.milan.com
 * Text Domain:       formplugin
 * Domain Path:       /languages
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
* Currently plugin version.
* Rename this for your plugin and update it as you release new versions.
*/
define( 'Form Plugin', '1.0.0' );

/**
* The code that runs during plugin activation.
* This action is documented in includes/class-formplugin-activator.php
*/
function activate_formplugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-formplugin-activator.php';
	Formplugin_Activator::activate();
}

/**
* The code that runs during plugin deactivation.
* This action is documented in includes/class-formplugin-deactivator.php
*/
function deactivate_formplugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-formplugin-deactivator.php';
	Formplugin_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_formplugin' );
register_deactivation_hook( __FILE__, 'deactivate_formplugin' );

/* Add menu Admin */

/** Step 2 (from text above). */
add_action( 'admin_menu', 'formplugin_plugin_menu' );

/** Step 1. */
function formplugin_plugin_menu() {
	add_menu_page( 'Customer Date', 'Form Plugin', 'manage_options', 'form-plugin', 'formplugin_backend','dashicons-welcome-widgets-menus', 90  );
}


function formplugin_backend() {

//must check that the user has the required capability 
	if (!current_user_can('manage_options'))
	{
		wp_die( __('You do not have sufficient permissions to access this page.') );
	}

	?>
	
	<h1>Customer Data</h1>

	<form action ="<?php echo $_SERVER['REQUEST_URI']; ?>" method ="post">
	
	<div class="form-control">
		<label for name=""> First Name:</label><br>
		<input type = "text" name = "name" id = "name" placeholder = "Enter Name">
	</div>
	
	<div class="form-control">
		<label for name=""> City:</label><br>
		<input type = "text" name = "city" id = "city" placeholder = "Enter City">
	</div>
	
	<div class="form-control">
		<label > State:</label><br>
		<input type = "text" name = "state" id = "state"  placeholder = "Enter State">
	</div>
	
	<div class="form-control">
		<label> Age:</label><br>
		<input type = "text" name = "age" id = "age"  placeholder = "Enter Age">
	</div>
	<div class="form-control">
		<input type = "submit" name = "submit" value = "Insert">
	</div>
	</form
	<?php

if(isset($_POST['submit'])) {
	global $wpdb;
	$table_name ='student';
	$name = $_POST['name'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$age = $_POST['age'];
	
	$success = $wpdb->insert("student", array(
	   "name" => $name,
	   "city" => $city,
	   "state" => $state,
	   "age" => $age ,
	));
	if($success) {
		echo ' Inserted successfully';
      } else {
		  echo 'not';
	  }
}

	} ?>