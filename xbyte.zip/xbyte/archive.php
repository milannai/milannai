<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<style>
.et-db #et-boc .et_pb_blog_0 .et_pb_post .entry-title a {
    font-family: 'Rubik',Helvetica,Arial,Lucida,sans-serif!important;
    font-weight: 700!important;
}

.et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta, .et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta a, .et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta span {
    font-family: 'Arimo',Helvetica,Arial,Lucida,sans-serif;
    color: #888!important;
    line-height: 1.8em;
}

.et-db #et-boc .et_pb_blog_0 .et_pb_post p {
    line-height: 1.8em;
}

.et-db #et-boc div.et_pb_section.et_pb_section_0 {
    background-image: url(http://www.xbyte.io/wp-content/uploads/2018/07/banner-bg.png)!important;
}

.et-db #et-boc .et_pb_section_0 {
    padding-top: 0px;
    padding-right: 9.8%;
    padding-bottom: 0px;
    padding-left: 9.8%;
    margin-top: 0px;
}
.et-db #et-boc .et_pb_text_0 h1 {
    font-weight: 500;
    font-size: 54px;
}

.et-db #et-boc .et_pb_column_0 {
    padding-top: 8vw;
    padding-right: 40px;
    padding-bottom: 6vw;
    padding-left: 40px;
}

.et-db #et-boc .et_pb_row_0.et_pb_row {
    padding-top: 0;
    padding-bottom: 0;
}
</style>
<div class="et-db">
<div class="et_divi_builder ">
<div id="et-boc" class="et-boc">
   <div id="et_builder_outer_content" class="et_builder_outer_content">
      <div class="et_builder_inner_content et_pb_gutters3">
         <div class="et_pb_section et_pb_section_0 demo-two et_pb_with_background et_section_regular et_section_transparent">
            <div class="et_pb_row et_pb_row_0">
               <div class="et_pb_column et_pb_column_4_4 et_pb_column_0    et_pb_css_mix_blend_mode_passthrough et-last-child">
                  <div class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_light  et_pb_text_align_center">
                     <div class="et_pb_text_inner">
                        	<?php
            					the_archive_title( '<h1 class="page-title">', '</h1>' );
            				?>
                     </div>
                  </div>
                  <!-- .et_pb_text -->
                  <!-- .et_pb_text -->
               </div>
               <!-- .et_pb_column -->
            </div>
            <!-- .et_pb_row -->
         </div>
         <!-- .et_pb_section -->
         <div class="et_pb_section et_pb_section_1 et_section_regular et_section_transparent">
            <div class="et_pb_row et_pb_row_1">
               <div class="et_pb_column et_pb_column_4_4 et_pb_column_1    et_pb_css_mix_blend_mode_passthrough et-last-child">
                  <div class="et_pb_module et_pb_blog_0 et_pb_blog_grid_wrapper">
                     <div class="et_pb_blog_grid clearfix et_pb_bg_layout_light ">
                        <div class="et_pb_ajax_pagination_container">
                           <div class="et_pb_salvattore_content" data-columns="3">
                              
                              
                              	<?php if ( have_posts() ) : ?>

			

                        			<?php
                        			// Start the Loop.
                        			while ( have_posts() ) : the_post();
                                    
                                    ?>
                        
                        			<div class="column">
                                         <article class="et_pb_post clearfix post-1 ">
                                            <div class="et_pb_image_container">							
                                                <a href="<?php the_permalink(); ?>" class="entry-featured-image-url">
                                                   <?php echo get_the_post_thumbnail( get_the_ID(), 'blug-thumb' );   ?>
                                                </a>
                                            </div>
                                            <!-- .et_pb_image_container -->
                                            <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                            <p class="post-meta">  <span class="published"><?php echo get_the_date( 'M j, Y' );  ?></span>  | <?php echo get_the_category_list(', ');?>   </p>
                                            <div class="post-content">
                                               <p><?php truncate_post( 270 ); ?></p>
                                            </div>
                                         </article>
                                      </div>
                        
                        			<?php // End the loop.
                            			endwhile;
                                
                                			// Previous/next page navigation.
                                			the_posts_pagination( array(
                                				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
                                				'next_text'          => __( 'Next page', 'twentysixteen' ),
                                				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
                                			) );
                                
                                		// If no content, include the "No posts found" template.
                                		else :
                                			get_template_part( 'template-parts/content', 'none' );
                                
                                		endif;
                            		?>
                                                          
                                  
                              
                              
                           </div>
                           <!-- .et_pb_salvattore_content -->
                           <div class="pagination clearfix">
                              <div class="alignleft">
                              </div>
                              <div class="alignright">
                              </div>
                           </div>
                        </div>
                        <!-- .et_pb_posts -->
                     </div>
                  </div>
               </div>
               <!-- .et_pb_column -->
            </div>
            <!-- .et_pb_row -->
         </div>
         <!-- .et_pb_section -->			
      </div>
   </div>
</div>
</div>
</div>


<?php get_footer(); ?>
