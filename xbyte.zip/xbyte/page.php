<?php get_header(); ?>
<?php /* ?>
<div class="main-banner">
	<div class="xb-bannerContent">
		<div class="bannerBox01">
			<div class="banner-textbox"><div class="xb-bannertitle01">
					<span></span><span><?php the_title(); ?></span>
				</div>
				<div class="xb-bannertext01"><?php the_excerpt(); ?></div>
			</div>
		</div>
	</div>
</div>
<?php */ ?>

<div id="primary" class="content-area">
	<div class="containerd">
        <?php
        // For Page contat
            while ( have_posts() ) : the_post(); 
                the_content();
            endwhile;wp_reset_query();
        ?>
    </div>
</div><!-- .content-area -->

<?php get_footer(); ?>
