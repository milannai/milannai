<footer class="xbyt-footer" id="contAct">
   <?php if( have_rows('logos','options') ): ?>	
   <div id="clients">
      <div class="clients-wrap">
         <ul id="clients-list" class="clearfix">
            <?php 
               while ( have_rows('logos','options') ) : the_row(); 
               $image = get_sub_field('logo','options');          
               ?>
            <li>
               <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
            </li>
            <?php  endwhile; ?> 
         </ul>
      </div>
      <!-- @end .clients-wrap -->
   </div>
   <?php endif; ?>
   <?php /* ?>
   <!-- @end #clients -->	
   <div class="footer-form" style="padding-top: 60px;background: url(<?php the_field('background','options'); ?>) no-repeat;">
      <div class="container">
         <div class="xb-title03"><?php the_field('contact_title','options'); ?></div>
         <?php echo do_shortcode('[contact-form-7 id="36" title="Footer Contact Form"]'); ?>
         <form name="inquiry_form_ft" id="inquiry_form_ft" method="post" action="" onSubmit="return chkrequired_ft()">
         </form>
      </div>
   </div>
   <?php */ ?>			
<div class="xbFooter_main">
   <div class="container flex" style="align-items: flex-start" >

         <div id="footerLogo">
            <div class="footerLogo_inner">
        		  <div class="ftBox01">
            		<?php $image = get_field('footer_logo','options');?>
               	<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
        		  </div>

              <?php if( have_rows('award_images','options') ): ?>
        		  <div id="footer_awardMain" class="ftBox02">
                 <div class="footer_award-wrap"> 
                     <ul id="footer_award">
                        <?php 
                           while ( have_rows('award_images','options') ) : the_row(); 
                           ?>
                        <li>
                           <a href="<?php echo get_sub_field('award_url'); ?>" target="_blank"><img src="<?php echo get_sub_field('award_image','options'); ?>" alt="<?php echo $image['alt'] ?>" /></a>
                         </li>
                         <?php endwhile; ?> 
                     </ul>
                </div>
        		  </div> 
              <?php endif; ?>
            </div>
		   </div>


         <div class="xbfotBox01">
               <div class="xbfotBox01_inner">
                  <?php if( have_rows('footer_contact_detail','options') ):
                        while ( have_rows('footer_contact_detail','options') ) : the_row();
                     ?> 
                     <div class="fotBox01_left">
                        <img src="<?php echo get_sub_field('icon'); ?>" alt="<?php echo $image['alt'] ?>" />
                     </div>
                     <div class="fotBox01_right">
                       <h4><?php echo get_sub_field('contact_title'); ?></h4>
                       <p><?php echo get_sub_field('contact_detail'); ?></p>
                     </div>

                     <?php endwhile; 
                           endif;
                     ?>
               </div>     
         </div>

         <div class="xbfotBox02">      
            <h3><?php the_field('global_presence_title', 'options'); ?></h3>
            <div class="xbfotBox02_inner">
                  <?php if( have_rows('global_presence','options') ):
                        while ( have_rows('global_presence','options') ) : the_row();
                     ?> 
                     <div class="fotBox02_left">
                        <img src="<?php echo get_sub_field('country_icon'); ?>" alt="<?php echo $image['alt'] ?>" />
                     </div>
                     <div class="fotBox02_right">
                       <p><?php echo get_sub_field('country_contact_no'); ?></p>
                     </div>

                     <?php endwhile; 
                           endif;
                     ?>
            </div>
         </div>

         <div class="xbfotBox03">
               <h3><?php the_field('footer_service_title', 'options'); ?></h3> 
               <div class="fotBox03">
                     <?php if( have_rows('footer_services_list','options') ):
                           while ( have_rows('footer_services_list','options') ) : the_row();
                        ?> 
                     <a href="<?php echo get_sub_field('service_url'); ?>"><P><?php echo get_sub_field('service_name'); ?></P></a>
                      <?php endwhile; 
                           endif;
                     ?>
               </div>
         </div>

         <div class="xbfotBox04">
               <h3><?php the_field('footer_solutions_title', 'options'); ?></h3>
               <div class="fotBox04">
                  <?php if( have_rows('footer_solutions_list','options') ):
                         while ( have_rows('footer_solutions_list','options') ) : the_row();
                     ?>
                  <a href="<?php echo get_sub_field('solution_url'); ?>"><P><?php echo get_sub_field('solution_name'); ?></P></a>
                  <?php endwhile; 
                         endif;
                     ?>
               </div>
         </div>

         <div class="xbfotBox05">
               <h3><?php the_field('footer_social_media_title', 'options'); ?></h3>
               <div class="fotBox05">
                  <?php if( have_rows('footer_social_media','options') ):
                        while ( have_rows('footer_social_media','options') ) : the_row();
                  ?>
                     <a href="<?php echo get_sub_field('social_media_url'); ?>" target="_blank"><img src="<?php echo get_sub_field('social_media_icon'); ?>" alt="<?php echo $image['alt'] ?>" /></a>
                  <?php 
                     endwhile; 
                     endif;
                  ?>  
               </div>
         </div>

   </div>
</div>


   <div class="xbcopirightbox">
      <div class="xbcopirightbox_inner">
         <a href="<?php the_field('copy_right_image_link  ', 'options'); ?>" target="_blank"><img src="<?php the_field('copy_right_image  ', 'options'); ?>" alt="" /></a>
         <span><?php the_field('copy_right_text', 'options'); ?></span>
      </div>   
   </div>


</footer>
<div id="inquire" class="iziModal" data-izimodal-title="Inquire Now" data-iziModal-subtitle="Got a project in mind? " >
   <div id="inquiry_form">
      <?php echo do_shortcode('[contact-form-7 id="85" title="Popup Form"]'); ?>
   </div>
</div>
<?php wp_footer(); ?>
<script type='application/ld+json'> 
   {
   "@context": "http://www.schema.org",
   "@type": "ProfessionalService",
   "name": "<?php echo get_field('xb_page_title'); ?>",
   "url": "<?php echo get_permalink(); ?>",
   "logo": "https://www.xbyte.io/wp-content/uploads/2018/07/logo.svg",
   "image": "https://www.xbyte.io/wp-content/uploads/2018/07/logo.svg",
   "description": "<?php echo get_field('xb_meta_description'); ?>",
   "priceRange":"INR",
   "aggregateRating": {
   "@type": "AggregateRating",
   "ratingValue": "4.9/5",
   "reviewCount": "1550"
   },
   "address": {
   "@type": "PostalAddress",
   "streetAddress": "A-412, 4th Floor, Dev Arc Commercial Complex Iscon Cross Road, Sarkhej - Gandhinagar Hwy, Ahmedabad, Gujarat 380015",
   "addressLocality": "Ahmedabad",
   "addressRegion": "Gujarat",
   "postalCode": "380015",
   "addressCountry": "India"
   },
   "telephone":"+91 070961 06592",
   "geo": {
   "@type": "GeoCoordinates",
   "latitude": "23.02609",
   "longitude": "72.507773"
   },
   "openingHours": "Mo, Tu, We, Th, Fr, Sa 10.00:00-19:30",
   "contactPoint": [{
   "@type": "ContactPoint",
   "telephone": "+91 070961 06592",
   "contactType": "customer support",
   "areaServed" : ["IN"],
   "availableLanguage" : ["Hindi","Gujarati","English"]
   },
   {
   "@type" : "ContactPoint",
   "telephone" : "+91 070961 06592",
   "contactType" : "technical support",
   "areaServed" : ["IN"],
   "availableLanguage" : ["Hindi","Gujarati","English"]
   }],
   "sameAs" : [
   "https://www.facebook.com/xbyteio",
       "https://twitter.com/xbyteio",
       "https://www.linkedin.com/company/xbyte-crawling",
       "https://www.instagram.com/xbytetechnolabs/"
       ]
   }
</script>


<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(52287295, "init", {
        id:52287295,
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<script type='text/javascript'>
window.__wtw_lucky_site_id = 143915;

(function() {
var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
})();
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/52287295" style="position:absolute; left:-9999px;" alt="" /></div></noscript>

<script type="text/javascript">
var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || 
{widgetcode:"ae56a149c873a9fe8a949af24eed3313a5a205bf4d221192ae8170160d3b6bb66970830d0bca98e608f2ec39ec1bc0e0", values:{},ready:function(){}};
var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;
s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);d.write("<div id='zsiqwidget'></div>");
</script>
</body>
</html>