<?php /**
 * Template Name: About Page
*/
get_header(); ?>

<style>
#process{background: #fff;margin-bottom: 40px;}
#process:after{display: none;}

</style>


<div id="primary" class="content-area">
	<div class="containerd">
        <?php
        // For Page contat
            while ( have_posts() ) : the_post(); 
                the_content();
            endwhile;wp_reset_query();
        ?>
    </div>
</div><!-- .content-area -->

<?php if( have_rows('values') ): ?>
<div id="process">
	<div class="container">
		<div class="xb-title02"><?php the_field('titleov'); ?></div>
		<div class="xb-text03">
			<p><?php the_field('descriptionov'); ?></p>
		</div>
		<div class="processbox">
            <?php 
               while ( have_rows('values') ) : the_row();  
            ?>
			<div class="proBox01 proBoxsix">
				<div class="proIconbox">
                    <img src="<?php the_sub_field('icon'); ?>" alt="" />
                </div>
				<?php the_sub_field('title'); ?> 
            </div>
            <?php  endwhile; ?> 
			
		</div>
	</div>
</div>
<?php endif; ?>



<?php get_footer(); ?>
