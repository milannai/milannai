<?php
/**
 * Template Name: Download Company Profile
*/
get_header(); ?>

<div class="cp_download" style="float: left;width: 100%;height: 500px;">

<?php 
$downloadId = $_GET['rdwtyp'];

$currentDateTime = date('Y-m-d H:i:s');

//echo $downloadId;

global $wpdb;
$linkAddtime = $wpdb->get_var('SELECT link_generate_time FROM xbjnj_company_profile WHERE download_id ="'.$downloadId.'" ');

   // Echo the ID of the 4th most commented post

$start_date = new DateTime($currentDateTime);
$since_start = $start_date->diff(new DateTime($linkAddtime));

$expireTime = $since_start->h;

//echo $expireTime;exit();

if($expireTime <= 24 && $linkAddtime != ''){

	$path = "https://www.xbyte.io/sample2.pdf";
	$filename = "sample2.pdf";
	header('Content-Transfer-Encoding: binary');  // For Gecko browsers mainly
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($path)) . ' GMT');
	header('Accept-Ranges: bytes');  // For download resume
	header('Content-Length: ' . filesize($path));  // File size
	header('Content-Encoding: none');
	header('Content-Type: application/pdf');  // Change this mime type if the file is not PDF
	header('Content-Disposition: attachment; filename=' . $filename);  // Make the browser display the Save As dialog
	readfile($path);  //this is necessary in order to get it to actually download the file, otherwise it will be 0Kb


	/*$file_name = 'company-profile.pdf';
	$file_url = 'https://www.xbyte.io/' . $file_name;
	header('Content-Type: application/pdf');
	header("Content-Transfer-Encoding: Binary"); 
	header("Content-disposition: attachment; filename=\"".$file_name."\""); 
	readfile($file_url);
	exit;*/
	/*header("Location: https://www.xbyte.io/company-profile.pdf"); 
	exit();*/


	/*$rootPath = get_home_path();
	//$path = $rootPath."sample.pdf";
	$path = "https://www.xbyte.io/company_profile_download.pdf";
	$filename = 'company_profile_download.pdf';

	$file_url = 'https://www.xbyte.io/company_profile_download.pdf';

	header('Content-type: application/pdf');
	header('Content-Disposition: attachment; filename="'.$filename.'"');
	header("Content-Transfer-Encoding: Binary");
	//header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\"");
	readfile($file_url);
	die;*/


/*
	header("Content-Type: application/pdf");

	$file = "https://www.xbyte.io/sample2.pdf";
	header("Content-Disposition: attachment; filename=" . urlencode($file));   
	header("Content-Type: application/octet-stream");
	header("Content-Type: application/download");
	header("Content-Description: File Transfer");            
	header("Content-Length: " . filesize($file));
	flush(); // this doesn't really matter.
	$fp = fopen($file, "r");
	while (!feof($fp))
	{
	    echo fread($fp, 65536);
	    flush(); // this is essential for large downloads
	} 
	fclose($fp);*/

}else{
	header("Location: ".site_url()."/company-profile"); 
	exit();
}


 ?>

</div>

<?php get_footer(); ?>