<?php
/**
 * Template Name: Case Studies
*/
get_header(); ?>



<div class="banner_section" style="background-image: url(<?php echo get_the_post_thumbnail_url() ?>);">
     <div class="banner_section_inner">
        <h1><?php the_title(); ?></h1>
        <h3><?php the_field('case_studies_subtitle'); ?></h3>
     </div>
 </div>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


      
        <!--Gallary section start-->
<div class="clearfix"></div>
    <div class="caseStudyList">
        <div class="container">

            <div class="caseStudyList_inner">

                <?php 
                    $current_page = get_query_var('paged') ? get_query_var('paged'):1;
                    $args_case = array(
                    'post_type' => 'case_studies',
                    'posts_per_page' => 3,
                    'order' => 'ASC',
                    "paged" => $current_page
                    );
                                    
                    $query_case = new WP_Query($args_case);
                                    
                    while ($query_case->have_posts()) : $query_case->the_post();
                        $case_id = get_post_thumbnail_id($query_case->ID);
                        $case_featured_img = wp_get_attachment_image_src($case_id, 'large'); 
                ?>

                <div class="caseStudyListSingle">
                    <a href="<?php  the_permalink(); ?>">
                    <div class="caseStudyListimg">
                        <img src="<?php echo $case_featured_img[0]; ?>"  />
                    </div>
                    <div class="caseStudyListContent">
                        <h3><?php the_title(); ?></h3>
                    </div>
                    </a>
                </div>
            <?php
                endwhile; 
                wp_reset_query();
            ?> 

        </div>     
                        
              
                <?php
                    $big = 999999999;
                    $pages = array(
                        'type' => 'array',
                        'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                        'format' => '?paged=%#%',
                        'current' => max( 1, get_query_var('paged') ),
                        'total' => $query_case->max_num_pages
                        );
                        $links = paginate_links($pages);
                ?>
                    <div class="pagination">    
                        <?php  
                            if($links != NULL){
                                foreach($links as $link){
                                    echo $link;
                                    }
                                }
                        ?>
                    </div>
                                           
        </div>
    </div>  

        <!--Gallary section end-->
<?php
endwhile;
endif;
?>

<?php get_footer(); ?>
