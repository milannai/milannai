<?php /**
 * Template Name: Career Page
*/
get_header(); ?>

<style>
#process{background: #fff;margin-bottom: 40px;}
#process:after{display: none;}

.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.accordion:after {
  content: '\002B';
  color: #777;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.panel {
  padding: 0 18px;
  background-color: white;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
.Apply_Now{
	color:#A81111 !important;
	border:1px solid #A81111 !important;
	padding:5px 10px;
}
.Apply_Now:hover{
	color:#FFF !important;
	background:#A81111;
}
h3:after{
	content: "";
    border: none;
    width: 82px;
    height: 6px;
    display: block;
    position: absolute;
    left: calc(50% - 41px);
    top: calc(100% + 5px);
    background: url(../images/title-bg.png) left top no-repeat;
}

.accordion{
	margin-bottom:15px;
	background-color:#dcdcdc;
	padding-right:0;
	padding:0;
	border-radius:5px;
}
.accordion:after{
	font-size: 25px;
    width: 50px;
    text-align: center;
    background: #a81212;
    color: #FFF;
    padding: 10px;
    border-radius: 0 5px 5px 0px;
}

.banner_section_inner1 {
    position: relative;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}
.section{position:absolute; margin:14px;  font-size:20px;}
.mainsection{display:flex;justify-content: space-between; align-items:center;margin-top:11px;}
.icon-mobile{font-size:30px; vertical-align:middle; margin-right:10px;}
.text-info{font-weight:600; color:#A90F0F; font-size:18px; margin-right:15px;}
.heading{color: #737373;font-weight: 600;font-size: 18px;display:block;margin-bottom:7px;}
.lbl-txt{color: #737373;font-size: 16px;display:inline-block;;line-height:2;}
.arrow{font-size: 20px;font-weight: 600; margin-right:5px;}
.description{float:left; width:10%;}
.list-info{float:left; width:90%;}

@media only screen and (max-width: 1024px) {
	.accordion{
		margin-left:20px !important;
		width:96% !important;
	}
	.panel{margin:0 20px}
	.description{
		width:15%;
	}
	.list-info{
		width:85%;
	}
}
@media only screen and (max-width: 768px){
	.description{
		width:20%;
	}
	.list-info{
		width:80%;
	}
	.xs-lbl-info{
		display:flex;		
	}
	.arrow{margin-right:5px;margin-top:5px;}
}

@media only screen and (max-width: 425px) {
	.mainsection{
		display:block;
	}
	.xs-margin-bottom-15{
		margin-bottom:15px;
	}
	.xs-margin-top-bottom-10{
		margin-top:10px;
		margin-bottom:10px;
	}
	.accordion{
		width:93% !important;
	}
	.arrow{
		margin-top:5px;
		margin-right:10px;
	}
	.lbl-txt{
		font-size:15px;
		text-align:left;
	}
	.xs-lbl-info{
		display:flex;		
	}
	.description{
		width:100%;
		margin:10px 0;
	}
	.list-info{
		width:100%;
	}
}

@media only screen and (max-width: 320px) {
	.accordion{
		width:90% !important;
	}
}
</style>

<div id="primary" class="content-area">
	<div class="containerd">
        <?php
        // For Page contat
            while ( have_posts() ) : the_post(); 
                the_content();
            endwhile;wp_reset_query();
        ?>
    </div>
</div><!-- .content-area -->


<div class="container" style="margin-top:50px; margin-bottom:50px;">

<div class="banner_section_inner1">
<h1>Current Openings</h1>
</div>

<button class="accordion"><span class="section">Section 1</span></button>
<div class="panel">
	<div class="mainsection">
  <div>
	<i class="fa fa-mobile icon-mobile"></i><label><span class="text-info">PHP Developer</span><b style="color:#000;">Post: 05 | Experience: 1 to 2 Years</b></label>
  </div>
  
  <div class="xs-margin-top-bottom-10">
	<a href="#" class="Apply_Now">Apply Now</a>
  </div>
  
  </div>
  
  <hr>
  <div class="mainsection">
  <div class="xs-margin-bottom-15">
	<label class="heading">Department:</label>
	<span style="font-size:16px;">PHP Development</span>
  </div>
  
   <div class="xs-margin-bottom-15">
	<label class="heading">Joining Period:</label>
	<span style="font-size:16px;">1 Month</span>
  </div>
  
   <div class="xs-margin-bottom-15">
	<label class="heading">Location:</label>
	<span style="font-size:16px;">Ahmedabad</span>
  </div>
  </div>
  
  <hr>
  <div class="mainsection1">
  <div class="description">
	<label style="color:#444; font-weight:600; font-size:16px;">Job Description:</labelel>
  </div>
  <div class="list-info">
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Ability to research & develop web applications in PHP, Mysql, Ajax independently.</label></div>
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Should have excellent database design, querying and implementation skills.</label></div>
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Knowledge of Magento Would be an added advantage.</label></div>
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Having working knowledge of shopping cart application with shipping and Payment Gateway Integration for ecommerce websites would be added advantage.</label></div>
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Sound knowledge of coding, server deployment and troubleshooting.</label></div>
	<div class="xs-lbl-info"><i class="fa fa-angle-right arrow" aria-hidden="true"></i> <label class="lbl-txt">Should be an excellent team player.</label></div>	
  </div>
  </div>
  <hr>
  
</div>

<button class="accordion"><span class="section">Section 2</span></button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>

<button class="accordion"><span class="section">Section 3</span></button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
</div>
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
</script>

<?php get_footer(); ?>
