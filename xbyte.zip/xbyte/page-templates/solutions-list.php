<?php
/**
 * Template Name: Solutions List
*/
get_header(); ?>

<div class="solutions_main">

 <div class="banner_section" style="background-image: url(<?php the_field('solution_banner_image') ?>);">
     <div class="banner_section_inner">
        <h1><?php the_title(); ?></h1>
        <h3><?php the_field('solution_sub_title'); ?></h3>
     </div>
 </div>

<section id="solutions_list">
<div class="container">
    <?php 

        $args = array(
            'post_type' => 'solution',
            'post_per_page' => '-1'
            );
            query_posts($args);
            while ( have_posts() ) : the_post();
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                $feature1 = get_post_thumbnail_id($post->ID);
                $image_alt = get_post_meta( $feature1, '_wp_attachment_image_alt', true);
                $solution_detail_display = get_field('solution_display_detail_page');

    ?>

    <div class="single_solution">
            <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>">
            <div class="single_solution_inner">
                <h5><?php the_title(); ?></h5>
                    <?php the_excerpt(); ?> 
                <a href="<?php if($solution_detail_display == "Yes"){ the_permalink(); }else{echo "#";} ?> ">Learn More</a>
            </div>
    </div>

    <?php endwhile;wp_reset_query(); ?>

</div>  
 </section> 

</div>


<?php get_footer(); ?>
