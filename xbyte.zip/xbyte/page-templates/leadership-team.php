<?php
/**
 * Template Name: Leadership Team
*/
get_header(); ?>

<div class="leadership-main">
 <div class="banner_section" style="background-image: url(<?php the_field('leadership_banner_image') ?>);">
     <div class="banner_section_inner">
        <h1><?php the_title(); ?></h1>
        <h3><?php the_field('leadership_sub_title'); ?></h3>
     </div>
 </div>


 <!-- Team Section 1 -->
<section class="leadership_section1">
    <div class="container">
        <div class="bussiness_inner">
            <div class="business_left">
                <?php 
                $profile1_image = get_field('profile-1_photo');
                echo wp_get_attachment_image($profile1_image, 'large');
                ?>
                <div class="social-icons">
                    <ul>
                        <?php
                        $p1_facebook = get_field('profile-1_facebook_link');
                        $p1_twitter = get_field('profile-1_twitter_link');
                        $p1_linkedin = get_field('profile-1_linkedin_link');

                         ?>

                        <?php if($p1_facebook != ''){ ?> <a href="<?php echo $p1_facebook; ?>"><li><i class="fa fa-facebook" aria-hidden="true"></i></li></a> <?php } ?>
                        <?php if($p1_twitter != ''){ ?>  <a href="<?php echo $p1_twitter; ?>"><li><i class="fa fa-twitter" aria-hidden="true"></i></li></a> <?php } ?>
                        <?php if($p1_linkedin != ''){ ?> <a href="<?php echo $p1_linkedin; ?>"><li><i class="fa fa-linkedin" aria-hidden="true"></i></li></a> <?php } ?>
                    </ul>
                </div>
            </div>

            <div class="business_right">
                <?php echo get_field('profile-1_description'); ?>
            </div>
        </div>
    </div>
</section>

 <!-- Team Section 2 -->
<section class="leadership_section2">
    <div class="container">
        <div class="bussiness_inner">
          
            <div class="business_left">
                <?php echo get_field('profile-2_description'); ?>
            </div>
              <div class="business_right">
                <?php 
                $profile2_image = get_field('profile-2_photo');
                
                echo wp_get_attachment_image($profile2_image, 'large');
                ?>
                  <div class="social-icons">
                    <ul>
                        <?php 
                            $p2_facebook = get_field('profile-2_facebook_link');
                            $p2_twitter = get_field('profile-2_twitter_link');
                            $p2_linkedin = get_field('profile-2_linkedin_link');
                        ?>
                        <?php if($p2_facebook != ''){ ?> <a href="<?php echo $p2_facebook; ?>"><li><i class="fa fa-facebook" aria-hidden="true"></i></li></a> <?php } ?>
                        <?php if($p2_twitter != ''){ ?>  <a href="<?php echo $p2_twitter; ?>"><li><i class="fa fa-twitter" aria-hidden="true"></i></li></a> <?php } ?>
                        <?php if($p2_linkedin != ''){ ?> <a href="<?php echo $p2_linkedin; ?>"><li><i class="fa fa-linkedin" aria-hidden="true"></i></li></a> <?php } ?>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Company Completion Year Section -->

<div id="CompleteYear">
    <div class="container flex">
        
        <div class="CyLeft">
            <div class="cbcylft" style="background-image: url(<?php echo site_url();?>/wp-content/uploads/2019/02/bg.png);">&nbsp;</div>
            <div class="CyLeftImg"><img src="<?php the_field('completed_year_image'); ?>" alt="07 Years of Experience and Excellence" title="07 Years of Experience and Excellence "></div>
        </div>
        <div class="CyRight">
            <?php if( have_rows('completed_project') ):
                  while ( have_rows('completed_project') ) : the_row();  
            ?>
            <div class="CyRight_inner">
               <div class="CyRightIcon"><img src="<?php the_sub_field('block_icon'); ?>"></div>
               <div class="CyRightNumber"><h4><?php the_sub_field('block_number'); ?>+</h4></div>
               <div class="CyRightText"><p><?php the_sub_field('block_text'); ?></p></div> 
            </div>
            <?php endwhile;
                  endif; ?>   
        </div> 
     </div>     
</div>


<!-- Blog Section -->

<section id="HomeBlogMain">

    <div class="container">
         
        <div class="homeBlogBox01">
            <div class="xb-title02">
                  Some of our latest insights
            </div>
        </div>
        <div class="homeBlogBox02">
            <div class="xb-text01"> We write about web data gathering, analyze trends and data.</div>
        </div>

        <div class="homeBlog_inner">

            <?php 
                $args =  array('post_type' =>'post',
                //'paged' => $paged,
                'posts_per_page'=>'3'
                );                                                  
                query_posts( $args );                        
                $i=1; while ( have_posts() ) : the_post();   
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                $feature2 = get_post_thumbnail_id($post->ID);
                $image_alt = get_post_meta( $feature2, '_wp_attachment_image_alt', true);
                $blogImg_title = get_the_title($feature2);
            ?>

            <div class="homeBlogSingle">
                <div class="homeBlogimg">
                    <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>" title="<?php echo $blogImg_title; ?>" />
                </div>
                <div class="homeBlogContent">
                    <a href="<?php echo get_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
                </div>
            </div>
        <?php endwhile;wp_reset_query(); ?>

        </div>

        <div class="homeBlogBtn">
            <a href="<?php get_site_url();?>/blog"  class="btn01 ">Explore More Resources</a>
        </div>

    </div>
    
</section>



</div>

<?php get_footer(); ?>
