<?php
/**
 * Template Name: Front Page
*/
get_header(); ?>



<div class="main-banner">
    <div class="xb-bannerContent">
        <div class="bannerBox01">
            <div class="banner-textbox"><div class="xb-bannertitle01">
                    <h2><?php the_field('page_title'); ?></h2><span><?php the_field('page_subtitle'); ?></span>
                </div>
                <div class="xb-bannertext01"><?php the_field('topdescription'); ?></div>
                <?php if(get_field('request_button')!=""){ ?> 
                    <a href="<?php the_field('button_link'); ?>"  class="btn01 contact-popup"><?php the_field('request_button'); ?></a>
                <?php } ?>
            </div>
        </div>
        <div class="bannerBox02">
                <div id="md-Canvas" >       
                <div id="animation_container">
                <canvas id="canvas" width="680" height="674"></canvas>
                <div id="dom_overlay_container">
                </div>
            </div></div>
        </div>
    </div>
</div>

<div id="aboutUs">
    <div class="container flex">
        <div class="abtBox01">
            <div class="xb-title01"><h1><?php the_field('who_are_title'); ?></h1></div>
        </div>
        <div class="abtBox02">
            <div class="xb-text01"> <?php the_field('descriptionww'); ?> </div>
        </div> 
     </div>     
</div>


<!-- Our Services Section -->
<div id="ourService">
    <div class="container">
        <div class="xb-title02"><?php the_field('services_title'); ?></div>
        <div class="xb-text03"><?php the_field('services_description'); ?></div>
        <div class="os-content">
            <div class=" clearfix flex ">
            <div class="owl-carousel">
                <?php 
                    $args =  array('post_type' =>'service',
                    //'paged' => $paged,
                    'posts_per_page'=>'-1'
                    );                                                  
                    query_posts( $args );                        
                    $i=1; while ( have_posts() ) : the_post();   
                    $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                    $feature1 = get_post_thumbnail_id($post->ID);
                    $image_alt = get_post_meta( $feature1, '_wp_attachment_image_alt', true);
                    $service_detail_display = get_field('service_detail_page_display');
                    $servicesImg_title = get_the_title($feature1);

                    ?>
                    
                    <div class="item serviceBox01">
                        <a href="<?php if($service_detail_display == "Yes"){ the_permalink(); }else{echo "#";}?>"> 
                        <div class="sb-iconbox">
                            <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>" title="<?php echo $servicesImg_title; ?>" />
                        </div>
                        <div class="srvTitle01"><?php the_title(); ?></div>
                        <div class="srvText01"><?php the_excerpt(); ?></div>
                        </a> 
                    </div>
               <?php endwhile;wp_reset_query(); ?>
               
               </div>
                
            </div>
        </div>
          
    </div>
</div>

<!-- Data Visulization Section -->
<section class="data_revenue">

    <div class="container flex data_revenue_inner">
            <div class="data_revenue_left">
                    <?php the_field('data_revenue_right_content'); ?>
            </div>
            <div class="data_revenue_right">
                <img src="<?php the_field('data_revenue_leftimg'); ?>" alt="A Step Wise Approach to Getting Better at Data Visualization" title="A Step Wise Approach to Getting Better at Data Visualization">
            </div>
    </div>
</section>


<!-- Our Solution Section -->
<div id="ourSolution">
    <div class="container">
        <div class="xb-title02"><?php the_field('solutions_title'); ?></div>
        <div class="xb-text03"><?php the_field('solutions_description'); ?></div>
        <div class="SolutionContent clearfix">
            <div class="owl-carousel">
            <?php 
                $args =  array('post_type' =>'solution',
                //'paged' => $paged,
                'posts_per_page'=>'-1'
                );                                                  
                query_posts( $args );                        
                $i=1; while ( have_posts() ) : the_post();   
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                $feature1 = get_post_thumbnail_id($post->ID);
                $image_alt = get_post_meta( $feature1, '_wp_attachment_image_alt', true);
                $solution_detail_display = get_field('solution_display_detail_page');
                $solutionImg_title = get_the_title($feature1);

            ?>
                <a href="<?php if($solution_detail_display == "Yes"){ the_permalink(); }else{echo "#";} ?>">
                   					
                    <div class="os-box01 nnt item clearfix">
                        <div class="osIconbox01">
                            <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>" title="<?php echo $solutionImg_title; ?>" />
                        </div>
                        <div class="osTitle01"><?php the_title(); ?></div>
                        <div class="text srvText01"><?php the_excerpt(); ?></div>                            
                    </div>
                <?php if(get_field('page_link')!=""){?> 
                    </a>
                <?php } ?> 
                </a> 
            <?php endwhile;wp_reset_query(); ?>
            </div>
        </div>
    </div>
</div>



<!-- Business Intelligence Section -->

   <?php if( have_rows('about_section_blocks') ): ?>
        <div class="abtsecMain">
            <div class="container">
                 <?php 
               while ( have_rows('about_section_blocks') ) : the_row();  
               $image = get_sub_field('icon','options');                       
            ?>
                <div class="abtsec_inner">
                    <img src="<?php the_sub_field('block_image'); ?>">
                    <div class="abtsec_inner2">
                        <h5><?php the_sub_field('block_title'); ?></h5>
                        <p><?php the_sub_field('block_description'); ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        </div>
    <?php endif; ?>


<!-- Data Delivery -->
<div id="data_delivery">
    <div class="container">
        <div class="DataBox01">
            <div class="xb-title02">
                  <?php the_field('data_delivery_title'); ?>
            </div>
        </div>
         <div class="DataBox02">
            <div class="xb-text01"> <?php the_field('data_title_description'); ?></div>
        </div>
        <?php if( have_rows('data_delivery_block') ): ?>
        <div class="DatasecMain">
                 <?php 
               while ( have_rows('data_delivery_block') ) : the_row();  
            ?>
                <div class="Datasec_inner">
                    <img src="<?php the_sub_field('icon'); ?>">
                    <div class="Datasec_inner2">
                        <h5><?php the_sub_field('title'); ?></h5>
                        <p><?php the_sub_field('short_description'); ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>

    </div>
</div>


<!-- Email Subscription Section -->
<div class="email_subc">
	<div class="container">
		<div class="email_subc_title">
		<h5>Lets get going !</h5>
		<h2>Connect with us to explore more...</h2>
	</div>
    	<?php //echo do_shortcode("[osd_subscribe categories='blog,management' placeholder='Enter your email address'  button_text='Request Now']"); 
              echo do_shortcode('[contact-form-7 id="32737" title="Request Call"]'); 
        ?>
    </div>
</div>

<!-- Business Section -->
<section class="business_section">
	<div class="container">
		<div class="bussiness_inner">
			<div class="business_left">
				<img src="<?php the_field('business_leftimage'); ?>" alt="Reasons Tend To Lead us The The Best Web Scarping Company In India" title="Reasons Tend To Lead us The The Best Web Scarping Company In India">
			</div>

			<div class="business_right">
				<h2><?php the_field('business_righttitle'); ?></h2>
				<ul class="accordion-box">
                        <!--Block-->

                        <?php if(have_rows('business_accordian')):
                        	  while(have_rows('business_accordian')) : the_row();
                         ?>

                        	<li class="accordion block">
                           		<div class="acc-btn">
                              		<div class="icon-outer"><span class="icon icon-plus flaticon-plus-symbol"></span> <span class="icon icon-minus flaticon-minus-symbol"></span></div>
                              			 <?php the_sub_field('title') ?> 
                           		</div>
                           		<div class="acc-content">
                              		<div class="content">
                                 		<div class="text">
                                    		<p> <?php the_sub_field('description') ?> </p>
                                 		</div>
                              		</div>
                           		</div>
                        	</li>

                        <?php
                    		endwhile;
                         	endif; 
                         ?>	                        	
                       
                      
                     </ul>
			</div>
		</div>
	</div>
</section>


<!-- Case Studies Section -->
<div id="CaseStudies">
    <div class="container">

        <div class="CaseTitleSec">
            <div class="CaseTitleSec_left">
                <i class="fa fa-briefcase" aria-hidden="true"></i>
                <h4>Primor Business Consulting</h4>
                <h2>Case Studies</h2>
            </div>
            <div class="CaseTitleSec_right">
                <a href="<?php echo site_url();?>/case-studies/">View More Cases ></a>
            </div>
        </div>
 </div>

        <div class="CaseStudy_inner clearfix">
            <div class="owl-carousel">
            <?php 
                $args =  array('post_type' =>'case_studies',
                //'paged' => $paged,
                'posts_per_page'=>'-1'
                );                                                  
                query_posts( $args );                        
                $i=1; while ( have_posts() ) : the_post();   
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                $feature1 = get_post_thumbnail_id($post->ID);
                $image_alt = get_post_meta( $feature1, '_wp_attachment_image_alt', true);
                $caseStudyImg_title = get_the_title($feature1);
            ?>
                <!-- <a href="<?php // the_permalink(); ?>"> -->  
                    <a href="<?php the_permalink(); ?>">
        			<h3>Case Study - <?php echo get_the_category()[0]->cat_name; ?></h3>
        			<h4><?php the_title(); ?></h4>
                    <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>" title="<?php echo $caseStudyImg_title; ?>" />
                    
                    </a>
               <!-- </a> -->
            <?php endwhile;wp_reset_query(); ?>
            </div>
        </div>
   
</div>


<!-- Company Completion Year Section -->

<div id="CompleteYear">
    <div class="container flex">
        
        <div class="CyLeft">
            <div class="cbcylft" style="background-image: url(<?php echo site_url();?>/wp-content/uploads/2019/02/bg.png);">&nbsp;</div>
            <div class="CyLeftImg"><img src="<?php the_field('completed_year_image'); ?>" alt="07 Years of Experience and Excellence" title="07 Years of Experience and Excellence "></div>
        </div>
        <div class="CyRight">
            <?php if( have_rows('completed_project') ):
                  while ( have_rows('completed_project') ) : the_row();  
            ?>
            <div class="CyRight_inner">
               <div class="CyRightIcon"><img src="<?php the_sub_field('block_icon'); ?>"></div>
               <div class="CyRightNumber"><h4><?php the_sub_field('block_number'); ?>+</h4></div>
               <div class="CyRightText"><p><?php the_sub_field('block_text'); ?></p></div> 
            </div>
            <?php endwhile;
                  endif; ?>   
        </div> 
     </div>     
</div>


<!-- Blog Section -->
<!-- 
<section id="HomeBlogMain">

    <div class="container">
         
        <div class="homeBlogBox01">
            <div class="xb-title02">
                  Some of our latest insights
            </div>
        </div>
        <div class="homeBlogBox02">
            <div class="xb-text01"> We write about web data gathering, analyze trends and data.</div>
        </div>

        <div class="homeBlog_inner">

            <?php 
                $args =  array('post_type' =>'post',
                //'paged' => $paged,
                'posts_per_page'=>'3'
                );                                                  
                query_posts( $args );                        
                $i=1; while ( have_posts() ) : the_post();   
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb_img' );
                $feature2 = get_post_thumbnail_id($post->ID);
                $image_alt = get_post_meta( $feature2, '_wp_attachment_image_alt', true);
                $blogImg_title = get_the_title($feature2);
            ?>

            <div class="homeBlogSingle">
                <div class="homeBlogimg">
                    <img src="<?php echo $thumb[0]; ?>" alt="<?php echo $image_alt; ?>" title="<?php echo $blogImg_title; ?>" />
                </div>
                <div class="homeBlogContent">
                    <a href="<?php echo get_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
                </div>
            </div>
        <?php endwhile;wp_reset_query(); ?>

        </div>

        <div class="homeBlogBtn">
            <a href="<?php get_site_url();?>/blog"  class="btn01 ">Explore More Resources</a>
        </div>

    </div>
    
</section> -->



<!-- Testimonial Section -->
<div class="xbtestimonial">
    <div class="testimonial_top_title">Testimonial</div>
	 <div class="xb-title02">What Our Client Says</div>
	<div class="container">
		<div class="testimonial_inner">
            <?php //echo do_shortcode( '[rt-testimonial id="28834" title="Homepage Testimonials"]' ) ?>
            <?php //echo do_shortcode( '[gs_testimonial transition="carousel"]'); ?>
            <?php echo do_shortcode( '[sp_testimonial id="28119"]'); ?>
		</div>
	</div>
</div>

<!-- Branch Addresses -->

<div class="branchAddress">
	<div class="container flex">
		<div class="branch_contact">
			<a href="mailto:sales@xbyte.io" target="_top"><span><i class="fa fa-envelope-o" aria-hidden="true"></i>sales@xbyte.io</span></a>
			<a href="tel:+917940392466"><span><i class="fa fa-phone-square" aria-hidden="true"></i>+91 (79) 403 924 66</span></a>
			
		</div>
			 <?php if( have_rows('branch_addresses') ):
               while ( have_rows('branch_addresses') ) : the_row();  
            ?>
                <div class="branch_inner">
                    <img src="<?php the_sub_field('country_icon'); ?>">
                    <div class="branch_inner2">
                        <h5><?php the_sub_field('country_name'); ?></h5>
                        <p><?php the_sub_field('country_address'); ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
		

</div>




<?php get_footer(); ?>
