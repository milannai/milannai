<?php
/**
 * Template Name: company profile
*/
get_header(); ?>


<div id="primary" class="content-area">
	<div class="containerd">
        <?php
        // For Page contat
            while ( have_posts() ) : the_post(); 
                the_content();
            endwhile;wp_reset_query();
        ?>
    </div>
</div><!-- .content-area -->

<?php 
/*$downloadId = $_GET['rdwtyp'];

if($downloadId != ''){

$currentDateTime = date('Y-m-d H:i:s');

global $wpdb;
$linkAddtime = $wpdb->get_var('SELECT link_generate_time FROM xbjnj_company_profile WHERE download_id ="'.$downloadId.'" ');

$start_date = new DateTime($currentDateTime);
$since_start = $start_date->diff(new DateTime($linkAddtime));
$expireTime = $since_start->h;

if($expireTime <= 24 && $linkAddtime != ''){

	$path = "https://www.xbyte.io/xbyteio-company-profile_final.pdf";
	$filename = "X-byte_company-profile.pdf";
	header('Content-Transfer-Encoding: binary');  // For Gecko browsers mainly
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($path)) . ' GMT');
	header('Accept-Ranges: bytes');  // For download resume
	header('Content-Length: ' . filesize($path));  // File size
	header('Content-Encoding: none');
	header('Content-Type: application/pdf');  // Change this mime type if the file is not PDF
	header('Content-Disposition: attachment; filename=' . $filename);  // Make the browser display the Save As dialog
	readfile($path);  //this is necessary in order to get it to actually download the file, otherwise it will be 0Kb


}else{
	header("Location: ".site_url()."/company-profile"); 
}

}
*/
?>

<?php get_footer(); ?>