<?php
/**
 * Template Name: White Paper
*/
get_header(); ?>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="banner_section" style="background-image: url(<?php echo get_the_post_thumbnail_url() ?>);">
     <div class="banner_section_inner">
        <h1><?php the_title(); ?></h1>
        <h3><?php the_field('brochure_banner_sub_title'); ?></h3>
     </div>
 </div>




      
        <!--Gallary section start-->
<div class="clearfix"></div>
    <div class="caseStudyList brochure-list">
        <div class="container">

            <div class="caseStudyList_inner">

                <?php 
                    $current_page = get_query_var('paged') ? get_query_var('paged'):1;
                    $args_case = array(
                    'post_type' => 'white_paper',
                    'posts_per_page' => 3,
                    'order' => 'ASC',
                    "paged" => $current_page
                    );
                                    
                    $query_case = new WP_Query($args_case);
                                    
                    while ($query_case->have_posts()) : $query_case->the_post();
                        $case_id = get_post_thumbnail_id($query_case->ID);
                        $case_featured_img = wp_get_attachment_image_src($case_id, 'large'); 
                        $whitepaper_detail_page_display = get_field('whitepaper_detail_page_display');
                ?>

                <div class="caseStudyListSingle">
                    <a href="<?php if($whitepaper_detail_page_display == "Yes"){ the_permalink(); }else{echo "#";} ?>">
                    <div class="caseStudyListimg">
                        <img src="<?php echo $case_featured_img[0]; ?>"  />
                    </div>
                    <div class="caseStudyListContent">
                        <h3><?php the_title(); ?></h3>
						<button class="button button1 brochure-btn">Download</button>
					</div>
                    </a>
                </div>
            <?php
                endwhile; 
                wp_reset_query();
            ?> 

        </div>     
                        
              
                <?php
                    $big = 999999999;
                    $pages = array(
                        'type' => 'array',
                        'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                        'format' => '?paged=%#%',
                        'current' => max( 1, get_query_var('paged') ),
                        'total' => $query_case->max_num_pages
                        );
                        $links = paginate_links($pages);
                ?>
                    <div class="pagination">    
                        <?php  
                            if($links != NULL){
                                foreach($links as $link){
                                    echo $link;
                                    }
                                }
                        ?>
                    </div>
                                           
        </div>
    </div>  

        <!--Gallary section end-->
<?php
endwhile;
endif;
?>

<?php get_footer(); ?>
