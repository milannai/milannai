<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<style>
.et-db #et-boc .et_pb_blog_0 .et_pb_post .entry-title a {
    font-family: 'Rubik',Helvetica,Arial,Lucida,sans-serif!important;
    font-weight: 700!important;
}

.et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta, .et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta a, .et-db #et-boc .et_pb_blog_0 .et_pb_post .post-meta span {
    font-family: 'Arimo',Helvetica,Arial,Lucida,sans-serif;
    color: #888!important;
    line-height: 1.8em;
}

.et-db #et-boc .et_pb_blog_0 .et_pb_post p {
    line-height: 1.8em;
}

.et-db #et-boc div.et_pb_section.et_pb_section_0 {
    background-image: url(http://www.xbyte.io/wp-content/uploads/2018/07/banner-bg.png)!important;
}

.et-db #et-boc .et_pb_section_0 {
    padding-top: 0px;
    padding-right: 9.8%;
    padding-bottom: 0px;
    padding-left: 9.8%;
    margin-top: 0px;
}
.et-db #et-boc .et_pb_text_0 h1 {
    font-weight: 500;
    font-size: 54px;
}

.et-db #et-boc .et_pb_column_0 {
    padding-top: 8vw;
    padding-right: 40px;
    padding-bottom: 4vw !important;
    padding-left: 40px;
}

.et-db #et-boc .et_pb_row_0.et_pb_row {
    padding-top: 0;
    padding-bottom: 0;
}

.et-db #et-boc .et_pb_textn {
    font-weight: 300;
    font-size: 25px;
    line-height: 1.8em;
}
</style>
<div class="et-db">
<div class="et_divi_builder ">
<div id="et-boc" class="et-boc">
   <div id="et_builder_outer_content" class="et_builder_outer_content">
      <div class="et_builder_inner_content et_pb_gutters3">
         <div class="et_pb_section et_pb_section_0 demo-two et_pb_with_background et_section_regular et_section_transparent">
            <div class="et_pb_row et_pb_row_0">
               <div class="et_pb_column et_pb_column_4_4 et_pb_column_0    et_pb_css_mix_blend_mode_passthrough et-last-child">
                  <div class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_light  et_pb_text_align_center">
                     <div class="et_pb_text_inner">
                        	<h1><?php _e( 'UH OH!', 'twentysixteen' ); ?></h1>
                            <div class="et_pb_module et_pb_text et_pb_textn et_pb_bg_layout_light  et_pb_text_align_center">
								<div class="et_pb_text_inner">
                					<p>We’re having trouble finding that one, Why not Give it another go!</p>
                				</div>
                			</div>
                     </div>
                  </div>
                  <!-- .et_pb_text -->
                  <!-- .et_pb_text -->
               </div>
               <!-- .et_pb_column -->
            </div>
            <!-- .et_pb_row -->
         </div>
         <!-- .et_pb_section -->
         
         <style>
            h3{font-size: 32px !important;line-height: 40px !important;}
            h4{font-size: 22px !important;line-height: 32px !important;margin-top: 20px !important;}
            .containernt p, .containernt li{font-size: 16px !important;line-height: 24px !important;}
            .containernt ul{padding-left: 20px !important;}
            .containernt li{list-style: disc !important;}
         </style>
         
         <div class="et_pb_section et_pb_section_1 et_section_specialty et_section_transparent">
               <div class="et_pb_row et_pb_row_3-4_1-4">
                  <div class="et_pb_column et_pb_column_3_4 et_pb_column_1   et_pb_specialty_column  et_pb_css_mix_blend_mode_passthrough">
                     <div class="et_pb_row_inner et_pb_row_inner_0">
                        <div class="et_pb_column et_pb_column_4_4 et_pb_column_inner et_pb_column_inner_0   et-last-child">
                           <div class="et_pb_with_border et_pb_module et_pb_blog_0 et_pb_posts et_pb_bg_layout_light" style="opacity: 1;">
                              
                              <div class="containernt">
                                  <h3>404 Page not found</h3>
                                  <p>The page you requested cannot be found. The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
                                  <h4>Please try the following:</h4>
                                  <ul>
                                    <li>If you typed the page address in the Address bar, make sure that it is spelled correctly.</li>
                                    <li>Open the <a href="http://www.xbyte.io">home page</a> and look for links to the information you want.</li>
                                    <li>Use the navigation bar on the left or top to find the link you are looking for.</li><li>Click the Back button to try another link.</li>
                                  </ul>
                              </div>
                           </div>
                        </div>
                        <!-- .et_pb_column -->
                     </div>
                     <!-- .et_pb_row_inner -->
                  </div>
                  <!-- .et_pb_column -->
                  <!-- .et_pb_column -->
               </div>
               <!-- .et_pb_row -->
            </div>
         
         <!-- .et_pb_section -->			
      </div>
   </div>
</div>
</div>
</div>


<?php get_footer(); ?>


