<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
 
    <!-- seo meta -->
    <meta charset="utf-8" />
    <meta http-equiv=X-UA-Compatible content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo get_field('xb_page_title'); ?></title>
    <meta name="description" content="<?php echo get_field('xb_meta_description'); ?>" />
    <meta name="ahrefs-site-verification" content="1cc61ee3c7c160d563a7072806b95c5b4b7cbacc253f85ea1679095f6d17c315">
    <meta name="google-site-verification" content="pKWkcUoq-tRWdCHxbnPpzg-lB4KtT0JdySPjr-692D4" />
    <meta name="yandex-verification" content="33df86a4b8cac226" />
    <meta name="msvalidate.01" content="31F9087EACA824596661BE3BDB536C9B" />
    <meta name="norton-safeweb-site-verification" content="apb74c427nt8voroihiuffg5cfog0omrg0r4w5dhngkusmeiy-7cah7-0ntl3lhkob7226-9xw2orpz25zask9dzqjfdyncu3hp2gdtjdsa5zn2b3imklpcep1ko2qbz" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="<?php echo get_permalink(); ?>" />
    <meta name="meta_classification" content="web scraping services, website data extraction, Data Crawling, Data Mining services, Price, Brand, Social Media Monitoring, Python Web Scraping and Web Crawling, HOSTED WEB CRAWLER AS A SERVICE, iOS and Android App Scraping - Mobile App Scraping Service, Data Scraping for ecommerce websites, Robotic Process Automation (RPA, Competitor Price Monitoring Services for eCommerce, Retail Website, Flight Price Intelligence, Scrape and Extract Airline Data, Travel, Hotel Price Intelligence -  Scrape, Extract Deals Reviews Data, Social Media Monitoring - Scrape, Extract Data LinkedIn Facebook, Product, Pricing, Review Data Scraping For eCommerce, Restaurant, Location Intelligence - Scrape, Extract Data Store Location, Movie/Cinema Showtime Intelligence - Scrape Data For Theatre Name " />
    <meta name="meta_business" content="Top Data Extraction and Web Scraping Services Provider Company in USA, INDIA providing Website data extraction and Web Scraping services using Python." />
    <meta name="meta_copyright" content="X-Byte Enterprise Crawling" />
    <meta name="meta_author" content="Mr. Alpesh Khunt" />
    <meta name="meta_identify_url" content="https://www.xbyte.io" />
    <meta name="meta_reply_to" content="sales@xbyte.io" />
    <meta name="meta_distribution" content="Global" />
    <meta name="meta_revisit_after" content="daily" />
    <meta name="language" content="en-US" />
    <meta name="meta_rating" content="General" />
    <meta name="meta_audience" content="All" />
    <meta name="meta_coverage" content="Worldwide" />
    <meta name="meta_document_state" content="Dynamic" />
    <meta name="meta_publisher" content="xbyte.io" />
    <meta property="og:type" content="website" /> 
    <meta property="og:url" content="https://www.xbyte.io" /> 
    <meta property="og:title" content="<?php echo get_field('xb_page_title'); ?>" /> 
    <meta property="og:description" content="<?php echo get_field('xb_meta_description'); ?>"/>
    <meta property="og:image" content="https://www.xbyte.io/wp-content/uploads/2018/07/logo.svg" /> 
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="300" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@xbyte.io" />
    <meta name="twitter:creator" content="@xbyte.io" />
    <meta name="twitter:title" content="<?php echo get_field('xb_page_title'); ?>" />
    <meta name="twitter:description" content="<?php echo get_field('xb_meta_description'); ?>" />
    <meta name="twitter:image" content="https://www.xbyte.io/wp-content/uploads/2018/07/logo.svg" />
    <meta name="twitter:image:alt" content="X-Byte-logo">
    <link rel="shortcut icon" href=images/favicon.png />
    <meta name=mobile-web-app-capable content=yes>
    <link rel=icon sizes=196x196 href=images/favicon. />
    <meta name="X-Byte Enterprise Crawling" content=images/favicon.png />
    <meta name=msapplication-TileColor content=#202429 />
    <meta name=apple-mobile-web-app-capable content=yes />
    <meta name=apple-mobile-web-app-status-bar-style content=black />
    <meta name=apple-mobile-web-app-title content="X-Byte Enterprise Crawling" />
    <meta name=apple-mobile-web-app-title content="X-Byte Enterprise Crawling" />
    <meta name="p:domain_verify" content="6f4aada105eba785a5e0f663bb7f1ea4"/>

    <!-- seo meta -->

    <link rel="icon" href="<?php echo bloginfo('template_url'); ?>/images/favicon.jpg" type="image/jpg" sizes="16x16">
     <!-- worksans font -->
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
    
    <!-- jQuery min -->
    <script src="<?php echo bloginfo('template_url'); ?>/js/jquery.min-1.11.3.js" defer ></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/custom.js" defer ></script>

    
    <!-- Menu CSS and js-->
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/regdev.css">
    <script type="text/javascript" src="<?php echo bloginfo('template_url'); ?>/js/rgdev.js" defer ></script>
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/boilerplate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/flaticon.css">
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/template.css">
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/responsive.css">
    <script src="<?php echo bloginfo('template_url'); ?>/js/jquery.anchorlink.js" defer ></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/jquery.countimator.min.js" defer ></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/bs-collaps.js" defer ></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/respond.min.js" defer ></script>
    
    
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/owl.carousel.min.css">
    
    <!--IZI modal Script-->
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/iziModal.min.css">
    
    	
    	
    <!--Canvas Animation Script-->
    <script src="https://code.createjs.com/createjs-2015.11.26.min.js" defer ></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/home-animation.js" defer ></script>	
    
    
    	
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/css/iziToast.min.css">
    <script src="<?php echo bloginfo('template_url'); ?>/js/iziToast.min.js" defer ></script>	
    
	<?php wp_head(); ?>
    
    <script src="<?php echo bloginfo('template_url'); ?>/js/iziModal.min.js" defer ></script>
    
    <!--Carosal modal Script-->
    <script src="<?php echo bloginfo('template_url'); ?>/js/owl.carousel.js" defer ></script>        
    
    <script src="<?php echo bloginfo('template_url'); ?>/js/script.js" defer ></script>
   
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-123159302-3" defer ></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-123159302-3');
    </script>
    <script type='text/javascript'>
window.__lo_site_id = 143915;

    (function() {
        var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
        wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
      })();
    </script>

</head>


<?php if(is_front_page()){ ?> 
    <body id="home-cs" onLoad="init();">
<?php } else { ?> 
    <body <?php body_class(); ?>>
<?php } ?>
 
<header class="xb-head ani-1" id="main-head">
	<div class="head-container clearfix">
		<div class="logo">
            <?php $logo = get_field('logo','options'); ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $logo['url']; ?>" alt="<?php echo $logo['alt']; ?>" title="<?php echo $logo['title']; ?>" /></a>
        </div>
		<nav class="rgdev no-ani">
            <?php
            // For navigation
                wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false,'menu_class'=>'mobile-sub rgdev-list') );
            ?> 
		</nav>
		
		
	</div>
</header>