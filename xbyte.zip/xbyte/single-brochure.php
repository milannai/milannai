<?php get_header(); ?>

<div id="primary" class="content-area single-brochure_inner">
	<div class="containerd">
        <?php
        // For Page contat
            while ( have_posts() ) : the_post(); 
                the_content();
            endwhile;wp_reset_query();
        ?>
    </div>
</div><!-- .content-area -->

<?php get_footer(); ?>
