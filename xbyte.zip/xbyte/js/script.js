var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
function init() {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("A14907C3CFA61245982069F7742A9AAD");
	var lib=comp.getLibrary();
	var loader = new createjs.LoadQueue(false);
	loader.addEventListener("fileload", function(evt){handleFileLoad(evt,comp)});
	loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
	var lib=comp.getLibrary();
	loader.loadManifest(lib.properties.manifest);
}
function handleFileLoad(evt, comp) {
	var images=comp.getImages();	
	if (evt && (evt.item.type == "image")) { images[evt.item.id] = evt.result; }	
}
function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	var queue = evt.target;
	var ssMetadata = lib.ssMetadata;
	for(i=0; i<ssMetadata.length; i++) {
		ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
	}
	exportRoot = new lib.homeanimation();
	stage = new lib.Stage(canvas);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		stage.addChild(exportRoot);
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;
			
//		Custome Responsive Code	 ( Replace this code =   			var iw = window.innerWidth, ih=window.innerHeight;	   )
					var divAdd = document.getElementById("md-Canvas");

					var iw = divAdd.offsetWidth,
						 ih = divAdd.offsetWidth;

//		Custome Responsive Code	End
			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;            
			stage.tickOnUpdate = false;            
			stage.update();            
			stage.tickOnUpdate = true;		
		}
	}
	makeResponsive(true,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}

// New

$( document ).ready(function() {
    

 $('.rgdev-list ul').addClass('rgdev-submenu');
 $('.rgdev-list ul ul').removeClass('rgdev-submenu');
 $('.rgdev-list ul ul').addClass('rgdev-submenu-sub');

    // Select all links with hashes
$('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });
  
    /*
    function RemoveBaseUrl(url) {
       
        var baseUrlPattern = /^http?:\/\/[a-z\:0-9./]+/;
        var result = "";
        
        var match = baseUrlPattern.exec(url);
        if (match != null) {
            result = match[0];
        }
        
        if (result.length > 0) {
            url = url.replace(result, "");
        }
        
        return url;
    }
    
    
    $('#home-cs #menu-main-navigation li.rmxb a').attr('href',function(i,o){
      return RemoveBaseUrl(o) ;
    });
    */
    
     $(function() {
          var $clientcarousel = $('#clients-list');
          var clients = $clientcarousel.children().length;
          var clientwidth = (clients * 220); // 140px width for each client item 
          $clientcarousel.css('width', clientwidth);
        
          var rotating = true;
          var clientspeed = 0;
          var seeclients = setInterval(rotateClients, clientspeed);
        
          $(document).on({
            mouseenter: function() {
              rotating = false; // turn off rotation when hovering
            },
            mouseleave: function() {
              rotating = true;
            }
          }, '#clients');
        
          function rotateClients() {
            if (rotating != false) {
              var $first = $('#clients-list li:first');
              $first.animate({
                'margin-left': '-220px'
              }, 2000, function() {
                $first.remove().css({
                  'margin-left': '0px'
                });
                $('#clients-list li:last').after($first);
              });
            }
          }
     });
    /*Logo
    /*on scroll change header------------------------------------------------------>*/
 
	var trigger = false;
	$(window).scroll(function(){
	  if($(window).scrollTop() > 100 && !trigger){
		  $('#main-head').addClass('fix_head');
		  trigger = true;
	  }
	});

	$(window).scroll(function(){
	  if($(window).scrollTop() < 100 && trigger==true){
		  $('#main-head').removeClass('fix_head');
		  trigger = false;
	  }
	});
    
    /* 
    //click to scroll script ------------------------------------------------------
    $('#home-cs li.rmxb .scroller_C').anchorlink({
      timer : 750,
      scrollOnLoad : true,
      offsetTop : -80,
      focusClass : 'js-focus',
      beforeScroll: function() {},
      afterScroll : function() {}
    });
    */

 /* Flip career page start */   
 jQuery('.hover').hover(function(){
 jQuery(this).addClass('flip');
 },function(){
 jQuery(this).removeClass('flip');
 });
 /* Flip career page end */  

});
/*animated text script ------------------------------------------------------>*/
$(function() {
  $(".counter").countimator();
});	
	
/*IZI modal script--------------------------------------------------*/
	
	function moWidth() {
	return $(window).width() > 310 && $(window).width() <= 700 ? "90%" : $(window).width() > 699 ? "50%" : 60
}	
	
    
	
	
/*input Lable Up script--------------------------------------------------*/
	
	/*
$( ".np-formbox" ).children('input').focusin(function() { 
		$(this).parent('.np-formbox').children('.np-lable').addClass('fly'); 
	})
$( ".np-formbox" ).children('input').focusout(function() { 
		if($(this).val().trim() == ''){ 
			$(this).parent('.np-formbox').children('.np-lable').removeClass('fly'); 
		} 
	})
    */


    
    
jQuery( document ).ready(function() {
   jQuery( ".np-formbox" ).children('input').each(function(){ 
		if(jQuery(this).val().trim() == ''){ 
			jQuery(this).parent('.np-formbox').children('.np-lable').removeClass('fly'); 
		}else{
		   jQuery(this).parent('.np-formbox').children('.np-lable').addClass('fly'); 
		} 
	})
	jQuery(".changeinq_link").click(function(){
		jQuery(".changeinq_link").removeClass("active");
		jQuery(this).addClass("active");
		var clasname = jQuery(this).attr("data-class");
		var idname = jQuery(this).attr("data-id");
		jQuery("."+clasname).hide();
		jQuery("#"+idname).show();
	})
    //jQuery('#menu-main-navigation').append('<li id="inq-btn" class="rgdev-item"><a href="javascript:void(0);"  data-izimodal-open="inquire" class="headBtn iz-modal ani-1">INQUIRE NOW</a></li>');
    
    
    jQuery('#ourSolution .owl-carousel').owlCarousel({
        loop:true,
        autoplay:true,	
        autoplayTimeout:3000,
    	autoplayHoverPause:true,
        margin:10,
        nav:true,
        dots: true,
        responsive:{
             0:{
                items:1
            },
            500:{
                items:2
            },
            991:{
                items:3
            },
            1025:{
                items:4
            }
        }
        
    });

    jQuery('#ourService .owl-carousel').owlCarousel({
        loop:true,
        autoplay:true,  
        autoplayTimeout:3000,
      autoplayHoverPause:true,
        margin:10,
        nav:true,
        dots: true,
        responsive:{
             0:{
                items:1
            },
            500:{
                items:2
            },
            991:{
                items:3
            },
            1025:{
                items:4
            }
        }
        
    });

     jQuery('#CaseStudies .owl-carousel').owlCarousel({
        loop:true,
        autoplay:true,  
        autoplayTimeout:3000,
      autoplayHoverPause:true,
        margin:10,
        nav:true,
        dots: true,
        responsive:{
             0:{
                items:1
            },
            500:{
                items:2
            },
            991:{
                items:3
            },
            1025:{
                items:4
            }
        }
        
    });
    
    

    jQuery(document).on("click", ".iz-modal", function (t) {
		t.preventDefault(), jQuery("#" + jQuery(this).attr("data-izimodal-open")).iziModal("open")
	}); 
	
	jQuery(".iziModal").iziModal( {
		headerColor: "#E61F2D", 
		width: moWidth(),
		overlayColor: "rgba(0, 0, 0, 0.5)",
		fullscreen:false,
		padding:0,
		//openFullscreen: true,
		transitionIn: "fadeInUp",
		transitionOut: "fadeOutDown", 
	//bodyOverflow:true
	})	
   	
	
})


/* Footer Award Image Slider */

$(function() {
          var $awardcarousel = $('#footer_award');
          var awards = $awardcarousel.children().length;
          var awardtwidth = (awards * 220); // 140px width for each client item 
          $awardcarousel.css('width', awardtwidth);
        
          var rotating = true;
          var awardspeed = 0;
          var seeclients = setInterval(rotateAwards, awardspeed);
        
          $(document).on({
            mouseenter: function() {
              rotating = false; // turn off rotation when hovering
            },
            mouseleave: function() {
              rotating = true;
            }
          }, '#footer_awardMain');
        
          function rotateAwards() {
            if (rotating != false) {
              var $first = $('#footer_award li:first');
              $first.animate({
                'margin-left': '-220px'
              }, 1000, function() {
                $first.remove().css({
                  'margin-left': '0px'
                });
                $('#footer_award li:last').after($first);
              });
            }
          }
     });

