(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"home_animation_atlas_", frames: [[0,0,128,131],[0,133,45,45]]}
];


// symbols:



(lib.poligon01 = function() {
	this.spriteSheet = ss["home_animation_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.xIcon = function() {
	this.spriteSheet = ss["home_animation_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(0.5,1,1).p("AArAAQAAASgMANQgNAMgSAAQgRAAgNgMQgMgNAAgSQAAgRAMgNQANgMARAAQASAAANAMQAMANAAARg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.3,-5.3,10.6,10.6);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.xIcon();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.poligon01();
	this.instance.parent = this;
	this.instance.setTransform(-64,-65.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-65.5,128,131);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#030104").s().p("Ah5UCIADggQAQiKgJg6IAHABQAkkygEgWIgBgGIAGAAIAQiTIgJgDIgBADIgBgRIAIACQALgWAOh6QAOh2gFgaIAAgDIAJAAIATiiIABABIARhrQgBAkgFBCIgCAQIALgMQAPgSAZgFQAGgBAHgBQAOABAUAEIAHACIgDgPIgzhkIA3BWIAEgJQAPgiAegIIANgDIhagpIBNAYIgKgZQgFgYATgcIAEgHIgZgEIgBAAQgnAMghAGIBDgZIgGgFQgMgLgRgbIgEgGIgXAiIAZgzIgWAMIgOABQgVAAgUgMIgJgFIAFAqIgPg2IgGAKQgZApgsADIgOAAIBBA1Ig/gpIABALQABAYgNAXIgFAJIBEgGQgmAIgfABIgCAAIgSAOIAGAEQAcATAFApIABAJIBQhLIheBmIAggFQAjAAAQAkIAFAMQgUgnglAAIgOACQgRADgKALIgHgCIhVBYIAWgEQAJgCALAAQAggBAlAbQAvAiAEAsQgMgwgpgbQghgWglAAQgLAAgOACIgaAIIgBABQgbAah1B5IgMAMIAQgEQAZgEAYAAQBDAAA7AnQBHAyAVBRQgWhKhEgwQg6gohCAAQgTAAgXADQgqAJgxAwQgdAfgtA0IAHAHQAKgIAYgFQAmgIAnAAQBeABBLAvQBSA1AeBfQgghThJg4QhKg2hbAAQgfAAgjAHQhOAPhgBaQg5A7hXBeIAGAIQA/giA6gMQArgIAmAAQBtAABoA8QCBBLA2CCQgvhrhphJQhwhNh9AAQgqAAgpAIQhmAVhdBMIgEgCIgDADQgsAthTBQIgcAAICEh9QAsgqA9hBQBThvgki4QgaiEhahfQhZhgiCgOIgBAAIhxANQhdAMh+ALIAAgLID2giQAFAAAEgLIADACIACAAQAbgCAbgEQCoghBmiYQBliZghirQgZiAioiFIiKhsIAHAAQBDAvB3BWIAEACIAGgGQBtBQB7gBQAlAAAngHQCsghBgiOQBeiLgZirIAPgDIgBgFQgNhHgLhPIAFAAQAaBvAbCEQAIAbAvA5QCMCbDDAAQA0AAA3gLQCMgbA9hKQAbgsAwhGIBciPIAJAAIhkCrIgDAFIAOAHQhKByAcCTQAXB2BcBiQBcBhBzAaQA2AMAcAAQANAAAGgDIFDhWIAAACQhEAYhyAkIgEACIAEAVQiOAwhGCEQhGCGAeCXQAkC5BxA/QA8AjCgA8QAsARAcALIAAAGIivg/IgGARQhRgXhDgBQglABgfAGQizAjhbCYQhcCYAjC1QAGAiBPCMIAIAOIgLAAIgzhOQhVh3hTgtQhKgoheAAQguABg2AJQhbAThDAoQBFgvBbgRQAugKAtABQCbAAB9BuIAIgGIhsi5IgJAEQhwinioAAQghAAgnAGQheAUhABOQA/hUBkgUQAkgHAgAAQCEAABrBsIAIgGIhkizIgDAAQg/hlhvgBQgcABgZAFQgtAIgkAVQAngYAvgJQAYgFAWABQBEAAA/AqIAHgGQhNiRgIgJQg0hKhEABQgPAAgLACQgpAIgnAoIgBABIAAADIgYDbIgCAQIAJgKIgIALIgBABIAAABIgVDOIAIADIgKAPIgBABIAAABQgSCLgYDbIAGABIgMAiQgJBHgPBigALYEFQiAAZhMBvQhNBvANCCIAAABICSD/IAKgDQgZiwBhiTQBfiSCvgjQAkgGAkgBQAVAAAaADIASACIgOgKQgagWhngqQhmgsgogIQgNgDgQAAQgWAAgfAFgAu2A4IgBAKQDiBGAyEDQAYB9guB8IAJAFQCSiRAOgZQBFhigZiAQgQhQg+hFQg/hIhKgFIgKAAQhYAAiZAdgAIBCwQhWAQgzBGQg0BIAKBWIABABIByDDIABgSQABiMBRhdQBSheCIgdIAQgDIgPgHQiNg7hIAAQgNAAgMADgAqDAXIgRADIAQAGQCMA2AfCiQASBeglBiIAIAGIA5g3IgFgGQBYhVgXh2QghipihAAQgnAAgrAKgAE7GAIAIAQIABgSQAEhbA7g7QA7g7BcgPIARgDIgPgGQhFgeiFg1IgCgBIgBABIgCAAIgKgBIgBAAQgxAKgeAvQgfAvAKAxIAJgCIgBAEIgEACIgDgCQAGAIBWCcgAnYgBIgYAFIAOAGQBlAxAWB2QAOBFgbBMIAJAEQAwgyA7g5QBAhLgMg9QgNhDhJglIgBgBIgCAAQhPADhkASgALnjcQhSBgAeCXQAhCsCjA+IABAHIBqApIAGgIQhRhbgYh4Qg1kVDeidIANgJIg6AAIADAEIgCAEIgCgJQjBAlhSBhgAA/BXQgrAIgGAzQgFAygCAoIAAANIAJgJQAfgfAtgJQAQgDAOAAQAjAAAeASIAQAKIg+h1IgJAGQgWgdggAAIgPACgAJijlIgCAGQiYA2AiCpQATBhBYA0QAMAJCjA/IAFgIQhQhKgVhsQghiqB4iAIANgNgACFBJIAAADIBMB9IAAgSQgBghAcgoQAcgnAggKIANgDIhjgsIgCALQgKgDgPAAIgBAAQgvAJgCAqgAkJgZIALAHQAuAfANBBQAGAigJAjIgDAPIAMgKQApgkAbgWQAsgygFgbQgKgwgmABIgGAAIgBgBIgGgOgAH+jJQhqAVgwAqQgxArANBAQAMA+A/AZIgFAPICBAwIAFgHQgogugNhCQgWhyBOhRIALgMgADQh1IADAUQgmAUAJAsQAFAbA7AZQAjAPAzARIACAAIANgDIgGgGQgcgggIgpQgLg8AhguIAJgLgArYpLQAdA2AMA9QAdCVhLCSQhKCSiNA6IADAKICtgUIABgKQAMAAAdgGQB3gWBEhnQBEhmgYh7QgRhVhDg9QhDg0hHgvgAn5mqQARAlAHAlQAVBpgwBfQgwBfhiAyIADAJIBGgGIABgGQBggEA9hSQA/hSgThiQgQhRhnhLIgPgLgAl6lNQANAjAEASQAfCkiPBYIAEAJICCgMIAAgQIALAAQA1gKAegyQAegwgKg2IgKgeIiVhugAjPjSQAMAtgaAxQgaAygoAUIADAJICkgPQAPgDALgYQALgVgDgSIAAgBIgMgZIgBgBIhkhGIgLgIgADJkiQgYAggTAbQgfAvAFAXQACAOARARQAOAOALAAQAEAAAFgCICHgrIgBgJQgmgIgjgjQgigjgCgoIAAgNgAjYj2IB2BdIAFgJQAPAIAPAAQAHAAAGgBQAygKAAg0IAJgBIgbiSIgNAKIgBACQgfBRhaARQgPACgOAAQgPAAgOgDgAASjbQAHAnAoAAIAUgCQASgDASgTIAJAGIBEh2IgaAEIgSAHQgQADgQABQg7gBg6grIgJgHgAGMi4IBggfIgPgEQh/gqgdiUQgEgYAAgcIAAgSIgJAOQgZApgdAsQggA3AHAnQALA4A0AcQAgARAiAAQARAAAUgFgAFuorIABAEQgpBJAPBOQANBBBCA+QAyAvAzAAQAQgBAQgEICyg2IAAgKQhsgQhPhKQhPhJgUhrQgKgxAEgpIgJgDgAi7kQQAOAAAQgEQCBgYgMh8IAHAAIgWhtIgGARQgxCHiXAdQgZAFgvAAIgSAAIBXBCIAMgQQAZAZAoAAgAHur3IABABQgWATgIA+QgHBEAIApQAYB9BrBJQBQA4BbAAQAeAAAggGIB0geIAAgJQiIgfhkhgQhjhhgbiJQgShbAWhTIgJgEgAgWm9QAXB+BrABQASAAAYgFQA3gKARgoIAKAEIA8hnIgOAFQgqATgIAAQghAIgjgBQhvAAhJhQIgLgLgAn4nMQBiBKAIADQAjASAuABQAYAAAZgFQBVgRA/hFQBAhGgQhPIgXh5IgKgBQg0DYjZAqQgfAGggABQggAAgfgIgAhLrcIAWBvQARBVBOAuQA6AhA9AAQAXAAAWgEQBMgPAtg4IBKh1IgHgHQg1Ahg6ALQgsAJgqAAQigAAhniGgAm2nfQAagBAggFQB2gXBUhrQBThsgTh0Igji0IgKABQgHCQhoBxQhpByiPAcQgnAHgpAAQg2AAg9gOIgEAJIB3BVIAFgDQBDA4BYAAgAh1u4IASBgQAYB7B0A+QBUAtBXAAQAgAAAjgHQCVgdAvhwIADAAIAohAIgHgHQhAAmhUAQQgzAKguAAQhRAAhSgcQiAgqhThog");
	this.shape.setTransform(0,0,1.517,1.517);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-205.5,-194.4,411,388.8);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgiAjQgOgOAAgVQAAgTAOgPQAPgOATAAQAVAAAOAOQAOAPAAATQAAAVgOAOQgOAOgVAAQgTAAgPgOg");
	this.shape.setTransform(4.9,4.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,9.8,9.8), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgaAaQgLgLAAgPQAAgOALgMQAMgLAOAAQAPAAALALQALAMAAAOQAAAPgLALQgLALgPAAQgOAAgMgLg");
	this.shape.setTransform(3.8,3.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,7.5,7.5), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgsAsQgRgSgBgaQABgZARgTQATgRAZgBQAaABASARQATATAAAZQAAAagTASQgSATgaAAQgZAAgTgTg");
	this.shape.setTransform(6.3,6.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,12.5,12.5), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhMBNQgfgggBgtQABgsAfggQAggfAsgBQAtABAgAfQAfAgAAAsQAAAtgfAgQggAfgtAAQgsAAgggfg");
	this.shape.setTransform(10.9,10.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,21.7,21.7), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("Ag7A7QgZgYAAgjQAAgiAZgZQAZgZAiAAQAjAAAYAZQAaAZAAAiQAAAjgaAYQgYAagjAAQgiAAgZgag");
	this.shape.setTransform(8.5,8.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,16.9,16.9), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DE2424").s().p("Ag4A5QgXgYAAghQAAggAXgYQAYgXAgAAQAhAAAYAXQAXAYAAAgQAAAhgXAYQgYAXghAAQggAAgYgXg");
	this.shape.setTransform(8,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,16,16), null);


(lib.XIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_118 = function() {
		this.gotoAndPlay(30);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(118).call(this.frame_118).wait(1));

	// Layer_2
	this.instance = new lib.Tween3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-20.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-0.5,alpha:1},29).wait(90));

	// Layer_1
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-20);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:0,alpha:1},29).to({rotation:180},89).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-85.5,128,131);


(lib.redFlash01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai7ecIgBgCIgBgDIAFgwQAXjRgNhWIABgDIACgCIADgBIAFABQA3nKgGghIAAAAIgCgJIAAgDIABgDIADgBIAGAAIAXjXIgFgBIgCADIgEABIgDgCIgBgDIgBgZIABgDIACgCIADAAIAIACQAQgoAUiuQAVizgHglIAAgBIgBgGIAAgBIgBgDQgRhFg9gpQgxggg3AAQgRAAgUAEIglALIgBABQgpAniyC4IgGAFIAIgCQAngHAkAAQBoAABaA9IAAAAQBtBMAgB9QAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQgghvhmhIQhXg8hiAAQgeAAghAGQg/ANhJBIQgrAthCBMIAEAFQARgLAhgHQA7gMA8AAQCPAABzBKQB+BQAvCSQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQgwh9hthSQhvhSiIAAQgvAAg0AKQh2AXiRCIIAAAAQhWBXiACNIADAGQBfg0BWgRQBDgMA5AAQCnAACeBdQDHByBRDGQAAABABAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQhHigiehvQioh0i8AAQhAAAg9ANQiZAeiMB0IgDABIgDAAIgDgCIgBACQhEBEh+B5QAAAAAAABQgBAAAAAAQgBAAAAAAQAAAAgBAAIgrAAIgCAAIgCgDIAAgCIABgDIDIi+IAAAAQBCg/BdhjIAAAAQB8img3kVQgmjHiHiOQiGiRjEgVIisATQiNASi/ASIgCgBIgCgCIgBgDIAAgQIABgDIADgCIF2gzIAAAAQAFgBAEgMIACgDIADgBIADABIADADIABAAQApgEAogHQD9gyCajkQCYjmgykDQgli/j+jJIjRijIgCgDIAAgCIACgDIADgBIAKAAIADABQBmBHC1CCIAAAAIACABIAGgHIAEgBIADABQCkB3C4AAQA5AAA7gLQEBgyCRjVQCNjSglkBIAAgDIADgDIATgDIgBgDQgThtgRh3IABgDIACgCIADgBIAHAAIADABIACADQAnCpAoDHIAAAAQAMApBHBVQDTDqEmAAQBPAABSgQQDTgqBchuQAphDBHhqICMjZIABgBIADgBIAOAAIADABIACADIgBAEIiXECIgCAEIAQAIIACACIABACIgBADQhvCtArDbQAiCyCKCTQCLCTCtAnQBRASAqAAQATAAAHgDIABAAIHqiEIADAAIACACIABACIAAAEIgBADIgCACQhnAkisA3IAAAAIgDABIAGAcIAAAEIgDACQjXBIhpDHQhoDIAsDlQA2EWCqBfQBbA1DyBbQBDAZAqASIACACIABADIAAAIIgBADIgDACIgDAAIkEhfIgIAWIgCADIgEAAQh5gkhmABQg3AAgvAJQkMA0iKDmQiKDkA0ERQAKA0B3DTIALAUIABAEIgCACIAAABIgWAAIAWAAIgDABIgQAAIgCgBIgBAAIgBgCIhNh1QiBi0h8hEQhwg7iNAAQhGAAhSAPQiIAbhmA9QAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQABAAAAgBQAAAAAAgBQABAAAAAAQBphHCLgcQBIgOBFABQDqgBC+CnIAFgDIifkSIgKAFIgDAAIgDgCQioj8j8AAQgyAAg6AKQiOAdhgB1QAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAgBABAAQBgiCCbgdQA3gMAwAAQDJAACjCkIAFgEIiUkKIgCABIgDgBIgCgCQhdiYimAAQgqAAgmAIQhDANg3AfQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQA9glBIgPQAlgHAhABQBngBBgBAIAFgFQhzjXgLgOIgBAAQhNhthlAAQgWgBgQAEIAAAAQg+ALg5A9IgBABIAAABIgkFMIAAAAIgBAIIACgCQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAgBABABQAAAAABAAQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAIgBAEIgMAQIAAAAIAAABIAAABQgMB4gUC8IAIADIADABIABAEIgBACIgPAWIAAABIAAABQgbDRglFIIAEACIADABIABADIAAACQgKAbgIAYQgMBrgYCVIgCADIgDABIgGAAIAAAAIgDgBgAShGJQghAAguAJQjBAlhzCnQhyCmATDEIAAABIDbF9IAGgCQgkkLCTjeQCSjgELg0QA3gLA3AAQAgAAApAEIAIABIgGgFIgBAAQgnggibhBQiZhBg+gMIAAAAQgTgGgWABIgBAAgA2dBaIAAAHQFWBrBLGLQAlC8hEC8IAGADQDbjYAUgmIAAAAQBoiTgmjAQgYh4hdhoQhdhrhugIIgQAAQiEAAjlAsgAMMEPQiBAZhNBpQhNBqAPCAIClEZIAAgKQACjWB9iOQB8iPDRgtIAAAAIAIgCIgHgDIAAAAQjWhZhsAAQgTAAgRADgAvPAnIgIACIAHADQDXBTAwD4QAbCOg3CVIAFAEIBRhOIgEgEIgBgEIABgDQCDiAgiiwQgxj8jxAAQg7AAhAAOgAFhFDIACACIABAEIgCAGIgBACIgBABIgEACQAXAnBvDJIAFAIIAAgKQAGiLBbhbQBbhaCNgYIAJgBIgIgDQhogtjKhQIgCAAIgBAAIgDAAQgHAAgJgBQhHAOgtBGQgsBDAMBFIAJgCIABAAIACABgArLADIgWAEIAHADQCcBMAjC2QAUBognBxIAGAEQBIhLBXhVIAAAAQBghwgRhaQgUhkhtg3IgBgBIAAAAQh4AEiXAcgARrlMQh7CQAtDlQAxEAD1BeIADACIABACIAAAHICbA8IAEgFQh5iLgki0QhSmpFVjvIAAgBIAGgEIg+AAIAAAAIAAAEIgEAFIgCACIgDAAIgDgBIgBgCIgCgJQkfA4h7CQgAhqEYQBJA1AGBEIAAAAIAGAAIAdjxIgBAAQgeg3g1AAQgKAAgLABQgXAFgOAPIgDACIgDAAIgHgDIh0B4IARgDIAAAAQAOgDASAAIAAAAQAygBA6AqgABhCIQg+ANgIBJQgIBLgDA9IAAAGIAEgFQAxgvBFgOQAZgFAWABQA3gBAvAeIAAAAIAIAFIhTidIgJAFIgDABIgDgCQghgpguAAQgKAAgLACgAOilZIgCAIIgBACIgCABQjjBQAyD9QAdCRCEBNIAAAAQARAOD0BeIADgGQh5hvggilQgzkEC4jDIAAAAIAHgIgADPBwIAAABIBpCuIAAgKQgBg0Arg9QAsg9AxgPIABAAIAHgCIiEg6IgCAKIgBACIgDACIgCAAQgPgEgWABIAAAAQhDAMgEA9gAkpDoIAGgFQA/g4ApggIAAAAQBAhIgHgoQgNhEg1gBIgJABIgDAAIgCgCIgBgBIgBgCIgIgSIipAcIAGAEIAAAAQBIAwATBlIAAAAQAKA1gOA2IABAAgAMHksQigAehHA/QhIBAATBfQARBbBeAlQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIgHATIC7BFIAEgGQg8hFgThkQgiivB3h9IAGgGgAAogEIAEACIABACQgBA4gJBjIgBAJIAGgHQAYgdAogHIgBAAQAKgCALgBQAXABAeAHIADAAIgDgNIhNiYIAAgEIACgCIAEgBIADACIBOB6IADgFQAYg0AwgOIAGgBIh8g4IgDgDIAAgDIADgDIADAAIBrAgIgLgbIgBgBQgHgoAdgrIAAAAIACgEIgegFQg7ASgyAJIgDgBIgCgDIAAgDIADgDIBdgiIgDgDQgSgQgbgqIgCgDIgeAtIgDACIgEAAIgCgDIAAgEIAfhAIgUALIgCABIgVACIAAAAQghgBgggSIgFgDIAHA2IgBAEIgDACIgEgBIgCgDIgUhHIgDAFIAAABQgnBAhGAFIgIAAIBYBGIABADIAAAEIgEACIgDgBIhXg3IAAAFQADAmgVAlIgDAFIBfgIIADABIACAEIgBAEIgDABQg7ANgvACIgBAAIgUAPIADACQArAdAIBBIABAFIBzhsQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAAAABABIgCAEIiGCRIAigGIABAAQA5AAAaA6IADAHIAYiRIACgDIADgBIAAAAgAFBiuIAEAZIAAADIgCACQg2AdAMA/QAJAnBVAlQA1AXBNAYIAAAAIALgCIgDgCIAAgBQgqgxgNg/QgRheAzhIIAFgGgAxLt7QArBSATBbQArDlhxDeQhxDejUBZIACAHID+geIABgLIACgDIAEgBQASgBAqgHQCzgjBliaQBniagli4QgYh/hlhdIAAABQhkhMhqhHgAr6qJQAaA5AKA5QAhChhKCSQhICPiTBNIACAHIBigKIACgHIABgCIADgBQCPgGBbh5QBeh7gdiTQgXh6ibhwIgHgGgAo5n8QAUA2AFAdQAxD5jYCGIACAHIC9gSIABgTIABgDIAEgCIAPAAQBPgQArhHIAAgBQAuhIgQhQIAAAAIgOgrIjTicgAk1lAQASBFgoBNQgnBLg7AfIACAGIDzgWQAVgFAQghQAPgfgDgaIAAAAIgSglIAAgBIiYhqIAAAAIgGgEgAE1m1QgkAvgcAqQguBEAGAiIAAAAQADATAZAaQAUATAOABQAFgBAHgCIAAAAIDJg/IAAgHQg5gOg1g0Qg2g3gCg9IAAgHgAiLj6QAWALAVAAQAKAAAIgCIAAgBQBKgOgBhJIABgDIADgCIAJgCIgojQIgLAKIgBAAIAAABQgwB9iLAbQgYAEgVAAQgVAAgVgFIgDAGICqCHIAGgHIADgCIABAAIACAAgAAglOQALA4A4AAQATgCAKgBQAagFAbgbIACgCIAEABIAIAGIBfilIgcAFIgbAKIAAAAQgYAFgaAAQhbAAhZhDIAAAAIgFgEgAJYkmIADABIABACIABAFIB8gpIgHgCQjDg/gtjkQgHgkACgtIAAgKIgGAJIAAgBQglA+gtBCIAAgBQgvBTALA7QAQBRBNAoIAAAAQAvAaAyAAQAaABAdgIIABAAIABAAgAIwtJIABADQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQg9BtAXB0QATBjBiBcQBLBFBLAAQAYAAAXgHIELhQIAAgHQijgbh3hvQh6hwgeijQgPhJAGg9IgGgDgAl9nHIADABQAkAjA5AAQAWAAAYgFQC+glgRi1IABgEIAEgCIAEgBIgciOIgDAJQhLDPjoAtQgnAIhIAAIgMAAIB0BYIAQgUIACgBIACgBIABABgAL0yCIAAABIAAADIgBADQghAdgLBaQgLBnAMA9QAkC8ChBvIAAAAQB3BTCJAAQAuAAAvgJIAAAAICsgsIAAgGQjMgwiYiRQiYiUgojRQgciJAgh+IgGgDgAgdqkQAjC7CeAAQAbAAAkgGQBRgPAYg6QAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAgBQABAAAAABQABAAAAAAIAMAEIBRiMIgHADQhAAcgNABQgyALg2AAQiqAAhxh6IAAgBIgFgGgAr3q7QCRBtALAEIABAAQA1AbBEAAQAkAAAlgHQB/gYBfhoQBfhpgXh2IgiizIgHAAQhSFGlJBBQgwAKgyAAQgugBgtgKgAhsxVIAgClQAZCAB2BDQBXAyBbAAQAhAAAigGQBygXBChSIBviuIgFgFQhQAwhYARQhDAOhAAAQjzAAiejKgAuEsyIADABQBkBUCEAAQAoAAAvgIQCygkB+igQB8ihgcivIg0kMIgGAAQgMDaieCrQigCvjcAqQg7AMg+AAQhRAAhagVIgDAGICtB9IAFgEIADgBIAAAAgAis2hIAbCNQAkC4CtBdQB/BECCAAQAxAAA0gLQDfgqBHioIACgCIACgBIACAAIA6hcIgFgFQhhA4h+AZQhPAPhFAAQh8AAh9gqQjChCh/icg");
	mask.setTransform(0.2,-0.2);

	// Layer_12
	this.instance = new lib.Symbol7();
	this.instance.parent = this;
	this.instance.setTransform(34.8,41.5,1,1,0,0,0,4.9,4.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).wait(1).to({x:34.5,y:40.5},0).wait(1).to({x:34.3,y:39.6},0).wait(1).to({x:34.1,y:38.7},0).wait(1).to({x:33.9,y:37.8},0).wait(1).to({x:33.7,y:36.9},0).wait(1).to({x:33.5,y:35.9},0).wait(1).to({x:33.4,y:35},0).wait(1).to({x:33.3,y:34.1},0).wait(1).to({x:33.2,y:33.1},0).wait(1).to({y:32.2},0).wait(1).to({x:33.1,y:31.2},0).wait(1).to({y:30.3},0).wait(1).to({x:33.2,y:29.3},0).wait(1).to({y:28.4},0).wait(1).to({x:33.3,y:27.5},0).wait(1).to({x:33.5,y:26.5},0).wait(1).to({x:33.6,y:25.6},0).wait(1).to({x:33.8,y:24.7},0).wait(1).to({x:34.1,y:23.8},0).wait(1).to({x:34.4,y:22.9},0).wait(1).to({x:34.7,y:22},0).wait(1).to({x:35.1,y:21.1},0).wait(1).to({x:35.5,y:20.3},0).wait(1).to({x:36,y:19.5},0).wait(1).to({x:36.5,y:18.7},0).wait(1).to({x:37,y:17.9},0).wait(1).to({x:37.6,y:17.2},0).wait(1).to({x:38.2,y:16.4},0).wait(1).to({x:38.9,y:15.8},0).wait(1).to({x:39.6,y:15.1},0).wait(1).to({x:40.3,y:14.5},0).wait(1).to({x:41,y:13.9},0).wait(1).to({x:41.8,y:13.3},0).wait(1).to({x:42.5,y:12.8},0).wait(1).to({x:43.3,y:12.3},0).wait(1).to({x:44.1,y:11.8},0).wait(1).to({x:45,y:11.3},0).wait(1).to({x:45.8,y:10.9},0).wait(1).to({x:46.7,y:10.5},0).wait(1).to({x:47.5,y:10.1},0).wait(1).to({x:48.4,y:9.8},0).wait(1).to({x:49.3,y:9.4},0).wait(1).to({x:50.2,y:9.1},0).wait(1).to({x:51.1,y:8.8},0).wait(1).to({x:52,y:8.5},0).wait(1).to({x:52.9,y:8.3},0).wait(1).to({x:53.8,y:8},0).wait(1).to({x:54.7,y:7.8},0).wait(1).to({x:55.6,y:7.6},0).wait(1).to({x:56.9,y:7.3,alpha:0.857},0).wait(1).to({x:58.1,y:7.1,alpha:0.714},0).wait(1).to({x:59.4,y:6.9,alpha:0.571},0).wait(1).to({x:60.7,y:6.7,alpha:0.429},0).wait(1).to({x:61.9,y:6.5,alpha:0.286},0).wait(1).to({x:63.2,y:6.3,alpha:0.143},0).wait(1).to({x:64.5,y:6.2,alpha:0},0).wait(88));

	// Layer_11
	this.instance_1 = new lib.Symbol6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-87.6,-77.3,1,1,0,0,0,3.8,3.8);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).wait(1).to({x:-86.5,y:-75.7},0).wait(1).to({x:-85.5,y:-74.1},0).wait(1).to({x:-84.4,y:-72.5},0).wait(1).to({x:-83.4,y:-70.9},0).wait(1).to({x:-82.5,y:-69.3},0).wait(1).to({x:-81.5,y:-67.6},0).wait(1).to({x:-80.6,y:-66},0).wait(1).to({x:-79.7,y:-64.3},0).wait(1).to({x:-78.9,y:-62.6},0).wait(1).to({x:-78.1,y:-60.9},0).wait(1).to({x:-77.3,y:-59.1},0).wait(1).to({x:-76.6,y:-57.4},0).wait(1).to({x:-76,y:-55.6},0).wait(1).to({x:-75.3,y:-53.8},0).wait(1).to({x:-74.8,y:-52},0).wait(1).to({x:-74.3,y:-50.2},0).wait(1).to({x:-73.9,y:-48.3},0).wait(1).to({x:-73.5,y:-46.5},0).wait(1).to({x:-73.3,y:-44.6},0).wait(1).to({x:-73.1,y:-42.7},0).wait(1).to({x:-73,y:-40.8},0).wait(1).to({y:-38.9},0).wait(1).to({x:-73.1,y:-37},0).wait(1).to({x:-73.3,y:-35.1},0).wait(1).to({x:-73.6,y:-33.3},0).wait(1).to({x:-74,y:-31.4},0).wait(1).to({x:-74.6,y:-29.6},0).wait(1).to({x:-75.2,y:-27.8},0).wait(1).to({x:-75.9,y:-26.1},0).wait(1).to({x:-76.8,y:-24.3},0).wait(1).to({x:-77.7,y:-22.7},0).wait(1).to({x:-78.7,y:-21.1},0).wait(1).to({x:-79.8,y:-19.5},0).wait(1).to({x:-80.9,y:-18},0).wait(1).to({x:-82.2,y:-16.6},0).wait(1).to({x:-83.4,y:-15.2},0).wait(1).to({x:-84.8,y:-13.9},0).wait(1).to({x:-86.2,y:-12.6},0).wait(1).to({x:-87.6,y:-11.4},0).wait(1).to({x:-89.1,y:-10.2},0).wait(1).to({x:-90.6,y:-9},0).wait(1).to({x:-92.2,y:-8},0).wait(1).to({x:-93.8,y:-6.9},0).wait(1).to({x:-95.4,y:-5.9},0).wait(1).to({x:-97.4,y:-4.7,alpha:0.857},0).wait(1).to({x:-99.4,y:-3.6,alpha:0.714},0).wait(1).to({x:-101.5,y:-2.5,alpha:0.571},0).wait(1).to({x:-103.6,y:-1.4,alpha:0.429},0).wait(1).to({x:-105.8,y:-0.5,alpha:0.286},0).wait(1).to({x:-107.9,y:0.5,alpha:0.143},0).wait(1).to({x:-110.1,y:1.4,alpha:0},0).wait(118));

	// Layer_10
	this.instance_2 = new lib.Symbol5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(81.3,-105.7,0.552,0.552,0,0,0,6.3,6.3);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90).to({_off:false},0).wait(1).to({scaleX:0.56,scaleY:0.56,x:79.5,y:-104.7},0).wait(1).to({scaleX:0.57,scaleY:0.57,x:77.7,y:-103.8},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:75.8,y:-102.8},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:74,y:-101.9},0).wait(1).to({scaleX:0.59,scaleY:0.59,x:72.1,y:-101},0).wait(1).to({scaleX:0.6,scaleY:0.6,x:70.2,y:-100.3},0).wait(1).to({scaleX:0.61,scaleY:0.61,x:68.3,y:-99.4},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:66.4,y:-98.7},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:64.4,y:-97.9},0).wait(1).to({scaleX:0.63,scaleY:0.63,x:62.5,y:-97.2},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:60.5,y:-96.6},0).wait(1).to({scaleX:0.65,scaleY:0.65,x:58.6,y:-96},0).wait(1).to({scaleX:0.65,scaleY:0.65,x:56.6,y:-95.4},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:54.6,y:-94.8},0).wait(1).to({scaleX:0.67,scaleY:0.67,x:52.6,y:-94.3},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:50.6,y:-93.9},0).wait(1).to({scaleX:0.69,scaleY:0.69,x:48.6,y:-93.5},0).wait(1).to({scaleX:0.69,scaleY:0.69,x:46.5,y:-93.2},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:44.5,y:-92.9},0).wait(1).to({scaleX:0.71,scaleY:0.71,x:42.4,y:-92.7},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:40.4,y:-92.5},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:38.3,y:-92.4},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:36.3,y:-92.3},0).wait(1).to({scaleX:0.74,scaleY:0.74,x:34.2},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:32.1,y:-92.4},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:30.1,y:-92.5},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:28,y:-92.7},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:26,y:-93},0).wait(1).to({scaleX:0.78,scaleY:0.78,x:24,y:-93.3},0).wait(1).to({scaleX:0.79,scaleY:0.79,x:21.9,y:-93.7},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:19.9,y:-94.2},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:17.9,y:-94.7},0).wait(1).to({scaleX:0.81,scaleY:0.81,x:16,y:-95.3},0).wait(1).to({scaleX:0.82,scaleY:0.82,x:14,y:-95.9},0).wait(1).to({scaleX:0.83,scaleY:0.83,x:12.1,y:-96.6},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:10.1,y:-97.4},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:8.3,y:-98.2},0).wait(1).to({scaleX:0.85,scaleY:0.85,x:6.4,y:-99.1},0).wait(1).to({scaleX:0.86,scaleY:0.86,x:4.6,y:-100},0).wait(1).to({scaleX:0.87,scaleY:0.87,x:2.8,y:-101},0).wait(1).to({scaleX:0.87,scaleY:0.87,x:1,y:-102.1},0).wait(1).to({scaleX:0.88,scaleY:0.88,x:-0.7,y:-103.1},0).wait(1).to({scaleX:0.89,scaleY:0.89,x:-2.5,y:-104.3},0).wait(1).to({scaleX:0.9,scaleY:0.9,x:-4.2,y:-105.4},0).wait(1).to({scaleX:0.91,scaleY:0.91,x:-5.8,y:-106.7},0).wait(1).to({scaleX:0.91,scaleY:0.91,x:-7.5,y:-107.9},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:-9.1,y:-109.2},0).wait(1).to({scaleX:0.93,scaleY:0.93,x:-10.6,y:-110.5},0).wait(1).to({scaleX:0.87,scaleY:0.87,x:-12.4,y:-112},0).wait(1).to({scaleX:0.81,scaleY:0.81,x:-14,y:-113.6},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:-15.7,y:-115.2},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:-17.4,y:-116.9},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:-18.9,y:-118.5},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:-20.5,y:-120.2},0).wait(1).to({scaleX:0.53,scaleY:0.53,x:-22,y:-122},0).wait(1).to({scaleX:0.47,scaleY:0.47,x:-23.5,y:-123.7},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:-25,y:-125.5},0).wait(33));

	// Layer_9
	this.instance_3 = new lib.Symbol4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-158.7,147.5,1,1,0,0,0,10.8,10.8);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(57).to({_off:false},0).wait(1).to({x:-155.7,y:144.8,alpha:0.999},0).wait(1).to({x:-152.7,y:142.2,alpha:0.997},0).wait(1).to({x:-149.7,y:139.5,alpha:0.996},0).wait(1).to({x:-146.8,y:136.8,alpha:0.994},0).wait(1).to({x:-143.9,y:134.1,alpha:0.993},0).wait(1).to({x:-141,y:131.3,alpha:0.991},0).wait(1).to({x:-138.1,y:128.5,alpha:0.99},0).wait(1).to({x:-135.3,y:125.7,alpha:0.988},0).wait(1).to({x:-132.6,y:122.8,alpha:0.987},0).wait(1).to({x:-129.9,y:119.9,alpha:0.985},0).wait(1).to({x:-127.2,y:116.9,alpha:0.984},0).wait(1).to({x:-124.6,y:113.9,alpha:0.982},0).wait(1).to({x:-122,y:110.9,alpha:0.981},0).wait(1).to({x:-119.6,y:107.8,alpha:0.979},0).wait(1).to({x:-117.1,y:104.6,alpha:0.978},0).wait(1).to({x:-114.8,y:101.3,alpha:0.976},0).wait(1).to({x:-112.6,y:98,alpha:0.975},0).wait(1).to({x:-110.4,y:94.7,alpha:0.973},0).wait(1).to({x:-108.4,y:91.2,alpha:0.972},0).wait(1).to({x:-106.5,y:87.7,alpha:0.97},0).wait(1).to({x:-104.8,y:84.1,alpha:0.969},0).wait(1).to({x:-103.3,y:80.4,alpha:0.967},0).wait(1).to({x:-102,y:76.7,alpha:0.966},0).wait(1).to({x:-100.9,y:72.8,alpha:0.964},0).wait(1).to({x:-100.1,y:68.9,alpha:0.963},0).wait(1).to({x:-99.6,y:65,alpha:0.961},0).wait(1).to({x:-99.4,y:61,alpha:0.96},0).wait(1).to({x:-99.7,y:57,alpha:0.958},0).wait(1).to({x:-100.3,y:53.1,alpha:0.957},0).wait(1).to({x:-101.4,y:49.2,alpha:0.955},0).wait(1).to({x:-102.8,y:45.5,alpha:0.954},0).wait(1).to({x:-104.6,y:42,alpha:0.952},0).wait(1).to({x:-106.8,y:38.6,alpha:0.951},0).wait(1).to({x:-109.2,y:35.4,alpha:0.949},0).wait(1).to({x:-111.9,y:32.5,alpha:0.948},0).wait(1).to({x:-114.7,y:29.7,alpha:0.946},0).wait(1).to({x:-117.8,y:27.1,alpha:0.945},0).wait(1).to({x:-120.9,y:24.7,alpha:0.943},0).wait(1).to({x:-124.2,y:22.4,alpha:0.942},0).wait(1).to({x:-127.6,y:20.3,alpha:0.94},0).wait(1).to({x:-131.1,y:18.3,alpha:0.939},0).wait(1).to({x:-134.6,y:16.5,alpha:0.937},0).wait(1).to({x:-138.2,y:14.7,alpha:0.936},0).wait(1).to({x:-141.8,y:13.1,alpha:0.934},0).wait(1).to({x:-145.5,y:11.5,alpha:0.933},0).wait(1).to({x:-149.2,y:10.1,alpha:0.931},0).wait(1).to({x:-152.9,y:8.7,alpha:0.93},0).wait(1).to({x:-158.6,y:6.8,alpha:0.845},0).wait(1).to({x:-164.3,y:4.9,alpha:0.761},0).wait(1).to({x:-170,y:3.3,alpha:0.676},0).wait(1).to({x:-175.8,y:1.7,alpha:0.592},0).wait(1).to({x:-181.6,y:0.3,alpha:0.507},0).wait(1).to({x:-187.4,y:-1.1,alpha:0.423},0).wait(1).to({x:-193.2,y:-2.4,alpha:0.338},0).wait(1).to({x:-199.1,y:-3.5,alpha:0.254},0).wait(1).to({x:-205,y:-4.6,alpha:0.169},0).wait(1).to({x:-210.8,y:-5.7,alpha:0.085},0).wait(1).to({x:-216.8,y:-6.7,alpha:0},0).wait(65));

	// Layer_8
	this.instance_4 = new lib.Symbol3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(131.2,-186.4,1,1,0,0,0,8.4,8.4);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(23).to({_off:false},0).wait(1).to({x:128,y:-182.8},0).wait(1).to({x:124.7,y:-179.3},0).wait(1).to({x:121.3,y:-175.8},0).wait(1).to({x:117.9,y:-172.3},0).wait(1).to({x:114.5,y:-168.8},0).wait(1).to({x:111,y:-165.3},0).wait(1).to({x:107.5,y:-161.9},0).wait(1).to({x:104,y:-158.5},0).wait(1).to({x:100.5,y:-155.1},0).wait(1).to({x:96.9,y:-151.8},0).wait(1).to({x:93.3,y:-148.5},0).wait(1).to({x:89.7,y:-145.3},0).wait(1).to({x:86,y:-142.1},0).wait(1).to({x:82.2,y:-139},0).wait(1).to({x:78.3,y:-136},0).wait(1).to({x:74.5,y:-133.4},0).wait(1).to({x:70.2,y:-131},0).wait(1).to({x:65.8,y:-128.9},0).wait(1).to({x:61.3,y:-127},0).wait(1).to({x:56.8,y:-125.1},0).wait(1).to({x:52.2,y:-123.4},0).wait(1).to({x:47.6,y:-121.9},0).wait(1).to({x:42.9,y:-120.5},0).wait(1).to({x:38.1,y:-119.4},0).wait(1).to({x:33.3,y:-118.6},0).wait(1).to({x:28.4,y:-118.4},0).wait(1).to({x:24,y:-119.1},0).wait(1).to({x:19.3,y:-120.6},0).wait(1).to({x:14.8,y:-122.6},0).wait(1).to({x:10.4,y:-124.9},0).wait(1).to({x:6.3,y:-127.5},0).wait(1).to({x:2.3,y:-130.3},0).wait(1).to({x:-1.5,y:-133.4},0).wait(1).to({x:-4.9,y:-136.9},0).wait(1).to({x:-8,y:-140.6},0).wait(1).to({x:-10.6,y:-144.5},0).wait(1).to({x:-13,y:-148.8},0).wait(1).to({x:-15.2,y:-153.2},0).wait(1).to({x:-17.3,y:-157.6},0).wait(1).to({x:-19.3,y:-162.1},0).wait(1).to({x:-21.3,y:-166.6},0).wait(1).to({x:-23.2,y:-171},0).wait(1).to({x:-25.1,y:-175.6},0).wait(1).to({x:-26.9,y:-180.1},0).wait(1).to({x:-28.7,y:-184.6},0).wait(1).to({x:-30.5,y:-189.2},0).wait(1).to({x:-32.2,y:-193.7},0).wait(1).to({x:-33.9,y:-198.3},0).wait(1).to({x:-35.6,y:-202.9},0).wait(1).to({x:-37.2,y:-207.5},0).wait(1).to({x:-38.8,y:-212},0).wait(106));

	// Layer_5
	this.instance_5 = new lib.Symbol2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(108.9,176.7,1,1,0,0,0,8,8);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({x:107.9,y:172.8},0).wait(1).to({x:106.6,y:168.9},0).wait(1).to({x:105.4,y:165.1},0).wait(1).to({x:104.1,y:161.3},0).wait(1).to({x:102.8,y:157.4},0).wait(1).to({x:101.4,y:153.6},0).wait(1).to({x:100.1,y:149.8},0).wait(1).to({x:98.7,y:146},0).wait(1).to({x:97.2,y:142.2},0).wait(1).to({x:96.4,y:138.6},0).wait(1).to({x:95.9,y:134.5},0).wait(1).to({x:95.7,y:130.4},0).wait(1).to({x:95.5,y:126.4},0).wait(1).to({y:122.3},0).wait(1).to({x:95.6,y:118.3},0).wait(1).to({x:95.8,y:114.2},0).wait(1).to({x:96.1,y:110.2},0).wait(1).to({x:96.6,y:106.2},0).wait(1).to({x:97.1,y:102.1},0).wait(1).to({x:97.8,y:98.2},0).wait(1).to({x:98.8,y:94.8},0).wait(1).to({x:100.9,y:90.9},0).wait(1).to({x:103.1,y:87.5},0).wait(1).to({x:105.5,y:84.2},0).wait(1).to({x:108.1,y:81.1},0).wait(1).to({x:110.8,y:78.1},0).wait(1).to({x:113.7,y:75.3},0).wait(1).to({x:116.8,y:72.6},0).wait(1).to({x:120.1,y:70.3},0).wait(1).to({x:123.4,y:68.2},0).wait(1).to({x:127,y:66.4},0).wait(1).to({x:130.7,y:64.7},0).wait(1).to({x:134.5,y:63.1},0).wait(1).to({x:138.3,y:61.8},0).wait(1).to({x:142.3,y:60.7},0).wait(1).to({x:146.2,y:59.9},0).wait(1).to({x:150.3,y:59.5},0).wait(1).to({x:154,y:60},0).wait(1).to({x:158,y:60.5},0).wait(1).to({x:162.1,y:60.6},0).wait(1).to({x:166.2},0).wait(1).to({x:170.3,y:60.5},0).wait(1).to({x:174.3,y:60.3},0).wait(1).to({x:178.4,y:60},0).wait(1).to({x:182.4,y:59.6},0).wait(1).to({x:186.4,y:59.2},0).wait(1).to({x:190.5,y:58.6},0).wait(1).to({x:194.4,y:57.8},0).wait(1).to({x:198.2,y:56.7},0).wait(131));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(100.9,168.7,16,16);


(lib.Pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AglAmQgPgQAAgWQAAgVAPgQQAQgPAVAAQAWAAAQAPQAPAQAAAVQAAAWgPAQQgQAPgWAAQgVAAgQgPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(62));

	// Layer_3
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({_off:false},0).to({scaleX:2.75,scaleY:2.75,alpha:0},37).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween7("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:2.75,scaleY:2.75,alpha:0},33).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.3,-5.3,10.7,10.7);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.instance = new lib.Pointer();
	this.instance.parent = this;
	this.instance.setTransform(-387.2,316.9,1.477,1.477);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(108).to({_off:false},0).wait(1).to({x:-384.6,y:314.4},0).wait(1).to({x:-382,y:311.8},0).wait(1).to({x:-379.4,y:309.3},0).wait(1).to({x:-376.8,y:306.7},0).wait(1).to({x:-374.3,y:304.2},0).wait(1).to({x:-371.7,y:301.7},0).wait(1).to({x:-369.1,y:299.1},0).wait(1).to({x:-366.5,y:296.6},0).wait(1).to({x:-363.9,y:294},0).wait(1).to({x:-361.3,y:291.5},0).wait(1).to({x:-358.7,y:288.9},0).wait(1).to({x:-356.1,y:286.4},0).wait(1).to({x:-353.5,y:283.9},0).wait(1).to({x:-351,y:281.3},0).wait(1).to({x:-348.4,y:278.8},0).wait(1).to({x:-345.8,y:276.2},0).wait(1).to({x:-343.2,y:273.7},0).wait(1).to({x:-340.6,y:271.2},0).wait(1).to({x:-338,y:268.6},0).wait(1).to({x:-335.4,y:266.1},0).wait(1).to({x:-332.8,y:263.5},0).wait(1).to({x:-330.3,y:261},0).wait(1).to({x:-327.7,y:258.4},0).wait(1).to({x:-325.1,y:255.9},0).wait(1).to({x:-322.5,y:253.4},0).wait(1).to({x:-319.9,y:250.8},0).wait(1).to({x:-317.3,y:248.3},0).wait(1).to({x:-314.7,y:245.7},0).wait(1).to({x:-312.1,y:243.2},0).wait(1).to({x:-309.5,y:240.7},0).wait(1).to({x:-307,y:238.1},0).wait(1).to({x:-304.4,y:235.6},0).wait(1).to({x:-301.8,y:233},0).wait(1).to({x:-299.2,y:230.5},0).wait(1).to({x:-296.6,y:227.9},0).wait(1).to({x:-294,y:225.4},0).wait(1).to({x:-291.4,y:222.9},0).wait(1).to({x:-288.8,y:220.3},0).wait(1).to({x:-286.3,y:217.8},0).wait(1).to({x:-283.7,y:215.2},0).wait(1).to({x:-281.1,y:212.7},0).wait(1).to({x:-278.5,y:210.2},0).wait(1).to({x:-275.9,y:207.6},0).wait(1).to({x:-273.3,y:205.1},0).wait(1).to({x:-270.7,y:202.5},0).wait(1).to({x:-268.1,y:200},0).wait(1).to({x:-265.5,y:197.5},0).wait(1).to({x:-263,y:194.9},0).wait(1).to({x:-260.4,y:192.4},0).wait(1).to({x:-257.8,y:189.8},0).wait(1).to({x:-255.2,y:187.3},0).wait(1).to({x:-252.6,y:184.7},0).wait(1).to({x:-250,y:182.2},0).wait(1).to({x:-247.4,y:179.7},0).wait(1).to({x:-244.8,y:177.1},0).wait(1).to({x:-242.2,y:174.6},0).wait(1).to({x:-239.7,y:172},0).wait(1).to({x:-237.1,y:169.5},0).wait(1).to({x:-234.5,y:166.9},0).wait(1).to({x:-231.9,y:164.4},0).wait(1).to({x:-229.3,y:161.9},0).wait(1).to({x:-226.7,y:159.3},0).wait(1).to({x:-224.1,y:156.8},0).wait(1).to({x:-221.5,y:154.2},0).wait(1).to({x:-218.9,y:151.7},0).wait(9).to({_off:true},1).wait(38));

	// Layer_5
	this.instance_1 = new lib.Pointer();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-106.7,-21.5,1.477,1.477);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(122).to({_off:false},0).wait(1).to({x:-108.2,y:-19.2},0).wait(1).to({x:-109.7,y:-16.9},0).wait(1).to({x:-111.1,y:-14.6},0).wait(1).to({x:-112.6,y:-12.3},0).wait(1).to({x:-114.1,y:-10.1},0).wait(1).to({x:-115.6,y:-7.8},0).wait(1).to({x:-117,y:-5.5},0).wait(1).to({x:-118.5,y:-3.2},0).wait(1).to({x:-120,y:-0.9},0).wait(1).to({x:-121.5,y:1.4},0).wait(1).to({x:-122.9,y:3.7},0).wait(1).to({x:-124.4,y:6},0).wait(1).to({x:-125.9,y:8.3},0).wait(1).to({x:-127.4,y:10.5},0).wait(1).to({x:-128.9,y:12.8},0).wait(1).to({x:-130.3,y:15.1},0).wait(1).to({x:-131.8,y:17.4},0).wait(1).to({x:-133.3,y:19.7},0).wait(1).to({x:-134.8,y:22},0).wait(1).to({x:-136.2,y:24.3},0).wait(1).to({x:-137.7,y:26.6},0).wait(1).to({x:-139.2,y:28.9},0).wait(1).to({x:-140.7,y:31.1},0).wait(1).to({x:-142.1,y:33.4},0).wait(1).to({x:-143.6,y:35.7},0).wait(1).to({x:-145.1,y:38},0).wait(1).to({x:-146.6,y:40.3},0).wait(1).to({x:-148.1,y:42.6},0).wait(1).to({x:-149.5,y:44.9},0).wait(1).to({x:-151,y:47.2},0).wait(1).to({x:-152.5,y:49.5},0).wait(1).to({x:-154,y:51.7},0).wait(1).to({x:-155.4,y:54},0).wait(1).to({x:-156.9,y:56.3},0).wait(1).to({x:-158.4,y:58.6},0).wait(1).to({x:-159.9,y:60.9},0).wait(1).to({x:-161.3,y:63.2},0).wait(1).to({x:-162.8,y:65.5},0).wait(1).to({x:-164.3,y:67.8},0).wait(1).to({x:-165.8,y:70.1},0).wait(1).to({x:-167.3,y:72.3},0).wait(1).to({x:-168.7,y:74.6},0).wait(1).to({x:-170.2,y:76.9},0).wait(1).to({x:-171.7,y:79.2},0).wait(1).to({x:-173.2,y:81.5},0).wait(1).to({x:-174.6,y:83.8},0).wait(1).to({x:-176.1,y:86.1},0).wait(1).to({x:-177.6,y:88.4},0).wait(1).to({x:-179.1,y:90.7},0).wait(1).to({x:-180.5,y:92.9},0).wait(1).to({x:-182,y:95.2},0).wait(1).to({x:-183.5,y:97.5},0).wait(1).to({x:-185,y:99.8},0).wait(1).to({x:-186.5,y:102.1},0).wait(1).to({x:-187.9,y:104.4},0).wait(1).to({x:-189.4,y:106.7},0).wait(1).to({x:-190.9,y:109},0).wait(1).to({x:-192.4,y:111.3},0).wait(1).to({x:-193.8,y:113.5},0).wait(1).to({x:-195.3,y:115.8},0).wait(1).to({x:-196.8,y:118.1},0).wait(1).to({x:-198.3,y:120.4},0).wait(1).to({x:-199.7,y:122.7},0).wait(1).to({x:-201.2,y:125},0).wait(1).to({x:-202.7,y:127.3},0).wait(1).to({x:-204.2,y:129.6},0).wait(1).to({x:-205.7,y:131.8},0).wait(1).to({x:-207.1,y:134.1},0).wait(1).to({x:-208.6,y:136.4},0).wait(1).to({x:-210.1,y:138.7},0).wait(1).to({x:-211.6,y:141},0).wait(1).to({x:-213,y:143.3},0).wait(1).to({x:-214.5,y:145.6},0).wait(1).to({x:-216,y:147.9},0).wait(1).to({x:-217.5,y:150.2},0).wait(1).to({x:-218.9,y:152.5},0).wait(23));

	// Layer_4
	this.instance_2 = new lib.Pointer();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-115.5,338.6,1.477,1.477);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(127).to({_off:false},0).wait(1).to({x:-117,y:335.9},0).wait(1).to({x:-118.5,y:333.2},0).wait(1).to({x:-120,y:330.5},0).wait(1).to({x:-121.5,y:327.9},0).wait(1).to({x:-122.9,y:325.2},0).wait(1).to({x:-124.4,y:322.5},0).wait(1).to({x:-125.9,y:319.9},0).wait(1).to({x:-127.4,y:317.2},0).wait(1).to({x:-128.9,y:314.5},0).wait(1).to({x:-130.3,y:311.9},0).wait(1).to({x:-131.8,y:309.2},0).wait(1).to({x:-133.3,y:306.5},0).wait(1).to({x:-134.8,y:303.8},0).wait(1).to({x:-136.2,y:301.2},0).wait(1).to({x:-137.7,y:298.5},0).wait(1).to({x:-139.2,y:295.8},0).wait(1).to({x:-140.7,y:293.2},0).wait(1).to({x:-142.2,y:290.5},0).wait(1).to({x:-143.6,y:287.8},0).wait(1).to({x:-145.1,y:285.2},0).wait(1).to({x:-146.6,y:282.5},0).wait(1).to({x:-148.1,y:279.8},0).wait(1).to({x:-149.5,y:277.2},0).wait(1).to({x:-151,y:274.5},0).wait(1).to({x:-152.5,y:271.8},0).wait(1).to({x:-154,y:269.1},0).wait(1).to({x:-155.5,y:266.5},0).wait(1).to({x:-156.9,y:263.8},0).wait(1).to({x:-158.4,y:261.1},0).wait(1).to({x:-159.9,y:258.5},0).wait(1).to({x:-161.4,y:255.8},0).wait(1).to({x:-162.8,y:253.1},0).wait(1).to({x:-164.3,y:250.5},0).wait(1).to({x:-165.8,y:247.8},0).wait(1).to({x:-167.3,y:245.1},0).wait(1).to({x:-168.8,y:242.5},0).wait(1).to({x:-170.2,y:239.8},0).wait(1).to({x:-171.7,y:237.1},0).wait(1).to({x:-173.2,y:234.4},0).wait(1).to({x:-174.7,y:231.8},0).wait(1).to({x:-176.1,y:229.1},0).wait(1).to({x:-177.6,y:226.4},0).wait(1).to({x:-179.1,y:223.8},0).wait(1).to({x:-180.6,y:221.1},0).wait(1).to({x:-182.1,y:218.4},0).wait(1).to({x:-183.5,y:215.8},0).wait(1).to({x:-185,y:213.1},0).wait(1).to({x:-186.5,y:210.4},0).wait(1).to({x:-188,y:207.8},0).wait(1).to({x:-189.4,y:205.1},0).wait(1).to({x:-190.9,y:202.4},0).wait(1).to({x:-192.4,y:199.7},0).wait(1).to({x:-193.9,y:197.1},0).wait(1).to({x:-195.4,y:194.4},0).wait(1).to({x:-196.8,y:191.7},0).wait(1).to({x:-198.3,y:189.1},0).wait(1).to({x:-199.8,y:186.4},0).wait(1).to({x:-201.3,y:183.7},0).wait(1).to({x:-202.7,y:181.1},0).wait(1).to({x:-204.2,y:178.4},0).wait(1).to({x:-205.7,y:175.7},0).wait(1).to({x:-207.2,y:173.1},0).wait(1).to({x:-208.7,y:170.4},0).wait(1).to({x:-210.1,y:167.7},0).wait(1).to({x:-211.6,y:165},0).wait(1).to({x:-213.1,y:162.4},0).wait(1).to({x:-214.6,y:159.7},0).wait(1).to({x:-216,y:157},0).wait(1).to({x:-217.5,y:154.4},0).wait(1).to({x:-219,y:151.7},0).wait(24));

	// Layer_3
	this.instance_3 = new lib.Pointer();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-386.1,31.4,1.477,1.477);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(80).to({_off:false},0).wait(1).to({x:-383.2,y:33.5},0).wait(1).to({x:-380.3,y:35.6},0).wait(1).to({x:-377.4,y:37.7},0).wait(1).to({x:-374.4,y:39.8},0).wait(1).to({x:-371.5,y:42},0).wait(1).to({x:-368.6,y:44.1},0).wait(1).to({x:-365.6,y:46.2},0).wait(1).to({x:-362.7,y:48.3},0).wait(1).to({x:-359.8,y:50.4},0).wait(1).to({x:-356.8,y:52.5},0).wait(1).to({x:-353.9,y:54.6},0).wait(1).to({x:-351,y:56.7},0).wait(1).to({x:-348,y:58.8},0).wait(1).to({x:-345.1,y:61},0).wait(1).to({x:-342.2,y:63.1},0).wait(1).to({x:-339.2,y:65.2},0).wait(1).to({x:-336.3,y:67.3},0).wait(1).to({x:-333.4,y:69.4},0).wait(1).to({x:-330.4,y:71.5},0).wait(1).to({x:-327.5,y:73.6},0).wait(1).to({x:-324.6,y:75.7},0).wait(1).to({x:-321.6,y:77.9},0).wait(1).to({x:-318.7,y:80},0).wait(1).to({x:-315.8,y:82.1},0).wait(1).to({x:-312.8,y:84.2},0).wait(1).to({x:-309.9,y:86.3},0).wait(1).to({x:-307,y:88.4},0).wait(1).to({x:-304,y:90.5},0).wait(1).to({x:-301.1,y:92.6},0).wait(1).to({x:-298.2,y:94.7},0).wait(1).to({x:-295.2,y:96.9},0).wait(1).to({x:-292.3,y:99},0).wait(1).to({x:-289.4,y:101.1},0).wait(1).to({x:-286.4,y:103.2},0).wait(1).to({x:-283.5,y:105.3},0).wait(1).to({x:-280.6,y:107.4},0).wait(1).to({x:-277.6,y:109.5},0).wait(1).to({x:-274.7,y:111.6},0).wait(1).to({x:-271.8,y:113.7},0).wait(1).to({x:-268.9,y:115.9},0).wait(1).to({x:-265.9,y:118},0).wait(1).to({x:-263,y:120.1},0).wait(1).to({x:-260.1,y:122.2},0).wait(1).to({x:-257.1,y:124.3},0).wait(1).to({x:-254.2,y:126.4},0).wait(1).to({x:-251.3,y:128.5},0).wait(1).to({x:-248.3,y:130.6},0).wait(1).to({x:-245.4,y:132.7},0).wait(1).to({x:-242.5,y:134.9},0).wait(1).to({x:-239.5,y:137},0).wait(1).to({x:-236.6,y:139.1},0).wait(1).to({x:-233.7,y:141.2},0).wait(1).to({x:-230.7,y:143.3},0).wait(1).to({x:-227.8,y:145.4},0).wait(1).to({x:-224.9,y:147.5},0).wait(1).to({x:-221.9,y:149.6},0).wait(1).to({x:-219,y:151.8},0).wait(84));

	// 2
	this.instance_4 = new lib.Pointer();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-243.5,365.1,1.477,1.477);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(35).to({_off:false},0).wait(1).to({x:-243.1,y:361.6},0).wait(1).to({x:-242.7,y:358.1},0).wait(1).to({x:-242.3,y:354.6},0).wait(1).to({x:-241.9,y:351.1},0).wait(1).to({x:-241.5,y:347.6},0).wait(1).to({x:-241.1,y:344.1},0).wait(1).to({x:-240.7,y:340.6},0).wait(1).to({x:-240.3,y:337.1},0).wait(1).to({x:-239.9,y:333.6},0).wait(1).to({x:-239.5,y:330.1},0).wait(1).to({x:-239.1,y:326.6},0).wait(1).to({x:-238.7,y:323.1},0).wait(1).to({x:-238.3,y:319.6},0).wait(1).to({x:-237.9,y:316.1},0).wait(1).to({x:-237.5,y:312.6},0).wait(1).to({x:-237.1,y:309.1},0).wait(1).to({x:-236.7,y:305.6},0).wait(1).to({x:-236.3,y:302.1},0).wait(1).to({x:-235.9,y:298.6},0).wait(1).to({x:-235.5,y:295.1},0).wait(1).to({x:-235,y:291.6},0).wait(1).to({x:-234.6,y:288.1},0).wait(1).to({x:-234.2,y:284.6},0).wait(1).to({x:-233.8,y:281.1},0).wait(1).to({x:-233.4,y:277.6},0).wait(1).to({x:-233,y:274.1},0).wait(1).to({x:-232.6,y:270.6},0).wait(1).to({x:-232.2,y:267.1},0).wait(1).to({x:-231.8,y:263.7},0).wait(1).to({x:-231.4,y:260.2},0).wait(1).to({x:-231,y:256.7},0).wait(1).to({x:-230.6,y:253.2},0).wait(1).to({x:-230.2,y:249.7},0).wait(1).to({x:-229.8,y:246.2},0).wait(1).to({x:-229.4,y:242.7},0).wait(1).to({x:-229,y:239.2},0).wait(1).to({x:-228.6,y:235.7},0).wait(1).to({x:-228.2,y:232.2},0).wait(1).to({x:-227.8,y:228.7},0).wait(1).to({x:-227.4,y:225.2},0).wait(1).to({x:-227,y:221.7},0).wait(1).to({x:-226.6,y:218.2},0).wait(1).to({x:-226.2,y:214.7},0).wait(1).to({x:-225.8,y:211.2},0).wait(1).to({x:-225.4,y:207.7},0).wait(1).to({x:-225,y:204.2},0).wait(1).to({x:-224.6,y:200.7},0).wait(1).to({x:-224.2,y:197.2},0).wait(1).to({x:-223.8,y:193.7},0).wait(1).to({x:-223.4,y:190.2},0).wait(1).to({x:-223,y:186.7},0).wait(1).to({x:-222.6,y:183.2},0).wait(1).to({x:-222.2,y:179.7},0).wait(1).to({x:-221.8,y:176.2},0).wait(1).to({x:-221.4,y:172.7},0).wait(1).to({x:-221,y:169.2},0).wait(1).to({x:-220.6,y:165.7},0).wait(1).to({x:-220.2,y:162.2},0).wait(1).to({x:-219.8,y:158.7},0).wait(1).to({x:-219.4,y:155.2},0).wait(1).to({x:-218.9,y:151.7},0).wait(125));

	// 1
	this.instance_5 = new lib.Pointer();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-14.9,91.7,1.477,1.477);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({scaleX:1.48,scaleY:1.48,x:-18.4,y:92.7},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-21.9,y:93.7},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-25.3,y:94.8},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-28.8,y:95.8},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-32.3,y:96.8},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-35.7,y:97.8},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-39.2,y:98.9},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-42.7,y:99.9},0).wait(1).to({scaleX:1.47,scaleY:1.47,x:-46.1,y:100.9},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-49.6,y:101.9},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-53.1,y:103},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-56.5,y:104},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-60,y:105},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-63.5,y:106},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-66.9,y:107.1},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-70.4,y:108.1},0).wait(1).to({scaleX:1.46,scaleY:1.46,x:-73.8,y:109.1},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-77.3,y:110.1},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-80.8,y:111.2},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-84.2,y:112.2},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-87.7,y:113.2},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-91.2,y:114.2},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-94.6,y:115.2},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-98.1,y:116.3},0).wait(1).to({scaleX:1.45,scaleY:1.45,x:-101.6,y:117.3},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-105,y:118.3},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-108.5,y:119.3},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-112,y:120.4},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-115.4,y:121.4},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-118.9,y:122.4},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-122.3,y:123.4},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-125.8,y:124.5},0).wait(1).to({scaleX:1.44,scaleY:1.44,x:-129.3,y:125.5},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-132.7,y:126.5},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-136.2,y:127.5},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-139.7,y:128.6},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-143.1,y:129.6},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-146.6,y:130.6},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-150.1,y:131.6},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-153.5,y:132.6},0).wait(1).to({scaleX:1.43,scaleY:1.43,x:-157,y:133.7},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-160.5,y:134.7},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-163.9,y:135.7},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-167.4,y:136.7},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-170.8,y:137.8},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-174.3,y:138.8},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-177.8,y:139.8},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-181.2,y:140.8},0).wait(1).to({scaleX:1.42,scaleY:1.42,x:-184.7,y:141.9},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-188.2,y:142.9},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-191.6,y:143.9},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-195.1,y:144.9},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-198.6,y:146},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-202,y:147},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-205.5,y:148},0).wait(1).to({scaleX:1.41,scaleY:1.41,x:-209,y:149},0).wait(1).to({scaleX:1.4,scaleY:1.4,x:-212.4,y:150.1},0).wait(1).to({scaleX:1.4,scaleY:1.4,x:-215.9,y:151.1},0).wait(1).to({scaleX:1.4,scaleY:1.4,x:-219.3,y:152.1},0).wait(162));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.8,83.8,15.8,15.8);


// stage content:
(lib.homeanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_75 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(75).call(this.frame_75).wait(1));

	// xIcon
	this.instance = new lib.XIcon();
	this.instance.parent = this;
	this.instance.setTransform(346,335.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(67));

	// Layer_6
	this.instance_1 = new lib.Symbol8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(567.5,179.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(35).to({_off:false},0).wait(41));

	// Zadd-red effect
	this.instance_2 = new lib.redFlash01();
	this.instance_2.parent = this;
	this.instance_2.setTransform(341.6,344.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(39).to({_off:false},0).wait(37));

	// zadd
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(341.6,324.2);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({y:344.2,alpha:1},39).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(476.1,466.8,411,388.8);
// library properties:
lib.properties = {
	id: 'A14907C3CFA61245982069F7742A9AAD',
	width: 680,
	height: 674,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://www.xbyte.io/wp-content/themes/xbyte/images/home_animation_atlas_.png", id:"home_animation_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A14907C3CFA61245982069F7742A9AAD'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;