jQuery(document).ready(function(){


jQuery('.accordion:first-child .acc-btn').addClass('active');
jQuery('.accordion:first-child .acc-content').addClass('current');
if(jQuery('.accordion-box').length){
		jQuery(".accordion-box").on('click', '.acc-btn', function() {
			
			var target = jQuery(this).parents('.accordion');
			
			if(jQuery(this).hasClass('active')!==true){
				jQuery('.accordion .acc-btn').removeClass('active');
			}
			
			if (jQuery(this).next('.acc-content').is(':visible')){
				//$(this).removeClass('active');
				return false;
				//$(this).next('.accord-content').slideUp(300);
			}else{
				jQuery(this).addClass('active');
				jQuery('.accordion').removeClass('active-block');
				jQuery('.accordion .acc-content').slideUp(300);
				target.addClass('active-block');
				jQuery(this).next('.acc-content').slideDown(300);	
			}
		});	
	}

 });	