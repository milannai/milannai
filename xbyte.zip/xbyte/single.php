<?php get_header(); ?>
<?php  ?>
<div class="main-banner">
	<div class="xb-bannerContent">
		<div class="bannerBox01_blog">
			<div class="banner-textbox"><div class="xb-bannertitle01">
					<h1><?php the_title(); ?></h1>
				</div>
				
			</div>
		</div>
	</div>
</div>
<?php  ?>

<div class="BlogDetails_Main">
	<div class="container">
		<div class="BlogDetails">
			<div id="primary" class="content-area">
				<div class="containerd">
        			<img src="<?php the_field('detail_page_image'); ?>">
	        		<div class="blogContent_main">
		        		<div class="blogContent">
		        		<?php
		        		// For Page contat
		            	while ( have_posts() ) : the_post(); 
		            		
		                	the_content();
		                ?>
		                </div>
		                <div class="BlogComment">
		                	<?php 
		                	if ( comments_open() || get_comments_number() ) :
							comments_template();
							endif;
							?>
		                </div>
	            	</div>
                <?php endwhile;wp_reset_query(); ?>
        		
    			</div>
			</div><!-- .content-area -->
		</div>

	</div>

		<div class="BlogSidebar">
			<?php get_sidebar(); ?>
		</div>
</div>

<?php get_footer(); ?>
