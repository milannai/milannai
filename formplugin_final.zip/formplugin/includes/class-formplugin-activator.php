<?php
/**
 * Fired during plugin activation
 *
 * @link       www.milan.com
 * @since      1.0.0
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 */
class Formplugin_Activator {

	public static function activate() {
		
		
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		
		$table_name = $wpdb->prefix . "customer"; 

		$sql = "CREATE TABLE $table_name (
			 id mediumint(9) NOT NULL AUTO_INCREMENT,
			 firstname varchar(50) NOT NULL,
			 lastname varchar(50) NOT NULL,
			 email varchar(100) NOT NULL,
			 address text NOT NULL,
			 phone varchar(20) NOT NULL,
			 image text NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );	
						
	}
}	