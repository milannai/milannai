<?php
/**
 * Fired during plugin deactivation
 *
 * @link       www.milan.com
 * @since      1.0.0
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 */
class Formplugin_Deactivator {
	
	public static function deactivate() {
			// if uninstall.php is not called by WordPress, die

	}
}